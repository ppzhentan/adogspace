import sqlite3
import json
import os
from pathlib import Path

DB = Path(os.getenv('EVAL_DB', str(Path(__file__).resolve().parent / 'evals.sqlite3')))

def conn():
    db = sqlite3.connect(DB, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    return db

def init():
    with conn() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY, variant TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, success_rate REAL NOT NULL, report TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS labels (id INTEGER PRIMARY KEY, run_id INTEGER NOT NULL, case_id TEXT NOT NULL, reviewer TEXT NOT NULL, score INTEGER NOT NULL CHECK(score BETWEEN 0 AND 5), note TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(run_id) REFERENCES runs(id));
        ''')

def save_run(variant, report):
    init()
    with conn() as db:
        cur = db.execute('INSERT INTO runs(variant,success_rate,report) VALUES(?,?,?)', (variant, report['success_rate'], json.dumps(report,ensure_ascii=False)))
        return cur.lastrowid

def list_runs():
    init()
    with conn() as db:
        return [dict(r) for r in db.execute('SELECT id,variant,created_at,success_rate FROM runs ORDER BY id DESC LIMIT 100')]

def get_run(run_id):
    init()
    with conn() as db:
        r = db.execute('SELECT * FROM runs WHERE id=?',(run_id,)).fetchone()
        if r is None: return None
        d=dict(r); d['report']=json.loads(d['report']); return d

def add_label(run_id,case_id,reviewer,score,note):
    if not get_run(run_id): raise ValueError('run not found')
    if not any(x['case_id']==case_id for x in get_run(run_id)['report']['results']): raise ValueError('case not in run')
    with conn() as db:
        db.execute('INSERT INTO labels(run_id,case_id,reviewer,score,note) VALUES(?,?,?,?,?)',(run_id,case_id,reviewer,score,note))

def list_labels(run_id):
    init()
    with conn() as db:
        return [dict(r) for r in db.execute('SELECT * FROM labels WHERE run_id=? ORDER BY id DESC',(run_id,))]
