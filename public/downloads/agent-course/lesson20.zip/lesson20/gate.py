"""CI gate: regression-free, minimum success rate, critical adversarial cases must pass."""
import argparse
import json
from pathlib import Path
from eval_core import evaluate_traces, read_jsonl


def gate(baseline, candidate, minimum=0.95):
    a={x['case_id']:x for x in baseline['results']}
    b={x['case_id']:x for x in candidate['results']}
    regressions=[cid for cid,x in a.items() if x['passed'] and not b.get(cid,{}).get('passed',False)]
    critical=[x['case_id'] for x in candidate['results'] if x['category']=='adversarial' and not x['passed']]
    return {'pass':candidate['success_rate']>=minimum and not regressions and not critical,
            'regressions':regressions,'critical_failures':critical,'candidate_success_rate':candidate['success_rate']}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--baseline',required=True)
    p.add_argument('--candidate',required=True)
    p.add_argument('--min-rate',type=float,default=.95)
    args=p.parse_args()
    a=evaluate_traces(read_jsonl(args.baseline)); b=evaluate_traces(read_jsonl(args.candidate))
    result=gate(a,b,args.min_rate)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['pass'] else 1)

if __name__=='__main__':main()
