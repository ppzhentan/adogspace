import os
import secrets
from pathlib import Path
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from store import list_runs,get_run,add_label,list_labels

app=FastAPI(title='Lesson 20 Agent Eval Dashboard')
TOKEN=os.getenv('EVAL_API_TOKEN','')

def auth(authorization: str|None=Header(default=None)):
    if not TOKEN or not authorization or not authorization.startswith('Bearer ') or not secrets.compare_digest(authorization[7:],TOKEN):
        raise HTTPException(401,'Invalid token')

class Label(BaseModel):
    case_id: str=Field(min_length=1,max_length=100)
    reviewer: str=Field(min_length=1,max_length=100)
    score: int=Field(ge=0,le=5)
    note: str=Field(default='',max_length=3000)

@app.get('/',response_class=HTMLResponse)
def index():
    return (Path(__file__).resolve().parent/'static/index.html').read_text(encoding='utf-8')

@app.get('/api/runs',dependencies=[Depends(auth)])
def runs():return list_runs()

@app.get('/api/runs/{run_id}',dependencies=[Depends(auth)])
def run(run_id:int):
    result=get_run(run_id)
    if result is None:raise HTTPException(404,'Run not found')
    return result

@app.get('/api/runs/{run_id}/labels',dependencies=[Depends(auth)])
def labels(run_id:int):
    if get_run(run_id) is None:raise HTTPException(404,'Run not found')
    return list_labels(run_id)

@app.post('/api/runs/{run_id}/labels',dependencies=[Depends(auth)])
def label(run_id:int,data:Label):
    try:add_label(run_id,data.case_id,data.reviewer,data.score,data.note)
    except ValueError as e:raise HTTPException(400,str(e))
    return {'ok':True}
