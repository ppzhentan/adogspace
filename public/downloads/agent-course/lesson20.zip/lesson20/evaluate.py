import argparse
import json
from pathlib import Path
from eval_core import read_jsonl, evaluate_traces, ROOT
from store import save_run


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--trace', required=True, help='JSONL exported from real workflow or provided fixtures')
    p.add_argument('--variant', default='candidate')
    args=p.parse_args()
    report=evaluate_traces(read_jsonl(args.trace))
    report['variant']=args.variant
    run_id=save_run(args.variant,report)
    dest=ROOT/'reports'; dest.mkdir(exist_ok=True)
    (dest/f'{args.variant}_{run_id}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[f'# Eval run {run_id} — {args.variant}', '', f"Success: {report['passed']}/{report['total']} ({report['success_rate']:.0%})",'']
    for r in report['results']:
        lines.append(f"- {'PASS' if r['passed'] else 'FAIL'} `{r['case_id']}`: {r['checks']}")
    (dest/f'{args.variant}_{run_id}.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f"Run {run_id}: {report['passed']}/{report['total']} passed; report: {dest/f'{args.variant}_{run_id}.md'}")

if __name__=='__main__':main()
