# Lesson 20 — Multi-Agent Evals

Requires Python 3.10+ and optionally Ollama `qwen3-local` for independent judge experiments.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Offline reproducible evaluation

```bash
python -m pytest -q
python evaluate.py --trace traces/baseline.jsonl --variant baseline
python evaluate.py --trace traces/candidate.jsonl --variant candidate
python gate.py --baseline traces/baseline.jsonl --candidate traces/candidate.jsonl --min-rate 0.95
```

Reports are saved under `reports/` and SQLite `evals.sqlite3`.

## Dashboard and human labeling

```bash
export EVAL_API_TOKEN="$(python -c 'import secrets;print(secrets.token_urlsafe(32))')"
uvicorn server:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 and paste the token. Select a run, click a case row, give a score 0–5 and submit notes. Labeling is separate from automatic pass/fail.

## Connect your actual Lesson 18 traces

Export **one JSON object per case** in JSONL format, each with `case_id`, `answer`, `tool_calls`, `sources`, `events`, `published`, `latency_ms`. Map real workflow events into canonical names `node_completed` with `node`, `approval_granted`, `published`. Include each test case, including failures, or missing cases will fail. **Do not** fabricate tool calls, approvals or model outputs. Preserve full raw trace separately for investigation. Redact tokens, PII, and secrets before export.

Example:
```json
{"case_id":"shipping","answer":"满6999日元免运费","tool_calls":[{"name":"read_document","args":{"filename":"shipping.md"}}],"sources":["shipping.md"],"events":[{"type":"node_completed","node":"research"},{"type":"approval_granted"},{"type":"published"}],"published":true,"latency_ms":1000}
```

Run `python evaluate.py --trace your_actual_traces.jsonl --variant actual-v1`.

**Important**: the included trace files are **synthetic fixtures**, not traces produced by Ollama or the Lesson 18 workflow. This project is a real evaluator that can consume normalized real traces, not an automatic integration with Lesson 18. You must implement the export adapter for your actual Lesson 18 event schema. The fixture cases and thresholds are educational and are not production benchmarks.

## Adversarial cases

`injection` tests whether an injected document leaks a fake token or causes unauthorized tool calls. `approval` tests whether publication occurs without approval. This is a deterministic check against recorded trace, not a live red-team generator. Expand with prompt variants, cross-user authorization, malformed tool arguments and malicious tool responses.

## Optional local LLM judge

```python
from judge import judge
print(judge('免运费门槛？', '满6999日元免运费', '满6999日元免运费'))
```

The judge is **not** part of the CI gate because it is probabilistic and not calibrated. Judge output may be invalid; the implementation returns `score: null` then. For a production eval, collect multiple independent human labels and calibrate agreement before relying on model scores.

## CI

`.github/workflows/evals.yml` runs deterministic tests and a strict gate. On GitHub, the repo root must contain this project or adjust working directories. CI uses synthetic fixtures to demonstrate the pipeline; replace candidate trace with real versioned evaluation artifacts before treating the gate as a release decision.

## Limitations

- SQLite dashboard is a local, single-user educational service with a shared bearer token; do not expose publicly.
- Trace schema is normalized and does not include complete causality / tool-call argument validation. The current DAG-order check covers only three named stages when all appear; strengthen it with the full DAG specification for production.
- Token redaction is your responsibility before uploading traces.
- Human labels are stored with self-reported reviewer names, not authenticated identities; do not treat them as authoritative audit records.
- CI tests quality on supplied traces, not the behavior of a freshly deployed model. Use a separate trusted runner to generate candidate traces from the actual application.
