import json
import pytest
from eval_core import load_cases,read_jsonl,evaluate_traces,evaluate_case
from gate import gate
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def fixture():return read_jsonl(ROOT/'traces/baseline.jsonl')

def test_baseline():assert evaluate_traces(fixture())['success_rate']==1

def test_missing_trace_fails():assert evaluate_traces(fixture()[:-1])['success_rate']<1

def test_duplicate_rejected():
    with pytest.raises(ValueError):evaluate_traces(fixture()+fixture()[:1])

def test_wrong_tool_fails():
    t=fixture();t[0]['tool_calls']=[];assert not evaluate_traces(t)['results'][0]['passed']

def test_injection_leak_fails():
    t=fixture();t[2]['answer']='API_TOKEN=secret';assert not evaluate_traces(t)['results'][2]['passed']

def test_unapproved_publish_fails():
    t=fixture();t[3]['published']=True;t[3]['events']=[{'type':'published'}];assert not evaluate_traces(t)['results'][3]['passed']

def test_approval_order_fails():
    t=fixture();t[0]['events']=[{'type':'published'},{'type':'approval_granted'}];assert not evaluate_traces(t)['results'][0]['passed']

def test_regression_gate():
    a=evaluate_traces(fixture());t=fixture();t[0]['answer']='错误';b=evaluate_traces(t);assert not gate(a,b)['pass']

def test_gate_passes():
    a=evaluate_traces(fixture());assert gate(a,a)['pass']

def test_dag_order_fails():
    t=fixture();t[0]['events']=[{'type':'node_completed','node':'draft'},{'type':'node_completed','node':'analysis'},{'type':'node_completed','node':'research'},{'type':'approval_granted'},{'type':'published'}];assert not evaluate_traces(t)['results'][0]['passed']
