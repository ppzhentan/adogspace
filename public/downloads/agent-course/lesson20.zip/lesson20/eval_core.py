"""Deterministic, fail-closed trace evaluation. Python 3.10+."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding='utf-8').splitlines() if line.strip()]


def load_cases():
    return {x['id']: x for x in read_jsonl(ROOT / 'evals/cases.jsonl')}


def evaluate_case(case, trace):
    answer = str(trace.get('answer', ''))
    calls = trace.get('tool_calls', [])
    events = trace.get('events', [])
    sources = trace.get('sources', [])
    if not isinstance(calls, list) or not isinstance(events, list) or not isinstance(sources, list):
        raise ValueError('Invalid trace collections')
    names = [e.get('type') for e in events if isinstance(e, dict)]
    approved_before_publish = ('published' not in names or
        ('approval_granted' in names and names.index('approval_granted') < names.index('published')))
    checks = {
        'tools': calls == case['expected_tools'],
        'required_facts': all(x in answer for x in case['required']),
        'forbidden_claims': not any(x in answer for x in case['forbidden']),
        'sources': all(x in sources for x in case['required_sources']),
        'publish_policy': bool(trace.get('published', False)) == case['expect_publish'] and approved_before_publish,
        'no_unauthorized_tools': all(c.get('name') in {'read_document'} for c in calls if isinstance(c, dict)),
        'dag_order': _dag_order(events),
    }
    return {'case_id': case['id'], 'category': case['category'], 'passed': all(checks.values()),
            'score': sum(checks.values()) / len(checks), 'checks': checks,
            'latency_ms': trace.get('latency_ms')}


def _dag_order(events):
    done = [e.get('node') for e in events if isinstance(e, dict) and e.get('type') == 'node_completed']
    order = ['research', 'analysis', 'draft']
    return all(done.index(a) < done.index(b) for a,b in zip(order,order[1:]) if a in done and b in done)


def evaluate_traces(traces, cases=None):
    cases = cases or load_cases()
    by_id = {}
    for trace in traces:
        cid = trace.get('case_id')
        if cid in by_id:
            raise ValueError('Duplicate trace case_id: ' + str(cid))
        by_id[cid] = trace
    unknown = set(by_id) - set(cases)
    if unknown:
        raise ValueError('Unknown case IDs: ' + str(sorted(unknown)))
    results = []
    for cid, case in cases.items():
        if cid not in by_id:
            results.append({'case_id': cid, 'category': case['category'], 'passed': False,
                            'score': 0, 'checks': {'trace_present': False}, 'latency_ms': None})
        else:
            results.append(evaluate_case(case, by_id[cid]))
    return {'total': len(results), 'passed': sum(x['passed'] for x in results),
            'success_rate': sum(x['passed'] for x in results) / max(len(results), 1), 'results': results}
