"""Run: uvicorn server:app --host 127.0.0.1 --port 8000"""
import os
import uuid
from contextlib import asynccontextmanager
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool
from agent import run_agent
from security import Denied, check_rate, grant_export, init_db, verify_token

@asynccontextmanager
async def lifespan(app):
    if not os.environ.get("AGENT_API_TOKEN"):
        raise RuntimeError("Set AGENT_API_TOKEN before starting")
    init_db()
    yield

app = FastAPI(title="Lesson 15 Secure Agent", lifespan=lifespan)

async def principal(authorization: str = Header(default="")) -> str:
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not verify_token(token):
        raise HTTPException(401, "unauthorized")
    return "demo-user"

class ChatBody(BaseModel):
    question: str = Field(min_length=1, max_length=1500)

class ApprovalBody(BaseModel):
    filename: str = Field(min_length=1, max_length=80)

@app.get("/health")
def health():
    return {"ok":True}

@app.post("/api/chat")
async def chat(body: ChatBody, user: str = Depends(principal)):
    try:
        check_rate(user)
    except Denied:
        raise HTTPException(429, "rate limit exceeded")
    trace = str(uuid.uuid4())
    try:
        return await run_in_threadpool(run_agent, body.question, user, trace)
    except Exception:
        # Don't leak internal stack traces to the API caller.
        raise HTTPException(503, f"agent unavailable; trace_id={trace}")

@app.post("/api/approvals/export")
async def approve(body: ApprovalBody, user: str = Depends(principal)):
    # In production this MUST be a separate authenticated user confirmation
    # flow with CSRF protections, audit logs and fine-grained permissions.
    try:
        check_rate(user)
        approval = grant_export(user, body.filename)
    except Denied as exc:
        raise HTTPException(400, str(exc))
    return {"approval":approval,"expires_in_seconds":120,"filename":body.filename}
