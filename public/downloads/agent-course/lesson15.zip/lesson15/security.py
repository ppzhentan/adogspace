"""Deterministic security boundaries. No model decisions are trusted here."""
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DOCS = ROOT / "docs"
SANDBOX = ROOT / "sandbox"
DB = Path(os.environ.get("AGENT_DB_PATH", str(ROOT / "security.db")))
MAX_DOC_BYTES = 128_000

class Denied(Exception):
    pass


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def verify_token(candidate: str) -> bool:
    expected = os.environ.get("AGENT_API_TOKEN", "")
    return bool(expected) and hmac.compare_digest(token_hash(candidate), token_hash(expected))


def init_db():
    with sqlite3.connect(DB, timeout=10) as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("CREATE TABLE IF NOT EXISTS rate_events (id INTEGER PRIMARY KEY, principal TEXT NOT NULL, ts REAL NOT NULL)")
        con.execute("CREATE INDEX IF NOT EXISTS ix_rate ON rate_events(principal, ts)")
        con.execute("CREATE TABLE IF NOT EXISTS approvals (id TEXT PRIMARY KEY, principal TEXT NOT NULL, target TEXT NOT NULL, expires REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0)")


def check_rate(principal: str, limit: int = 8, window: int = 60):
    """SQLite transactional fixed-window-like rolling limiter, single-host demo."""
    now = time.time()
    with sqlite3.connect(DB, timeout=10, isolation_level=None) as con:
        con.execute("BEGIN IMMEDIATE")
        con.execute("DELETE FROM rate_events WHERE ts < ?", (now-window,))
        count = con.execute("SELECT COUNT(*) FROM rate_events WHERE principal=?", (principal,)).fetchone()[0]
        if count >= limit:
            con.execute("COMMIT")
            raise Denied("rate_limit_exceeded")
        con.execute("INSERT INTO rate_events(principal,ts) VALUES(?,?)", (principal, now))
        con.execute("COMMIT")


def safe_path(base: Path, filename: str) -> Path:
    """Only one simple filename; reject traversal, separators, symlinks and dotfiles."""
    if not isinstance(filename, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", filename):
        raise Denied("invalid_filename")
    if filename.startswith(".") or ".." in filename or "/" in filename or "\\" in filename:
        raise Denied("invalid_filename")
    base.mkdir(parents=True, exist_ok=True)
    path = base / filename
    if path.is_symlink() or not path.resolve().is_relative_to(base.resolve()):
        raise Denied("unsafe_path")
    return path


def read_document(filename: str) -> dict:
    path = safe_path(DOCS, filename)
    if path.suffix.lower() not in {".md", ".txt"}:
        raise Denied("unsupported_extension")
    if not path.is_file():
        raise Denied("document_not_found")
    if path.stat().st_size > MAX_DOC_BYTES:
        raise Denied("document_too_large")
    return {"filename": filename, "content": path.read_text(encoding="utf-8")}


def grant_export(principal: str, target: str) -> str:
    safe_path(SANDBOX, target)
    if not target.endswith(".txt"):
        raise Denied("unsupported_extension")
    approval = secrets.token_urlsafe(24)
    with sqlite3.connect(DB) as con:
        con.execute("INSERT INTO approvals(id,principal,target,expires) VALUES(?,?,?,?)", (token_hash(approval),principal,target,time.time()+120))
    return approval


def export_report(principal: str, target: str, content: str, approval: str) -> dict:
    path = safe_path(SANDBOX, target)
    if not target.endswith(".txt") or len(content.encode("utf-8")) > 20_000:
        raise Denied("invalid_export")
    # Consume approval atomically; approval is bound to user and filename.
    with sqlite3.connect(DB, timeout=10, isolation_level=None) as con:
        con.execute("BEGIN IMMEDIATE")
        changed = con.execute("UPDATE approvals SET used=1 WHERE id=? AND principal=? AND target=? AND used=0 AND expires>?", (token_hash(approval),principal,target,time.time())).rowcount
        con.execute("COMMIT")
    if changed != 1:
        raise Denied("approval_required_or_expired")
    # Exclusive creation, no overwrites. O_NOFOLLOW avoids final-component symlink race on POSIX.
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        fd = os.open(path, flags, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
    except FileExistsError:
        raise Denied("file_already_exists")
    return {"saved": target}


def execute_tool(name: str, args: dict, principal: str) -> dict:
    if not isinstance(args, dict):
        raise Denied("invalid_arguments")
    if name == "read_document":
        if set(args) != {"filename"}:
            raise Denied("invalid_arguments")
        return read_document(args["filename"])
    if name == "export_report":
        if set(args) != {"filename", "content", "approval"}:
            raise Denied("invalid_arguments")
        return export_report(principal, args["filename"], args["content"], args["approval"])
    raise Denied("tool_not_allowed")
