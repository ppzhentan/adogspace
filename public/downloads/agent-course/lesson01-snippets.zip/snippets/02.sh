ollama run qwen3-local
