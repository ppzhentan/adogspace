pip install -U openai
