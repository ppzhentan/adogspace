
from openai import OpenAI

# 连接本地 Ollama
client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama"
)

# 调用本地 Qwen3
response = client.chat.completions.create(
    model="qwen3-local",
    messages=[
        {
            "role": "system",
            "content": "你是一个专业的中文 AI 助手。"
        },
        {
            "role": "user",
            "content": "什么是 Function Calling？"
        }
    ]
)

print(response.choices[0].message.content)
