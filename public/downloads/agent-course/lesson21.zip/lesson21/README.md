# Lesson 21 · AI Operations Workspace

教学用、可本地部署的 AI Agent SaaS MVP，使用本地 Ollama `qwen3-local` 和可选 `embeddinggemma`。不使用付费 API。

## 本地启动

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama list
uvicorn server:app --host 127.0.0.1 --port 8000 --workers 1
```

浏览器访问 http://127.0.0.1:8000 ，注册（密码至少 12 位）、登录、添加文档、创建任务、查看进度、审批报告。

推荐先安装 `ollama pull embeddinggemma`。若 embedding 不可用，会回退为简单词汇匹配。模型调用需要本地 Ollama 服务可用。

## Docker

```bash
docker compose up --build -d
```

Docker 容器通过 `host.docker.internal:11434` 访问宿主机 Ollama。macOS 上需确认 Ollama 对容器可达。容器端口仅绑定 127.0.0.1。

## 测试

```bash
python -m pytest -q
```

## API

- POST `/api/register`, `/api/login`
- GET/POST `/api/documents`
- GET/POST `/api/jobs`
- GET `/api/jobs/{id}`, `/api/jobs/{id}/events`, `/api/jobs/{id}/stream`, `/api/jobs/{id}/evaluation`
- POST `/api/jobs/{id}/approve`, `/reject`, `/cancel`

所有业务 API 要求 Bearer token；资源按 user_id 隔离。登录 token 有效期 24 小时，存储 SHA-256 摘要。注册/登录端点未设置独立防暴力破解限制，仅适用于本地可信环境。

## 真实实现与边界

- **Agent**: research(检索) → analysis → writer → reviewer → waiting_approval → published。模型角色分工真实调用 Ollama，但并非动态规划/并行 DAG；是固定依赖链。
- **RAG**: 每用户最多检索 100 份文档，优先使用 `embeddinggemma` 余弦相似度；失败时回退简单词汇匹配。为简化教学，文档按整篇嵌入（截断到 8000 字符），未实现分块索引、增量批处理、混合检索。
- **持久化**: SQLite 保存用户、文档、任务、事件、评估、审批状态。崩溃时 running 状态保留，但不自动恢复。
- **人工审批**: 服务端状态机严格限制审批；批准操作代表登录用户同意，不具备审批人角色分离或不可抵赖审计。
- **Evals**: 来源文件名覆盖率和 reviewer 文本记录；**不是**严格的事实性或 Golden Dataset 回归评估。可接入第 20 课的 eval_core/gate 实现完整 CI 评估。
- **取消**: 通过 DB 标记协作式取消；不能强行中断 Ollama 端已开始的推理。
- **安全**: 密码 scrypt、随机 Token、token 哈希、按用户限流、资源归属验证。无 HTTPS、密码重置、邮件验证、MFA、RBAC、计费、管理员功能、跨进程 lease/heartbeat；不可直接公网暴露。
- **部署**: 单 worker、单机、127.0.0.1 监听。上线前应使用反向代理 TLS、独立队列/Worker、PostgreSQL、密钥管理、完整日志/监控和安全测试。

## 学习任务

1. 注册两个账号，验证跨用户知识库与任务隔离。
2. 上传 shipping.md / returns.md 两份真实或虚构政策文档。
3. 创建分析任务，观察 research、analysis、writer、reviewer 事件。
4. 检查来源覆盖率、Reviewer 反馈，再人工审批。
5. 在 Ollama 停止时创建任务，观察 failed 状态和错误日志。
6. 修改 Prompt，再将真实 Trace 接入第 20 课的回归测试。
