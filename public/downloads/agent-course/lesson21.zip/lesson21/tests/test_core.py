import os, tempfile, unittest
from unittest.mock import patch
import core
class TestCore(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=core.DB;core.DB=self.tmp.name+'/test.db';core.init()
        self.u=core.register('a@example.com','very-secure-pass-123')
        self.v=core.register('b@example.com','very-secure-pass-456')
    def tearDown(self):core.DB=self.old;self.tmp.cleanup()
    def test_login(self):
        t=core.login('a@example.com','very-secure-pass-123');self.assertEqual(core.identify(t),self.u)
        self.assertIsNone(core.login('a@example.com','wrong'))
    def test_duplicate(self):
        with self.assertRaises(Exception):core.register('a@example.com','very-secure-pass-123')
    def test_tenant_docs(self):
        core.add_doc(self.u,'a.md','test body');self.assertEqual(len(core.docs(self.v)),0)
    def test_tenant_jobs(self):
        j=core.create_job(self.u,'analyze');self.assertIsNone(core.job(self.v,j))
        self.assertIsNone(core.events(self.v,j))
    def test_approval_guard(self):
        j=core.create_job(self.u,'analyze');self.assertFalse(core.decide(self.u,j,True))
        core.update(j,status='waiting_approval');self.assertFalse(core.decide(self.v,j,True));self.assertTrue(core.decide(self.u,j,True))
    def test_cancel_guard(self):
        j=core.create_job(self.u,'analyze');self.assertFalse(core.cancel(self.v,j));self.assertTrue(core.cancel(self.u,j));self.assertFalse(core.decide(self.u,j,True))
    def test_rate(self):
        self.assertTrue(core.rate_limit(self.u,limit=1));self.assertFalse(core.rate_limit(self.u,limit=1))
    def test_doc_validation(self):
        with self.assertRaises(ValueError):core.add_doc(self.u,'../bad','abc')
    def test_event_scope(self):
        j=core.create_job(self.u,'analyze');self.assertEqual(core.events(self.u,j)[0]['kind'],'created')
if __name__=='__main__':unittest.main()
