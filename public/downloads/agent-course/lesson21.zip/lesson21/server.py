import asyncio, json, os, sqlite3
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel, Field
import core

running={}
@asynccontextmanager
async def lifespan(app):
    core.init()
    # Recovery is explicit; do not auto-replay incomplete LLM calls.
    yield
    for t in running.values():t.cancel()

app=FastAPI(title='Lesson 21 - AI Operations Workspace',lifespan=lifespan)
class Credentials(BaseModel):
    email:str
    password:str
class Document(BaseModel):
    name:str
    body:str
class Job(BaseModel):
    goal:str=Field(min_length=1,max_length=2000)

def user(authorization:str|None=Header(default=None)):
    token=authorization[7:] if authorization and authorization.startswith('Bearer ') else ''
    uid=core.identify(token)
    if not uid:raise HTTPException(401,'Invalid token')
    if not core.rate_limit(uid):raise HTTPException(429,'Rate limit exceeded',headers={'Retry-After':'60'})
    return uid

@app.get('/',response_class=HTMLResponse)
def home():return open('static/index.html',encoding='utf8').read()
@app.get('/health')
def health():return {'ok':True,'model':core.MODEL}
@app.post('/api/register')
def register(c:Credentials):
    try:return {'user_id':core.register(c.email,c.password)}
    except sqlite3.IntegrityError:raise HTTPException(409,'Email already registered')
    except ValueError as e:raise HTTPException(422,str(e))
@app.post('/api/login')
def login(c:Credentials):
    token=core.login(c.email,c.password)
    if not token:raise HTTPException(401,'Invalid credentials')
    return {'token':token,'expires_in':86400}
@app.get('/api/documents')
def documents(uid=Depends(user)):return core.docs(uid)
@app.post('/api/documents')
def add_doc(d:Document,uid=Depends(user)):
    try:return {'id':core.add_doc(uid,d.name,d.body)}
    except ValueError as e:raise HTTPException(422,str(e))
@app.get('/api/jobs')
def jobs(uid=Depends(user)):return core.jobs(uid)
@app.post('/api/jobs')
def create_job(d:Job,uid=Depends(user)):
    jid=core.create_job(uid,d.goal)
    task=asyncio.create_task(core.run_job(uid,jid))
    running[jid]=task
    task.add_done_callback(lambda _:running.pop(jid,None))
    return {'id':jid}
@app.get('/api/jobs/{jid}')
def job(jid:str,uid=Depends(user)):
    j=core.job(uid,jid)
    if not j:raise HTTPException(404,'Not found')
    return j
@app.get('/api/jobs/{jid}/events')
def events(jid:str,since:int=0,uid=Depends(user)):
    rows=core.events(uid,jid,since)
    if rows is None:raise HTTPException(404,'Not found')
    return rows
@app.get('/api/jobs/{jid}/stream')
async def stream(jid:str,request:Request,uid=Depends(user)):
    if not core.job(uid,jid):raise HTTPException(404,'Not found')
    async def generate():
        cursor=0
        for _ in range(120):
            if await request.is_disconnected():break
            rows=core.events(uid,jid,cursor) or []
            for r in rows:
                cursor=r['id']
                yield f"id: {cursor}\ndata: {json.dumps(r,ensure_ascii=False)}\n\n"
            await asyncio.sleep(1)
    return StreamingResponse(generate(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})
@app.post('/api/jobs/{jid}/approve')
def approve(jid:str,uid=Depends(user)):
    if not core.job(uid,jid):raise HTTPException(404,'Not found')
    if not core.decide(uid,jid,True):raise HTTPException(409,'Not awaiting approval')
    return {'status':'completed'}
@app.post('/api/jobs/{jid}/reject')
def reject(jid:str,uid=Depends(user)):
    if not core.job(uid,jid):raise HTTPException(404,'Not found')
    if not core.decide(uid,jid,False):raise HTTPException(409,'Not awaiting approval')
    return {'status':'rejected'}
@app.post('/api/jobs/{jid}/cancel')
def cancel(jid:str,uid=Depends(user)):
    if not core.job(uid,jid):raise HTTPException(404,'Not found')
    if not core.cancel(uid,jid):raise HTTPException(409,'Already terminal')
    return {'status':'cancelled'}
@app.get('/api/jobs/{jid}/evaluation')
def evaluation(jid:str,uid=Depends(user)):
    if not core.job(uid,jid):raise HTTPException(404,'Not found')
    with core.conn() as c:r=c.execute('SELECT * FROM evaluations WHERE job_id=?',(jid,)).fetchone()
    return dict(r) if r else {'status':'pending'}
