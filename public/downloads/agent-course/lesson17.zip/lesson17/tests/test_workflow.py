import os
import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import workflow as wf

@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setattr(wf, 'DB', tmp_path / 'test.sqlite3')
    monkeypatch.setattr(wf, 'OUTPUTS', tmp_path / 'outputs')

def test_dag_valid():
    assert wf.validate_dag(wf.NODES)

def test_dag_cycle():
    with pytest.raises(ValueError, match='cycle'):
        wf.validate_dag({'a': {'deps': ['b']}, 'b': {'deps': ['a']}})

def test_dag_missing_dependency():
    with pytest.raises(ValueError, match='missing'):
        wf.validate_dag({'a': {'deps': ['missing']}})

def test_persistence_and_claim():
    wid = wf.start('test')
    assert wf.snapshot(wid)[0]['status'] == 'pending'
    assert wf.claim(wid, 'research_shipping')
    assert not wf.claim(wid, 'research_shipping')
    wf.finish(wid, 'research_shipping', {'source': 'shipping.md'})
    assert wf.snapshot(wid)[1]['research_shipping']['status'] == 'completed'

def test_recovery_keeps_completed():
    wid = wf.start('test')
    assert wf.claim(wid, 'research_shipping')
    wf.finish(wid, 'research_shipping', {'ok': True})
    assert wf.claim(wid, 'research_returns')
    wf.reset(wid)
    tasks = wf.snapshot(wid)[1]
    assert tasks['research_shipping']['status'] == 'completed'
    assert tasks['research_returns']['status'] == 'pending'

def test_no_approval_before_waiting():
    wid = wf.start('test')
    with pytest.raises(ValueError, match='not awaiting'):
        wf.approve(wid, 'approved', 'alice')

def test_approval_and_rejection():
    wid = wf.start('test')
    with wf.connect() as con:
        con.execute("UPDATE workflows SET status='waiting_approval' WHERE id=?", (wid,))
        con.execute("UPDATE tasks SET status='waiting_approval' WHERE workflow_id=? AND node='approval'", (wid,))
    wf.approve(wid, 'rejected', 'alice')
    w, tasks, approval = wf.snapshot(wid)
    assert w['status'] == 'rejected'
    assert tasks['approval']['status'] == 'rejected'
    assert approval['reviewer'] == 'alice'
    with pytest.raises(ValueError):
        wf.approve(wid, 'approved', 'alice')

def test_publish_needs_approval():
    import asyncio
    wid = wf.start('test')
    with pytest.raises(PermissionError):
        asyncio.run(wf.execute('publish', wid, 'test', {}, None))
