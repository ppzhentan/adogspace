# 第十七课：持久化 DAG + 并行执行 + 人工审批

本项目使用 **本地 Ollama `qwen3-local`**，无付费 API。依赖仅 `openai`（调用 Ollama 的 OpenAI 兼容接口）与 `pytest`。

## 环境

- Python 3.10+
- 已启动 Ollama，`ollama list` 能看到 `qwen3-local`
- macOS / Linux

```bash
cd lesson17
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama list
```

如本地模型名称不同：`export OLLAMA_MODEL=你的模型名`。如 Ollama 地址不同：`export OLLAMA_URL=http://127.0.0.1:11434/v1`。

## 完整操作

**1. 创建工作流**

```bash
python workflow.py start "分析日本站配送、退货与支付政策，提出3项值得测试的改进，并注明证据来源"
```

复制输出的 UUID（下文用 `<ID>` 表示）。

**2. 执行工作流**

```bash
python workflow.py run <ID>
```

三个 Researcher 并行调用本地 Ollama；Analyst 等三个任务完成；Writer 生成草稿；调度器暂停在 `waiting_approval`。

**3. 查看草稿**

```bash
python workflow.py show <ID>
```

**4a. 人工批准后继续发布**

```bash
python workflow.py approve <ID> --reviewer alice
python workflow.py run <ID>
```

报告位于 `outputs/<ID>.md`。

**4b. 或拒绝**

```bash
python workflow.py reject <ID> --reviewer alice
```

拒绝后工作流终止，无法发布。

## 恢复失败或崩溃的工作流

先确保旧的 `python workflow.py run <ID>` **已经停止**，然后：

```bash
python workflow.py show <ID>
python workflow.py resume <ID>
python workflow.py run <ID>
```

`resume` 会将 `running` / `failed` 节点恢复为 `pending`，但保留已完成节点的结果，因此无需重新运行成功的节点。

> **重要限制：** 本课的恢复是人工触发，适合**单实例调度器**。不要同时对同一工作流启动多个 runner；没有租约、fencing token 或跨进程分布式锁。数据库事务防止重复领取同一节点，但尚不保证多个调度器下的完整 DAG 调度正确性。`publish` 使用同一工作流 ID 的固定文件名并原子替换，但外部发邮件、支付等操作仍需独立幂等机制。`approve --reviewer` 只是教学模拟，并不提供身份认证；正式系统需要登录、权限检查、审计和审批人绑定。

## 运行测试

```bash
python -m pytest -q
```

8 个测试均无需 Ollama，验证 DAG 环、缺失依赖、持久化、任务原子领取、恢复保留结果、审批前置条件、拒绝和发布权限。

## 代码导读

- `NODES`: 固定 DAG 定义与依赖关系
- `validate_dag()`: DFS 检测环和不存在的依赖
- `start()`: SQLite 创建工作流及任务 Checkpoint
- `run()`: 查找依赖满足的节点，`asyncio.gather()` 并发调度
- `claim()`: SQLite 原子任务领取
- `finish()` / `fail()`: 持久化任务结果及错误
- `reset()`: 人工恢复中断任务，保留已完成任务
- `approve()`: 人工决策入库；批准后才允许发布
- `execute()`: Researcher / Analyst / Writer / Publisher 执行逻辑

## 练习

1. 观察三个 Researcher 的 `START` 日志是否在任意一个 `DONE` 前输出。
2. 工作流暂停审批时关闭终端，再执行 `show`，验证草稿仍在。
3. 不批准直接运行，验证不能发布。
4. 人工拒绝，验证工作流进入 `rejected`。
5. 停止 Ollama 触发失败，重启 Ollama 后 `resume`，验证已完成节点不会重做。
6. 扩展一个 `review` 节点，并使 `approval` 依赖 `review`，为发布增加模型审查步骤。

## 生产化下一步

本课是理解调度器的最小工程：没有自动租约恢复、任务重试上限、队列优先级、分布式 Worker、真正的身份认证、审批通知、生产级观测，也没有对同一模型服务的并发吞吐量承诺。下课可结合第十四课的 Lease / Heartbeat 和第十五课的鉴权做进一步集成。
