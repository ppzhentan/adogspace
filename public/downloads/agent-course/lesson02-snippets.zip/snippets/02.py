
import json
from openai import OpenAI

# 1. 连接本地 Qwen3
client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama"
)

MODEL = "qwen3-local"


# 2. 定义真正的 Python 函数
def calculate_difference(a: float, b: float):
    print(f"正在执行 Python 函数：{a} 和 {b}")
    return abs(a - b)


# 3. 告诉 AI 有哪些工具可以使用
tools = [
    {
        "type": "function",
        "function": {
            "name": "calculate_difference",
            "description": "计算两个数字之间的绝对差值",
            "parameters": {
                "type": "object",
                "properties": {
                    "a": {
                        "type": "number",
                        "description": "第一个数字"
                    },
                    "b": {
                        "type": "number",
                        "description": "第二个数字"
                    }
                },
                "required": ["a", "b"]
            }
        }
    }
]


# 4. 用户提问
messages = [
    {
        "role": "user",
        "content": "北京15度，东京22度，相差多少度？请使用工具计算。"
    }
]


# 5. 第一次调用 AI
response = client.chat.completions.create(
    model=MODEL,
    messages=messages,
    tools=tools,
    tool_choice="auto"
)

message = response.choices[0].message

# 6. 判断 AI 是否决定调用工具
if message.tool_calls:

    messages.append(message)

    for tool_call in message.tool_calls:

        function_name = tool_call.function.name

        arguments = json.loads(
            tool_call.function.arguments
        )

        print("AI 选择的工具：", function_name)
        print("AI 提供的参数：", arguments)

        if function_name == "calculate_difference":
            result = calculate_difference(
                arguments["a"],
                arguments["b"]
            )
        else:
            result = "未知工具"

        # 7. 把函数结果返回给 AI
        messages.append({
            "role": "tool",
            "tool_call_id": tool_call.id,
            "content": str(result)
        })

    # 8. 第二次调用 AI，生成最终回答
    final_response = client.chat.completions.create(
        model=MODEL,
        messages=messages
    )

    print("\nAI 最终回答：")
    print(final_response.choices[0].message.content)

else:
    print("AI 没有调用工具：")
    print(message.content)
