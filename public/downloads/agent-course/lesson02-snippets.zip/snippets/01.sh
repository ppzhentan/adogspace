ollama list
