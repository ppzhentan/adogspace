# Lesson 12: FastAPI + SSE + Web Chat

Requires Python 3.10+ and Ollama models `qwen3-local` and `embeddinggemma`.

```bash
python -m pip install -r requirements.txt
python rag_core.py index
uvicorn server:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs.

Endpoints:
- `GET /health`
- `POST /api/chat` body `{"question":"..."}`
- `POST /api/chat/stream` same JSON body; returns SSE events `sources`, `delta`, `done`, `error`.

The pipeline reuses lesson 11 hybrid retrieval and LLM reranking. Reranking happens **before** streaming, so the first token can be delayed. This educational server is localhost-only, has no authentication, and must not be exposed directly to the Internet. One request does not retain conversation state.
