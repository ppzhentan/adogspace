
from mcp.server import MCPServer

# 创建 MCP Server
mcp = MCPServer("MyFirstMCP")


@mcp.tool()
def calculate_profit(
    price: float,
    cost: float,
    shipping: float
) -> dict:
    """计算商品利润和利润率。

    Args:
        price: 商品售价
        cost: 商品采购成本
        shipping: 商品物流成本
    """
    if price <= 0:
        return {"error": "售价必须大于0"}

    profit = price - cost - shipping
    margin = profit / price * 100

    return {
        "profit": round(profit, 2),
        "margin": round(margin, 2)
    }


@mcp.tool()
def get_product(product_id: str) -> dict:
    """根据商品编号查询商品信息。"""

    products = {
        "P001": {
            "name": "女士针织衫",
            "price": 299,
            "cost": 120,
            "shipping": 25
        },
        "P002": {
            "name": "女士连衣裙",
            "price": 399,
            "cost": 180,
            "shipping": 35
        }
    }

    return products.get(
        product_id,
        {"error": "商品不存在"}
    )
