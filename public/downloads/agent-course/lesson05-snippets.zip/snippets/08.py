
import asyncio
from mcp import Client
from server import mcp


async def main():
    async with Client(mcp) as client:

        # 1. 自动发现工具
        result = await client.list_tools()

        print("发现的 MCP 工具：")
        for tool in result.tools:
            print("-", tool.name)
            print("  参数：", tool.input_schema)

        # 2. 调用商品查询工具
        product = await client.call_tool(
            "get_product",
            {"product_id": "P001"}
        )

        print("\n商品查询结果：")
        print(product.structured_content or product.content)

        # 3. 调用利润计算工具
        profit = await client.call_tool(
            "calculate_profit",
            {
                "price": 299,
                "cost": 120,
                "shipping": 25
            }
        )

        print("\n利润计算结果：")
        print(profit.structured_content or profit.content)


if __name__ == "__main__":
    asyncio.run(main())
