python -m pip show mcp
