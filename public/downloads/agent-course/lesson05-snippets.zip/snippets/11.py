
import asyncio
import json

from mcp import Client
from openai import AsyncOpenAI
from server import mcp

MODEL = "qwen3-local"

llm = AsyncOpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama",
    timeout=120.0
)


async def run_agent(task: str, max_steps=8):

    # 连接 MCP Server
    async with Client(mcp) as mcp_client:

        # 自动发现 MCP 工具
        result = await mcp_client.list_tools()
        available = {t.name: t for t in result.tools}

        # 将 MCP 工具转换为 OpenAI 工具格式
        tools = [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description or "",
                    "parameters": tool.input_schema
                }
            }
            for tool in result.tools
        ]

        print("发现工具：", list(available))

        messages = [
            {
                "role": "system",
                "content": (
                    "你是中文电商数据分析助手。"
                    "必须使用工具查询商品和计算利润。"
                    "不要编造商品数据。"
                    "先查询商品，再根据返回数据计算。"
                    "如工具失败，明确报告错误。"
                )
            },
            {
                "role": "user",
                "content": task
            }
        ]

        # Agent Loop
        for step in range(max_steps):

            print(f"\n===== 第 {step + 1} 轮 =====")

            response = await llm.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                temperature=0
            )

            message = response.choices[0].message
            messages.append(message.model_dump(
                exclude_none=True
            ))

            # 没有工具调用，返回最终答案
            if not message.tool_calls:
                print("\n最终回答：")
                print(message.content or "没有返回文本")
                return message.content

            # 执行模型请求的工具
            for call in message.tool_calls:

                name = call.function.name
                print("调用 MCP 工具：", name)

                try:
                    args = json.loads(
                        call.function.arguments
                    )

                    if name not in available:
                        output = {
                            "error": "未知或未授权的工具"
                        }

                    elif not isinstance(args, dict):
                        output = {
                            "error": "参数必须是JSON对象"
                        }

                    else:
                        print("参数：", args)

                        tool_result = await mcp_client.call_tool(
                            name,
                            args
                        )

                        if tool_result.is_error:
                            output = {
                                "error": [
                                    block.model_dump(mode="json")
                                    for block in tool_result.content
                                ]
                            }
                        else:
                            output = (
                                tool_result.structured_content
                                if tool_result.structured_content
                                is not None
                                else [
                                    block.model_dump(mode="json")
                                    for block in tool_result.content
                                ]
                            )

                except (ValueError, TypeError) as e:
                    output = {"error": str(e)}
                except Exception as e:
                    output = {
                        "error": f"工具调用失败: {e}"
                    }

                print("工具结果：", output)

                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps(
                        output,
                        ensure_ascii=False
                    )
                })

        print("达到最大执行轮数")
        return None


async def main():
    await run_agent(
        "查询商品P001和P002，"
        "分别计算利润和利润率，"
        "比较哪个商品利润率更高。"
    )


if __name__ == "__main__":
    asyncio.run(main())
