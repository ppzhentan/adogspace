def get_product(product_id: str) -> dict:
