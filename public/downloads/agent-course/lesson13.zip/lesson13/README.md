# Lesson 13 — Multi-user RAG API

## 本机运行

```bash
python -m pip install -r requirements.txt
python create_user.py alice
python worker.py             # terminal A
uvicorn server:app --host 127.0.0.1 --port 8000  # terminal B
```

Use the printed bearer token in the browser at http://127.0.0.1:8000 . Click **新建会话**.

Build the knowledge index using the authenticated endpoint:

```bash
export TOKEN='paste-your-token-here'
curl -X POST http://127.0.0.1:8000/api/jobs/reindex -H "Authorization: Bearer $TOKEN"
# Query returned job ID:
curl http://127.0.0.1:8000/api/jobs/JOB_ID -H "Authorization: Bearer $TOKEN"
```

## Docker (macOS + host Ollama)

First make sure the host Ollama server is reachable from Docker. `host.docker.internal` is the host address inside Docker Desktop. By default Ollama may listen only on 127.0.0.1 and be inaccessible from a container. Configure Ollama to listen on an appropriate host interface, with host firewall restrictions, before starting containers. Do not expose Ollama to the public internet.

```bash
docker compose build
docker compose run --rm api python create_user.py alice
docker compose up -d
docker compose logs -f worker
```

Open http://127.0.0.1:8000 and paste your token.

## API
- GET `/health` (public)
- POST `/api/sessions` (auth)
- GET `/api/sessions` (auth)
- GET `/api/sessions/{id}/messages` (auth)
- POST `/api/sessions/{id}/chat` body `{"question":"..."}` (auth)
- POST `/api/sessions/{id}/stream` same body, SSE (auth)
- POST `/api/jobs/reindex` (auth, **admin-only in production**, not enforced in demo)
- GET `/api/jobs/{id}` (auth)

## Important limits

This is a single-machine educational app, not a public production service. All authenticated users can request a global reindex; add role checks before public deployment. The knowledge base is shared among users; only sessions and jobs are isolated. SQLite queue has no lease/heartbeat recovery for jobs stuck in `running` after a crash. Concurrent chat requests to the same session are not serialized. SSE client disconnects may leave a partial answer unrecorded. No HTTPS, rate limiting, token rotation, quotas, tenant-specific knowledge authorization, or monitoring is included. SQLite + Chroma writes can conflict with simultaneous indexing; schedule indexing during quiet periods. The `index_docs` implementation rebuilds the index for simplicity (Lesson 11 covers incremental indexing). The RAG pipeline uses vector search without the Lesson 11 hybrid/reranker to keep deployment concepts isolated.
