import time, json, traceback
from db import conn,init
from rag import index_docs

def claim():
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute("SELECT id,kind FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
        if row:
            c.execute("UPDATE jobs SET status='running',updated_at=? WHERE id=? AND status='queued'",(time.time(),row['id']))
        return dict(row) if row else None

def finish(jid,status,result=None,error=None):
    with conn() as c:c.execute('UPDATE jobs SET status=?,result=?,error=?,updated_at=? WHERE id=?',(status,json.dumps(result,ensure_ascii=False) if result is not None else None,error,time.time(),jid))

if __name__=='__main__':
    init()
    print('Worker started',flush=True)
    while True:
        job=claim()
        if not job:
            time.sleep(2);continue
        try:
            if job['kind']=='reindex':
                result=index_docs()
            else:raise ValueError('Unknown job type')
            finish(job['id'],'completed',result)
        except Exception as e:
            traceback.print_exc()
            finish(job['id'],'failed',error=str(e))
