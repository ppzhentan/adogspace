import sys,uuid,secrets,hashlib
from db import conn,init
if len(sys.argv)!=2:
    print('Usage: python create_user.py <username>');raise SystemExit(2)
init(); username=sys.argv[1];token=secrets.token_urlsafe(32)
with conn() as c:
    c.execute('INSERT INTO users(id,username,token_hash) VALUES(?,?,?)',(str(uuid.uuid4()),username,hashlib.sha256(token.encode()).hexdigest()))
print('Username:',username)
print('Bearer token (shown once):',token)
print('Save this token securely; it cannot be recovered.')
