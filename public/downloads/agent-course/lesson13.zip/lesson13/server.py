import os, uuid, time, hashlib, hmac, json, asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, Header, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from db import conn,init
from rag import answer,retrieve,stream_answer

@asynccontextmanager
async def lifespan(app):
    init()
    yield
app=FastAPI(title='Lesson 13 RAG API',lifespan=lifespan)

def user(authorization: str | None=Header(default=None)):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Bearer token required')
    token=authorization[7:]
    digest=hashlib.sha256(token.encode()).hexdigest()
    with conn() as c:
        row=c.execute('SELECT id,username FROM users WHERE token_hash=?',(digest,)).fetchone()
    if not row: raise HTTPException(401,'Invalid token')
    return dict(row)

def owned_session(session_id, uid):
    with conn() as c:
        row=c.execute('SELECT id FROM sessions WHERE id=? AND user_id=?',(session_id,uid)).fetchone()
    if not row: raise HTTPException(404,'Session not found')

def history(sid):
    with conn() as c:
        rows=c.execute('SELECT role,content FROM messages WHERE session_id=? ORDER BY id',(sid,)).fetchall()
    return [dict(r) for r in rows]

def save_turn(sid,question,reply):
    with conn() as c:
        c.execute('INSERT INTO messages(session_id,role,content,created_at) VALUES(?,?,?,?)',(sid,'user',question,time.time()))
        c.execute('INSERT INTO messages(session_id,role,content,created_at) VALUES(?,?,?,?)',(sid,'assistant',reply,time.time()))

class Ask(BaseModel):
    question:str=Field(min_length=1,max_length=4000)

@app.get('/health')
def health(): return {'ok':True}

@app.post('/api/sessions')
def create_session(u=Depends(user)):
    sid=str(uuid.uuid4())
    with conn() as c:c.execute('INSERT INTO sessions VALUES(?,?,?)',(sid,u['id'],time.time()))
    return {'session_id':sid}

@app.get('/api/sessions')
def list_sessions(u=Depends(user)):
    with conn() as c: rows=c.execute('SELECT id,created_at FROM sessions WHERE user_id=? ORDER BY created_at DESC',(u['id'],)).fetchall()
    return {'sessions':[dict(x) for x in rows]}

@app.get('/api/sessions/{sid}/messages')
def get_messages(sid:str,u=Depends(user)):
    owned_session(sid,u['id'])
    return {'messages':history(sid)}

@app.post('/api/sessions/{sid}/chat')
async def chat(sid:str,req:Ask,u=Depends(user)):
    owned_session(sid,u['id'])
    prior=history(sid)
    # Blocking Ollama/Chroma calls run in a worker thread.
    text,sources=await asyncio.to_thread(answer,prior,req.question)
    save_turn(sid,req.question,text)
    return {'answer':text,'sources':sources}

def sse(kind,data):return f'event: {kind}\ndata: {json.dumps(data,ensure_ascii=False)}\n\n'

@app.post('/api/sessions/{sid}/stream')
async def chat_stream(sid:str,req:Ask,u=Depends(user)):
    owned_session(sid,u['id'])
    prior=history(sid)
    async def events():
        parts=[]
        try:
            sources=await asyncio.to_thread(retrieve,req.question)
            yield sse('sources',{'sources':sources})
            # Blocking generator runs in a dedicated thread, with bounded backpressure.
            from starlette.concurrency import iterate_in_threadpool
            async for piece in iterate_in_threadpool(stream_answer(prior,req.question,sources)):
                parts.append(piece)
                yield sse('delta',{'text':piece})
            save_turn(sid,req.question,''.join(parts))
            yield sse('done',{})
        except Exception:
            yield sse('error',{'error':'Generation failed; see server logs'})
    return StreamingResponse(events(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

@app.post('/api/jobs/reindex')
def enqueue_index(u=Depends(user)):
    jid=str(uuid.uuid4());t=time.time()
    with conn() as c:c.execute('INSERT INTO jobs(id,user_id,kind,payload,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(jid,u['id'],'reindex','{}','queued',t,t))
    return {'job_id':jid,'status':'queued'}

@app.get('/api/jobs/{jid}')
def job_status(jid:str,u=Depends(user)):
    with conn() as c:row=c.execute('SELECT id,kind,status,result,error FROM jobs WHERE id=? AND user_id=?',(jid,u['id'])).fetchone()
    if not row:raise HTTPException(404,'Job not found')
    return dict(row)

app.mount('/',StaticFiles(directory='static',html=True),name='static')
