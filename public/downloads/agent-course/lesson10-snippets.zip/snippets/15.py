query_vector = embed_texts([query])[0]

result = collection.query(
    query_embeddings=[query_vector],
    n_results=3
)
