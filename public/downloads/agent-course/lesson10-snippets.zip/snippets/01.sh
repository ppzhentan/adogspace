ollama pull embeddinggemma
