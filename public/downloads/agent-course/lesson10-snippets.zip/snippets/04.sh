python -m pip install -U openai ollama chromadb
