python agent.py chat
