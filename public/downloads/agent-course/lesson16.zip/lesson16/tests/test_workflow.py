import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
try:
    import openai
except ImportError:
    import types
    sys.modules["openai"] = types.SimpleNamespace(OpenAI=object)
import agent

def test_fallback_plan(monkeypatch):
    monkeypatch.setattr(agent,'ask_model',lambda *a,**k:'{"steps":[{"id":"hack","agent":"shell","depends_on":[]}]}')
    result=agent.plan('test')
    assert [s['agent'] for s in result]==['researcher','analyst','writer','reviewer']

def test_read_corpus():
    corpus=agent.read_corpus()
    assert any(d['source']=='shipping.md' for d in corpus)

def test_check_sources():
    assert agent.deterministic_checks('a'*101,[{'source':'shipping.md'}])
    assert not agent.deterministic_checks('shipping.md '+'a'*101,[{'source':'shipping.md'}])

def test_review_invalid(monkeypatch):
    monkeypatch.setattr(agent,'ask_model',lambda *a,**k:'{"approved":"yes"}')
    result=agent.reviewer('g','draft',{'sources':[]})
    assert result['approved'] is False

def test_bus():
    bus=agent.Bus()
    bus.send('A','B','task',{'x':1})
    assert bus.events[0].recipient=='B'
