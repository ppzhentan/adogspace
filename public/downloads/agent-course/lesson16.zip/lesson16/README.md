# Lesson 16 — Local Multi-Agent System

A minimal educational Supervisor → Researcher → Analyst → Writer → Reviewer workflow. Uses **only** a local Ollama `qwen3-local` model, no cloud API. Role separation is logical (distinct model calls), not OS process isolation.

## Setup

```bash
ollama list
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python agent.py
```

Ollama OpenAI-compatible endpoint defaults to `http://127.0.0.1:11434/v1`.

Override if needed:

```bash
OLLAMA_MODEL=qwen3-local OLLAMA_URL=http://127.0.0.1:11434/v1 python agent.py "分析物流与退货政策，提出三项改进"
```

## Output

- `outputs/report.md` is written **only after reviewer approval**.
- If review fails after up to 2 revisions, an `outputs/draft_*.md` is saved and the command exits 2.
- `outputs/trace_*.json` contains the full message bus and may include sensitive source text; do not publish it.

## Test

```bash
python -m pytest -q
```

## What to observe

1. Supervisor creates a plan; server enforces the fixed allowed workflow.
2. Researcher reads trusted local document paths, treats content as untrusted.
3. Analyst distinguishes facts from assumptions.
4. Writer composes a cited report.
5. Reviewer returns JSON; server also applies deterministic checks.
6. Failed review triggers at most two revisions; no unapproved report is published.

## Limitations

- No real-time internet research; source documents are local fictional demo policies.
- No cross-agent parallelism, persistent checkpoints, or production-grade trace store.
- LLM reviewer can miss hallucinations; source mention checks do not verify each claim.
- `outputs/trace_*.json` stores full intermediate contents and should be treated as private.
- No arbitrary shell/file tools are exposed to model outputs.
