python client.py
