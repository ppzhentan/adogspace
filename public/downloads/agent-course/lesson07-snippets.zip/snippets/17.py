
async with httpx2.AsyncClient(
    headers={
        "Authorization": f"Bearer {TOKEN}"
    }
) as http_client:

    transport = streamable_http_client(
        URL,
        http_client=http_client
    )

    async with Client(transport) as mcp_client:
        # 原来的工具发现和 Agent Loop 放在这里
        ...
