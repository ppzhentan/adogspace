import os
import httpx2

from dotenv import load_dotenv
from mcp.client.streamable_http import streamable_http_client

load_dotenv()

URL = os.environ["MCP_URL"]
TOKEN = os.environ["MCP_TOKEN"]
