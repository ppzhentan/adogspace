params = StdioServerParameters(
    command=sys.executable,
    args=[str(SERVER)]
)

async with Client(params) as mcp_client:
