
import os
import secrets
import uvicorn
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.environ["MCP_TOKEN"]


class BearerAuth:
    """在 MCP HTTP 请求进入服务前验证 Token。"""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):

        # lifespan 等非 HTTP 请求直接交给原应用
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers", []))
        authorization = headers.get(
            b"authorization", b""
        ).decode("latin-1")

        expected = f"Bearer {TOKEN}"

        if not secrets.compare_digest(
            authorization, expected
        ):
            body = b'{"error":"Unauthorized"}'

            await send({
                "type": "http.response.start",
                "status": 401,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length",
                     str(len(body)).encode())
                ]
            })

            await send({
                "type": "http.response.body",
                "body": body
            })
            return

        await self.app(scope, receive, send)


if __name__ == "__main__":

    mcp_app = mcp.streamable_http_app(
        stateless_http=True,
        json_response=True
    )

    app = BearerAuth(mcp_app)

    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000
    )
