
import csv
from pathlib import Path
from mcp.server import MCPServer

mcp = MCPServer("ProductHTTPServer")

WORKSPACE = Path(__file__).resolve().parent / "workspace"


@mcp.tool()
def list_products() -> list[dict]:
    """读取商品列表。"""

    with (WORKSPACE / "products.csv").open(
        encoding="utf-8-sig",
        newline=""
    ) as f:
        return [
            {
                "id": row["id"],
                "name": row["name"],
                "price": float(row["price"]),
                "cost": float(row["cost"]),
                "shipping": float(row["shipping"])
            }
            for row in csv.DictReader(f)
        ]


@mcp.tool()
def calculate_margin(
    price: float,
    cost: float,
    shipping: float
) -> dict:
    """计算商品利润和利润率。"""

    if price <= 0 or cost < 0 or shipping < 0:
        return {"error": "金额无效"}

    profit = price - cost - shipping

    return {
        "profit": round(profit, 2),
        "margin": round(profit / price * 100, 2)
    }


if __name__ == "__main__":
    mcp.run(
        transport="streamable-http",
        host="127.0.0.1",
        port=8000,
        stateless_http=True,
        json_response=True
    )
