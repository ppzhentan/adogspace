
import asyncio
from mcp import Client


async def main():
    url = "http://127.0.0.1:8000/mcp"

    async with Client(url) as client:

        tools = await client.list_tools()

        print("发现工具：")
        for tool in tools.tools:
            print("-", tool.name)

        result = await client.call_tool(
            "list_products",
            {}
        )

        print("\n商品数据：")
        print(
            result.structured_content
            if result.structured_content is not None
            else result.content
        )


if __name__ == "__main__":
    asyncio.run(main())
