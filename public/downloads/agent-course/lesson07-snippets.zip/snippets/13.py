app = BearerAuth(mcp_app)
