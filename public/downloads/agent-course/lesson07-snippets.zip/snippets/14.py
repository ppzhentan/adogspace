
import os
import asyncio
import httpx2

from dotenv import load_dotenv
from mcp import Client
from mcp.client.streamable_http import streamable_http_client

load_dotenv()

URL = os.environ["MCP_URL"]
TOKEN = os.environ["MCP_TOKEN"]


async def main():

    async with httpx2.AsyncClient(
        headers={
            "Authorization": f"Bearer {TOKEN}"
        }
    ) as http_client:

        transport = streamable_http_client(
            URL,
            http_client=http_client
        )

        async with Client(transport) as client:

            tools = await client.list_tools()

            print("已通过身份验证")
            print("可用工具：")

            for tool in tools.tools:
                print("-", tool.name)

            result = await client.call_tool(
                "list_products",
                {}
            )

            print("\n查询结果：")
            print(
                result.structured_content
                if result.structured_content is not None
                else result.content
            )


if __name__ == "__main__":
    asyncio.run(main())
