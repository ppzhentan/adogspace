
import asyncio
import json
import sys
from pathlib import Path

from mcp import Client, StdioServerParameters
from openai import AsyncOpenAI

MODEL = "qwen3-local"

SERVER = Path(__file__).resolve().parent / "server.py"

llm = AsyncOpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama",
    timeout=120.0
)

# 工具权限白名单
READ_TOOLS = {
    "list_products",
    "calculate_margin"
}

WRITE_TOOLS = {
    "save_report"
}

ALLOWED_TOOLS = READ_TOOLS | WRITE_TOOLS


async def run_agent(task: str, max_steps=10):

    params = StdioServerParameters(
        command=sys.executable,
        args=[str(SERVER)]
    )

    async with Client(params) as mcp_client:

        # 自动发现工具
        result = await mcp_client.list_tools()

        available = {
            tool.name: tool
            for tool in result.tools
            if tool.name in ALLOWED_TOOLS
        }

        tools = [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description or "",
                    "parameters": tool.input_schema
                }
            }
            for tool in available.values()
        ]

        print("MCP 工具：", list(available))

        messages = [
            {
                "role": "system",
                "content": (
                    "你是中文电商商品分析助手。"
                    "必须先读取商品数据。"
                    "需要计算时调用calculate_margin。"
                    "根据工具结果分析，不要编造数据。"
                    "如果用户要求保存报告，"
                    "先整理完整Markdown报告，"
                    "再调用save_report。"
                    "写入被拒绝时，不要重复请求。"
                )
            },
            {
                "role": "user",
                "content": task
            }
        ]

        for step in range(max_steps):

            print(f"\n===== 第 {step + 1} 轮 =====")

            response = await llm.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                temperature=0
            )

            message = response.choices[0].message

            messages.append(
                message.model_dump(exclude_none=True)
            )

            if not message.tool_calls:
                print("\n最终回答：")
                print(message.content or "没有返回文本")
                return message.content

            for call in message.tool_calls:

                name = call.function.name
                print("\n请求工具：", name)

                try:
                    args = json.loads(
                        call.function.arguments
                    )

                    if not isinstance(args, dict):
                        output = {"error": "参数格式错误"}

                    elif name not in available:
                        output = {"error": "工具未授权"}

                    else:
                        # 写操作需要用户确认
                        if name in WRITE_TOOLS:

                            print("\n检测到写入操作")
                            print("工具：", name)
                            print(
                                "参数预览：",
                                json.dumps(
                                    args,
                                    ensure_ascii=False,
                                    indent=2
                                )[:3000]
                            )

                            approval = input(
                                "\n是否允许执行？(yes/no): "
                            ).strip().lower()

                            if approval != "yes":
                                output = {
                                    "error": "用户拒绝写入操作"
                                }
                            else:
                                output = await execute_tool(
                                    mcp_client, name, args
                                )

                        else:
                            output = await execute_tool(
                                mcp_client, name, args
                            )

                except (ValueError, TypeError) as e:
                    output = {"error": str(e)}
                except Exception as e:
                    output = {
                        "error": f"工具执行失败: {e}"
                    }

                print("执行结果：", output)

                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps(
                        output,
                        ensure_ascii=False,
                        default=str
                    )
                })

        print("\n达到最大执行轮数")
        return None


async def execute_tool(client, name, args):

    result = await client.call_tool(name, args)

    if result.is_error:
        return {
            "error": [
                item.model_dump(mode="json")
                for item in result.content
            ]
        }

    if result.structured_content is not None:
        return result.structured_content

    return [
        item.model_dump(mode="json")
        for item in result.content
    ]


async def main():

    await run_agent(
        "读取全部商品数据，"
        "计算每个商品的利润和利润率，"
        "按利润率从高到低排序，"
        "生成中文Markdown分析报告，"
        "并保存到report.md。"
    )


if __name__ == "__main__":
    asyncio.run(main())
