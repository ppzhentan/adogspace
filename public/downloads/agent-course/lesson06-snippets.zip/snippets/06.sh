python test_mcp.py
