python -m pip install -U "mcp>=2,<3" openai
