
import asyncio
import sys
from pathlib import Path
from mcp import Client, StdioServerParameters

SERVER = Path(__file__).resolve().parent / "server.py"


async def main():

    params = StdioServerParameters(
        command=sys.executable,
        args=[str(SERVER)]
    )

    async with Client(params) as client:

        print("MCP Server 已连接")

        result = await client.list_tools()

        print("\n可用工具：")
        for tool in result.tools:
            print("-", tool.name)

        products = await client.call_tool(
            "list_products",
            {}
        )

        print("\n商品数据：")
        print(
            products.structured_content
            if products.structured_content is not None
            else products.content
        )


if __name__ == "__main__":
    asyncio.run(main())
