
import csv
import json
import sys
from pathlib import Path
from mcp.server import MCPServer

mcp = MCPServer("ProductReportServer")

WORKSPACE = Path(__file__).resolve().parent / "workspace"
WORKSPACE.mkdir(exist_ok=True)


@mcp.tool()
def list_products() -> list[dict]:
    """读取工作目录中的商品CSV数据。只读操作。"""

    file = WORKSPACE / "products.csv"

    with file.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return [
            {
                "id": row["id"],
                "name": row["name"],
                "price": float(row["price"]),
                "cost": float(row["cost"]),
                "shipping": float(row["shipping"])
            }
            for row in reader
        ]


@mcp.tool()
def calculate_margin(
    price: float,
    cost: float,
    shipping: float
) -> dict:
    """计算商品利润和利润率，利润率以百分比返回。"""

    if price <= 0 or cost < 0 or shipping < 0:
        return {"error": "金额参数无效"}

    profit = price - cost - shipping

    return {
        "profit": round(profit, 2),
        "margin": round(profit / price * 100, 2)
    }


@mcp.tool()
def save_report(content: str) -> dict:
    """将Markdown报告保存为workspace/report.md。写入操作。"""

    if len(content) > 20000:
        return {"error": "报告内容超过限制"}

    destination = WORKSPACE / "report.md"
    destination.write_text(content, encoding="utf-8")

    return {
        "success": True,
        "path": str(destination)
    }


if __name__ == "__main__":
    # stdio协议消息必须独占stdout
    # 调试日志应写入stderr
    mcp.run(transport="stdio")
