import pytest
from scoring import tool_score, fact_score, violation_count, citation_score, section_score, evaluate
from evaluate import load_cases, summarize
from compare import compare

def test_dataset():
    cases=load_cases()
    assert len(cases)==5 and len({x['id'] for x in cases})==5

def test_tool_exact_match():
    x=[{'name':'read_document','args':{'filename':'shipping.md'}}]
    assert tool_score(x,x)==1
    assert tool_score(x,[{'name':'read_document','args':{'filename':'returns.md'}}])==0

def test_required_facts():
    assert fact_score(['6999','日元'],'满6999日元免运费')==1
    assert fact_score(['6999','日元'],'免运费')==0

def test_forbidden_claims():
    assert violation_count(['24小时'],'付款期限为24小时')==1

def test_citation():
    assert citation_score(['shipping.md'],'来源：shipping.md')==1
    assert citation_score(['shipping.md'],'无引用')==0

def test_sections():
    assert section_score(['事实','建议'],'事实：...建议：...')==1

def test_evaluation_gates():
    c=load_cases()[0]
    r={'answer':'满6999日元免运费（shipping.md）','tool_calls':c['expected_tools'],
       'evidence':[],'latency_ms':100,'usage':{}}
    assert evaluate(c,r)['passed']
    r['tool_calls']=[]
    assert not evaluate(c,r)['passed']

def test_compare_regression():
    def row(id,passed):return {'id':id,'scores':{'passed':passed}}
    a={'cases':[row('a',True)],'summary':{'task_success_rate':1.0}}
    b={'cases':[row('a',False)],'summary':{'task_success_rate':0.0}}
    out=compare(a,b)
    assert not out['pass'] and out['regressions']==['a']

def test_compare_mismatched_cases():
    a={'cases':[{'id':'a','scores':{'passed':True}}],'summary':{'task_success_rate':1}}
    b={'cases':[{'id':'b','scores':{'passed':True}}],'summary':{'task_success_rate':1}}
    with pytest.raises(ValueError):compare(a,b)

def test_summarize():
    s={'passed':True,'tool_accuracy':1,'required_fact_recall':1,'citation_coverage':1,
       'latency_ms':100,'faithfulness_judge':None}
    out=summarize([{'scores':s}])
    assert out['task_success_rate']==1 and out['judge_scored_cases']==0
