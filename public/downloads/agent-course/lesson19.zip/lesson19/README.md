# Lesson 19: Agent Evals (local Ollama)

> Educational example. Documents are fictional. No paid API needed.

## Setup

```bash
cd lesson19
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama list  # must include qwen3-local
```

If Ollama uses a different name or address:

```bash
export OLLAMA_MODEL=qwen3-local
export OLLAMA_BASE_URL=http://127.0.0.1:11434/v1
```

## Fast deterministic tests (no Ollama needed)

```bash
python -m pytest -q
```

## Run evaluation

```bash
python evaluate.py --variant baseline
python evaluate.py --variant candidate
python compare.py
```

Optional local LLM-as-a-Judge (additional model call per case):

```bash
python evaluate.py --variant baseline --judge
python evaluate.py --variant candidate --judge
python compare.py
```

Run one case:

```bash
python evaluate.py --variant baseline --case rag_shipping
```

Results are written to `reports/{variant}.json` and `.md`.

## Design details

- `agent.py` is a **minimal read-only candidate** that routes documents deterministically using case metadata. It does **not** evaluate LLM-selected tools. The exact tool-call evaluator is real, but to test autonomous tool selection replace `run_case()` with an adapter for your Lesson 18 Agent, capturing its real tool calls and retrieved evidence. Do not expose `expected_tools` or `required_facts` to the candidate Agent.
- This dataset has 5 small, fictional cases. It is a tutorial fixture, not a statistical benchmark.
- Rule scores measure exact tool traces, required phrases, forbidden phrases, source filename mentions and report headings. Phrase presence is **not** full semantic correctness. A correct paraphrase may be marked wrong.
- `--judge` adds a subjective local model score for faithfulness. A judge parse failure yields null and is excluded from the mean, not silently scored as zero. Track judge coverage.
- The judge is given evidence and answer, but not expected phrases. It can still share biases with the candidate; manually label a held-out set.
- A regression is a case that previously passed and now fails. `compare.py` exits nonzero if any such regression exists or overall task success decreases.
- Scores are deterministic only for fixed outputs. Local model generations can vary across runs even with temperature 0.
- For serious use, add adversarial examples, negative/unanswerable cases, multilingual examples, retrieval Recall@k, latency percentiles, cost budgets, per-tenant datasets and independent human ratings.
- Reports contain complete answers and may contain sensitive content if you adapt this to real data; do not publish them blindly.

## Next step

Connect `run_case()` to the Lesson 18 workflow and evaluate true multi-agent traces, tool authorization, retries and approval decisions. Keep test ground truth separate from the Agent's prompt.
