import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def compare(base,cand,threshold=0):
    a={r['id']:r for r in base['cases']}
    b={r['id']:r for r in cand['cases']}
    if set(a)!=set(b):
        raise ValueError('case sets differ; evaluate the same dataset')
    regressions=[id for id in sorted(a) if a[id]['scores']['passed'] and not b[id]['scores']['passed']]
    improvements=[id for id in sorted(a) if not a[id]['scores']['passed'] and b[id]['scores']['passed']]
    delta=cand['summary']['task_success_rate']-base['summary']['task_success_rate']
    passed=not regressions and delta>=-threshold
    return {'pass':passed,'success_rate_delta':round(delta,4),'regressions':regressions,'improvements':improvements,
            'baseline_success':base['summary']['task_success_rate'],
            'candidate_success':cand['summary']['task_success_rate']}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--baseline',default='reports/baseline.json')
    p.add_argument('--candidate',default='reports/candidate.json')
    p.add_argument('--tolerance',type=float,default=0)
    a=p.parse_args()
    result=compare(json.loads(Path(a.baseline).read_text()),json.loads(Path(a.candidate).read_text()),a.tolerance)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['pass'] else 1)
