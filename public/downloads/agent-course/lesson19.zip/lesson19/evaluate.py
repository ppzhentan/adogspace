import argparse
import json
import statistics
from datetime import datetime, timezone
from pathlib import Path
from agent import run_case, MODEL
from scoring import evaluate

ROOT = Path(__file__).resolve().parent

def load_cases(path=ROOT / "evals/cases.jsonl"):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]

def summarize(rows):
    if not rows:
        raise ValueError("empty eval run")
    scores = [r["scores"] for r in rows]
    judged = [s["faithfulness_judge"]["score"] for s in scores if s["faithfulness_judge"] is not None]
    return {"cases":len(rows),"task_success_rate":sum(s["passed"] for s in scores)/len(rows),
            "tool_accuracy":statistics.mean(s["tool_accuracy"] for s in scores),
            "required_fact_recall":statistics.mean(s["required_fact_recall"] for s in scores),
            "citation_coverage":statistics.mean(s["citation_coverage"] for s in scores),
            "avg_latency_ms":round(statistics.mean(s["latency_ms"] for s in scores),2),
            "judge_faithfulness_mean":statistics.mean(judged) if judged else None,
            "judge_scored_cases":len(judged)}

def run(variant, use_judge, only=None):
    rows = []
    for case in load_cases():
        if only and case["id"] != only:
            continue
        print(f"Running {case['id']} ({variant})...",flush=True)
        try:
            result = run_case(case,variant)
            scores = evaluate(case,result,use_judge)
            rows.append({"id":case["id"],"kind":case["kind"],"scores":scores,
                         "answer":result["answer"],"tool_calls":result["tool_calls"]})
        except Exception as exc:
            print(f"  ERROR {type(exc).__name__}: {exc}")
            rows.append({"id":case["id"],"kind":case["kind"],
                         "scores":{"passed":False,"tool_accuracy":0.0,"required_fact_recall":0.0,
                                   "forbidden_claims_found":0,"citation_coverage":0.0,"section_coverage":0.0,
                                   "faithfulness_judge":None,"latency_ms":0,"usage":{}},
                         "error":f"{type(exc).__name__}: {exc}"})
    report={"variant":variant,"model":MODEL,"created_at":datetime.now(timezone.utc).isoformat(),
            "summary":summarize(rows),"cases":rows}
    out=ROOT / "reports" / f"{variant}.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[f"# Agent Eval: {variant}","",f"Model: `{MODEL}`","", "## Summary","",
        "| Metric | Value |","|---|---:|"]
    for k,v in report["summary"].items():
        md.append(f"| {k} | {v} |")
    md.extend(["","## Cases","","| ID | Passed | Tools | Facts | Citations |","|---|---|---:|---:|---:|"])
    for r in rows:
        s=r["scores"]
        md.append(f"| {r['id']} | {s['passed']} | {s['tool_accuracy']:.2f} | {s['required_fact_recall']:.2f} | {s['citation_coverage']:.2f} |")
    (ROOT / "reports" / f"{variant}.md").write_text("\n".join(md)+"\n",encoding="utf-8")
    print(json.dumps(report["summary"],ensure_ascii=False,indent=2))
    print("Saved:",out)
    return report

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--variant",choices=["baseline","candidate"],default="baseline")
    p.add_argument("--judge",action="store_true")
    p.add_argument("--case",default=None)
    a=p.parse_args()
    run(a.variant,a.judge,a.case)
