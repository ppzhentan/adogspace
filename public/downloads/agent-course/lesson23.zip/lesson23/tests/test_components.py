import pytest
from app.policy import plan,valid_plan
from app.security import valid_email,password_hash,verify,token_hash
from app.rag import chunks,cosine
from app.trace_evals import score,compare

def test_dag():assert valid_plan(plan())
def test_dag_cycle():
    p=plan();p[0]['deps']=['publish'];assert not valid_plan(p)
def test_password():
    salt='ab'*16;h=password_hash('long-secret-123',salt)
    assert verify('long-secret-123',salt,h)
    assert not verify('wrong-password',salt,h)
def test_email():assert valid_email('hello@example.com') and not valid_email('invalid')
def test_token_hash():assert token_hash('abc')!=token_hash('def')
def test_chunks():
    a=chunks('abcdefghij',size=5,overlap=2)
    assert a[0]=='abcde' and a[1]=='defgh'
def test_chunk_validation():
    with pytest.raises(ValueError):chunks('abc',size=4,overlap=4)
def test_cosine():assert cosine([1,0],[1,0])==1 and cosine([1,0],[0,1])==0
def test_cosine_bad_dimensions():assert cosine([1,0],[1])==0
def test_trace_pass():
    x={'answer':'满6999日元免运费','sources':['shipping.md'],'tool_calls':[{'name':'retrieve_documents'}],'events':[{'kind':'approved'},{'kind':'published'}]}
    assert score(x,{'required_facts':['6999'],'required_sources':['shipping.md']})['passed']
def test_approval_bypass():
    x={'answer':'test','sources':['shipping.md'],'tool_calls':[],'events':[{'kind':'published'}]}
    assert not score(x,{})['checks']['approval_before_publish']
def test_injection_tool():
    x={'answer':'ok','sources':['x'],'tool_calls':[{'name':'shell'}],'events':[]}
    assert not score(x,{})['checks']['tool_allowlist']
def test_regression():
    x=compare([{'case_id':'a','passed':True}],[{'case_id':'a','passed':False}])
    assert x['regressions']==['a'] and x['candidate_rate']==0
