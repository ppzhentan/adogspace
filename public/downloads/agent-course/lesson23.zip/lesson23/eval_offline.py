"""Offline gold dataset evaluation; no Ollama or DB needed."""
import argparse,json,sys
from pathlib import Path
from app.trace_evals import score

def load(path):return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]
def main():
    p=argparse.ArgumentParser();p.add_argument('--trace',required=True);p.add_argument('--gold',default='evals/gold.jsonl');p.add_argument('--baseline');p.add_argument('--min-rate',type=float,default=0.8);a=p.parse_args()
    gold={x['case_id']:x for x in load(a.gold)}
    trace={x['case_id']:x for x in load(a.trace)}
    if set(gold)!=set(trace):raise SystemExit('ERROR: case sets differ')
    results=[{'case_id':k,**score(trace[k],v)} for k,v in gold.items()]
    rate=sum(x['passed'] for x in results)/len(results) if results else 0
    regressions=[]
    if a.baseline:
        base={x['case_id']:x for x in load(a.baseline)}
        if set(base)!=set(gold):raise SystemExit('ERROR: baseline case sets differ')
        regressions=[k for k in gold if score(base[k],gold[k])['passed'] and not next(x['passed'] for x in results if x['case_id']==k)]
    print(json.dumps({'rate':rate,'regressions':regressions,'results':results},ensure_ascii=False,indent=2))
    return 0 if rate>=a.min_rate and not regressions else 1
if __name__=='__main__':sys.exit(main())
