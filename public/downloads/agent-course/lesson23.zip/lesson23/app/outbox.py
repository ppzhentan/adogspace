"""Transactional outbox relay. Postgres is authoritative; Redis messages may duplicate."""
import time,logging
from .db import connect
from .queue import client
LOG=logging.getLogger(__name__)

def deliver_once(push=None):
    push=push or (lambda payload:client().lpush('agent:wake',str(payload['workflow_id'])))
    with connect() as c:
        with c.transaction():
            row=c.execute('SELECT id,kind,payload FROM outbox WHERE delivered_at IS NULL ORDER BY id FOR UPDATE SKIP LOCKED LIMIT 1').fetchone()
            if not row:return False
            # Holding row lock across short Redis call prevents concurrent relays.
            # A crash after LPUSH but before commit may duplicate the notification.
            push(row['payload'])
            c.execute('UPDATE outbox SET delivered_at=now(),attempts=attempts+1 WHERE id=%s',(row['id'],))
            return True

def main():
    while True:
        try:
            if not deliver_once():time.sleep(1)
        except Exception:
            LOG.exception('outbox relay error');time.sleep(2)
if __name__=='__main__':main()
