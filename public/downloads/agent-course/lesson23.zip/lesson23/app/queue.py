import redis
from .config import REDIS_URL

def client():return redis.Redis.from_url(REDIS_URL,decode_responses=True,socket_timeout=2)
def wake():
    try:client().lpush('agent:wake','1')
    except redis.RedisError:pass  # Postgres scanner remains authoritative
