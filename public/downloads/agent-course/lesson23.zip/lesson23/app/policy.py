import hmac
from datetime import datetime,timezone

def tenant_for_token(token, mapping):
    for item in mapping.split(','):
        if ':' not in item: continue
        secret,tenant=item.split(':',1)
        if secret and hmac.compare_digest(token,secret): return tenant
    return None

def valid_plan(nodes):
    names={n['id'] for n in nodes}
    if len(names)!=len(nodes): return False
    if any(n['kind'] not in {'research','analysis','write','review','approval','publish'} or any(d not in names or d==n['id'] for d in n['deps']) for n in nodes): return False
    state={}
    def visit(n):
        if state.get(n)==1:return False
        if state.get(n)==2:return True
        state[n]=1
        for dep in next(x['deps'] for x in nodes if x['id']==n):
            if not visit(dep):return False
        state[n]=2
        return True
    return all(visit(n) for n in names)

def plan():
    return [
      {'id':'research_shipping','kind':'research','deps':[]},
      {'id':'research_returns','kind':'research','deps':[]},
      {'id':'research_payment','kind':'research','deps':[]},
      {'id':'analysis','kind':'analysis','deps':['research_shipping','research_returns','research_payment']},
      {'id':'write','kind':'write','deps':['analysis']},
      {'id':'review','kind':'review','deps':['write']},
      {'id':'approval','kind':'approval','deps':['review']},
      {'id':'publish','kind':'publish','deps':['approval']},
    ]

def day_utc():return datetime.now(timezone.utc).date().isoformat()
