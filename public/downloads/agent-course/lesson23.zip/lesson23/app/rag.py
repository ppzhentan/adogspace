"""Tenant-scoped cosine RAG with Ollama embeddings. Document text is untrusted evidence."""
import math,re,uuid
import httpx
from .config import OLLAMA_URL,EMBED_MODEL

def cosine(a,b):
    if len(a)!=len(b) or not a:return 0.0
    den=math.sqrt(sum(x*x for x in a))*math.sqrt(sum(x*x for x in b))
    return sum(x*y for x,y in zip(a,b))/den if den else 0.0

def chunks(text,size=1100,overlap=120):
    if size<=overlap or overlap<0:raise ValueError('invalid chunk settings')
    return [text[i:i+size] for i in range(0,len(text),size-overlap)]

def embedding(text):
    with httpx.Client(timeout=120) as client:
        r=client.post(f'{OLLAMA_URL}/api/embed',json={'model':EMBED_MODEL,'input':text})
        r.raise_for_status();v=r.json()['embeddings'][0]
        if not v or not all(isinstance(x,(int,float)) for x in v):raise ValueError('invalid embedding')
        return v

def add_document(user_id,name,body,embed=embedding):
    if not re.fullmatch(r'[\w .-]{1,100}',name) or not body.strip() or len(body)>40000:raise ValueError('invalid document')
    parts=chunks(body)
    vectors=[embed(x) for x in parts] # failures before commit; no partial document
    from .db import connect
    with connect() as c:
        with c.transaction():
            d=c.execute('INSERT INTO documents(user_id,name,body) VALUES (%s,%s,%s) RETURNING id',(user_id,name,body)).fetchone()['id']
            for i,(part,v) in enumerate(zip(parts,vectors)):
                c.execute('INSERT INTO doc_chunks(document_id,user_id,ordinal,body,embedding) VALUES (%s,%s,%s,%s,%s::jsonb)',(d,user_id,i,part,__import__('json').dumps(v)))
    return str(d)

def retrieve(user_id,query,limit=4,embed=embedding):
    v=embed(query)
    from .db import connect
    with connect() as c:
        rows=c.execute('''SELECT c.body,c.embedding,d.name,d.id AS document_id,c.ordinal FROM doc_chunks c JOIN documents d ON d.id=c.document_id WHERE c.user_id=%s AND d.user_id=%s''',(user_id,user_id)).fetchall()
    scored=sorted(({ 'score':cosine(v,r['embedding']),'body':r['body'],'source':r['name'],'document_id':str(r['document_id']),'chunk':r['ordinal']} for r in rows),key=lambda x:x['score'],reverse=True)
    return scored[:limit]
