import json,logging,time,uuid
from contextlib import contextmanager
logging.basicConfig(level=logging.INFO,format='%(message)s')
LOG=logging.getLogger('agent')

def log(event,**fields):
    LOG.info(json.dumps({'time':time.time(),'event':event,**fields},ensure_ascii=False,default=str))

@contextmanager
def span(name,**attrs):
    start=time.monotonic();trace_id=uuid.uuid4().hex
    try:yield trace_id
    finally:log('span',name=name,trace_id=trace_id,duration_ms=round((time.monotonic()-start)*1000),**attrs)
