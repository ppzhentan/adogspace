"""Authenticated tenant-scoped API. For local/private deployment, not public production."""
from fastapi import FastAPI,Depends,HTTPException,Header,Request
from fastapi.responses import HTMLResponse,PlainTextResponse
from pydantic import BaseModel,Field
from pathlib import Path
from . import db,store,security,rag
from .trace_evals import score
from .observability import log

app=FastAPI(title='Lesson 23 Integrated Agent SaaS')
@app.on_event('startup')
def startup():db.init()

def user(authorization:str=Header(default='')):
    if not authorization.startswith('Bearer '):raise HTTPException(401,'Missing bearer token')
    uid=security.identify(authorization[7:])
    if not uid:raise HTTPException(401,'Invalid or expired token')
    return uid

class Credentials(BaseModel):
    email:str=Field(max_length=200)
    password:str=Field(min_length=12,max_length=200)
class Document(BaseModel):
    name:str=Field(min_length=1,max_length=100)
    body:str=Field(min_length=1,max_length=40000)
class Create(BaseModel):goal:str=Field(min_length=5,max_length=2000)

@app.get('/',response_class=HTMLResponse)
def index():return (Path(__file__).resolve().parent.parent/'static/index.html').read_text()
@app.get('/health')
def health():return {'status':'ok'}
@app.post('/api/register')
def register(body:Credentials):
    try:return {'user_id':security.register(body.email,body.password)}
    except ValueError as e:raise HTTPException(422,str(e))
    except Exception as e:
        if getattr(e,'sqlstate',None)=='23505':raise HTTPException(409,'Account already exists')
        raise
@app.post('/api/login')
def login(body:Credentials):
    token=security.login(body.email,body.password)
    if not token:raise HTTPException(401,'Invalid credentials')
    return {'token':token,'token_type':'bearer','expires_in':86400}
@app.post('/api/documents')
def add_doc(body:Document,uid:str=Depends(user)):
    try:return {'id':rag.add_document(uid,body.name,body.body)}
    except ValueError as e:raise HTTPException(422,str(e))
@app.get('/api/documents')
def documents(uid:str=Depends(user)):
    with db.connect() as c:return c.execute('SELECT id,name,created_at FROM documents WHERE user_id=%s ORDER BY created_at DESC LIMIT 100',(uid,)).fetchall()
@app.post('/api/workflows')
def create(body:Create,uid:str=Depends(user)):
    try:wid=store.create(uid,body.goal,uid)
    except ValueError as e:raise HTTPException(429,str(e))
    log('workflow_created',workflow_id=wid,user_id=uid)
    return {'id':wid}
@app.get('/api/workflows')
def history(uid:str=Depends(user)):return store.history(uid,uid)
@app.get('/api/workflows/{wid}')
def detail(wid:str,uid:str=Depends(user)):
    try:obj=store.get(uid,wid,uid)
    except Exception:raise HTTPException(404)
    if not obj:raise HTTPException(404)
    return obj
@app.get('/api/workflows/{wid}/events')
def events(wid:str,uid:str=Depends(user)):
    if not store.get(uid,wid,uid):raise HTTPException(404)
    return store.events(uid,wid,uid)
@app.get('/api/workflows/{wid}/eval')
def evals(wid:str,uid:str=Depends(user)):
    obj=store.get(uid,wid,uid)
    if not obj:raise HTTPException(404)
    nodes={n['id']:n for n in obj['nodes']}
    report=nodes.get('write',{}).get('result') or ''
    evs=store.events(uid,wid,uid)
    tool_events=[]
    for e in evs:
        if e['kind']=='tool_call':
            try:tool_events.append(__import__('json').loads(e['detail']))
            except (ValueError,TypeError):pass
    trace={'answer':report,'tool_calls':[{'name':e['name']} for e in tool_events],
           'sources':sorted({s for e in tool_events for s in e.get('sources',[])}),
           'events':[{'kind':e['kind']} for e in evs]}
    result=score(trace,{'required_sources':[],'required_facts':[],'forbidden_claims':[]})
    result['trace']=trace
    result['limitations']='Observed retrieval tool events; source presence is not proof of per-claim factual grounding. Apply eval_offline.py with human-labelled gold facts.'
    return result

@app.post('/api/workflows/{wid}/approve')
def approve(wid:str,uid:str=Depends(user)):
    if not store.decision(uid,wid,True,uid,uid):raise HTTPException(409,'Not awaiting approval or not found')
    return {'status':'approved'}
@app.post('/api/workflows/{wid}/reject')
def reject(wid:str,uid:str=Depends(user)):
    if not store.decision(uid,wid,False,uid,uid):raise HTTPException(409,'Not awaiting approval or not found')
    return {'status':'rejected'}
@app.post('/api/workflows/{wid}/cancel')
def cancel(wid:str,uid:str=Depends(user)):
    if not store.cancel(uid,wid,uid):raise HTTPException(409,'Cannot cancel or not found')
    return {'status':'cancelled'}
@app.get('/metrics',response_class=PlainTextResponse)
def metrics():
    # No tenant-specific labels, no secrets. Keep endpoint bound to loopback.
    with db.connect() as c:
        wf=c.execute('SELECT status,count(*) n FROM workflows GROUP BY status').fetchall()
        pending=c.execute('SELECT count(*) n FROM outbox WHERE delivered_at IS NULL').fetchone()['n']
    lines=['# TYPE agent_workflows gauge']+[f'agent_workflows{{status="{r["status"]}"}} {r["n"]}' for r in wf]+['# TYPE agent_outbox_pending gauge',f'agent_outbox_pending {pending}']
    return '\n'.join(lines)+'\n'
