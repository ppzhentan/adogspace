"""Password-based auth, hashed expiring bearer tokens, tenant isolation."""
import hashlib,hmac,re,secrets
from datetime import datetime,timezone,timedelta

def valid_email(email):return bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email))
def password_hash(password,salt):return hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1).hex()
def verify(password,salt,digest):return hmac.compare_digest(password_hash(password,salt),digest)
def token_hash(token):return hashlib.sha256(token.encode()).hexdigest()

def register(email,password):
    from .db import connect
    email=email.strip().lower()
    if not valid_email(email) or len(password)<12:raise ValueError('Invalid email or password (min 12 characters)')
    salt=secrets.token_hex(16)
    with connect() as c:
        row=c.execute('INSERT INTO users(email,salt,password_hash) VALUES (%s,%s,%s) RETURNING id',(email,salt,password_hash(password,salt))).fetchone()
    return str(row['id'])

def login(email,password):
    from .db import connect
    with connect() as c:
        row=c.execute('SELECT * FROM users WHERE email=%s',(email.strip().lower(),)).fetchone()
        if not row or not verify(password,row['salt'],row['password_hash']):return None
        token=secrets.token_urlsafe(32)
        c.execute("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES (%s,%s,now()+interval '24 hours')",(token_hash(token),row['id']))
    return token

def identify(token):
    from .db import connect
    if not token:return None
    with connect() as c:
        row=c.execute('SELECT user_id FROM sessions WHERE token_hash=%s AND expires_at>now()',(token_hash(token),)).fetchone()
        return str(row['user_id']) if row else None
