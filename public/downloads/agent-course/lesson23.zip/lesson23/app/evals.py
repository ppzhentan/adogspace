import json

def evaluate(workflow):
    """Deterministic trace gates; not semantic factuality evaluation."""
    nodes={n['id']:n for n in workflow['nodes']}
    approved=nodes.get('approval',{}).get('status')=='completed'
    published=nodes.get('publish',{}).get('status')=='completed'
    research=all(nodes.get(k,{}).get('status')=='completed' for k in ('research_shipping','research_returns','research_payment'))
    report=nodes.get('write',{}).get('result') or ''
    checks={'research_completed':research,'approval_before_publish':not published or approved,'report_nonempty':bool(report.strip()),'publish_consistent':workflow['workflow']['status']!='completed' or published}
    return {'checks':checks,'passed':all(checks.values()),'warning':'Structural checks only; no human-labelled factuality, adversarial corpus, or LLM judge.'}
