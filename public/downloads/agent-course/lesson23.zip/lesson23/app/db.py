from contextlib import contextmanager
import psycopg
from psycopg.rows import dict_row
from .config import DATABASE_URL

@contextmanager
def connect():
    with psycopg.connect(DATABASE_URL,row_factory=dict_row) as conn:
        yield conn

SCHEMA='''
CREATE TABLE IF NOT EXISTS workflows (
 id uuid PRIMARY KEY, tenant text NOT NULL, goal text NOT NULL,
 status text NOT NULL DEFAULT 'running', created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS nodes (
 workflow_id uuid NOT NULL REFERENCES workflows(id), id text NOT NULL, kind text NOT NULL,
 deps jsonb NOT NULL, status text NOT NULL DEFAULT 'pending', result text,
 attempts integer NOT NULL DEFAULT 0, lease_until timestamptz,
 owner text, fencing bigint NOT NULL DEFAULT 0, error text,
 PRIMARY KEY(workflow_id,id));
CREATE TABLE IF NOT EXISTS approvals (
 workflow_id uuid PRIMARY KEY REFERENCES workflows(id), tenant text NOT NULL,
 decision text NOT NULL, reviewer text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS events (
 id bigserial PRIMARY KEY, workflow_id uuid NOT NULL REFERENCES workflows(id),
 kind text NOT NULL, node text, detail text, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS quotas (
 tenant text NOT NULL, day date NOT NULL, used integer NOT NULL DEFAULT 0,
 PRIMARY KEY(tenant,day));
CREATE INDEX IF NOT EXISTS idx_nodes_status ON nodes(status,lease_until);
'''

def init():
    with connect() as conn:
        for statement in SCHEMA.split(';'):
            if statement.strip():conn.execute(statement)

EXT_SCHEMA='''
CREATE TABLE IF NOT EXISTS users(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),email text UNIQUE NOT NULL,salt text NOT NULL,password_hash text NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash text PRIMARY KEY,user_id uuid NOT NULL REFERENCES users(id),expires_at timestamptz NOT NULL);
CREATE TABLE IF NOT EXISTS documents(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),user_id uuid NOT NULL REFERENCES users(id),name text NOT NULL,body text NOT NULL,created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS doc_chunks(document_id uuid NOT NULL REFERENCES documents(id),user_id uuid NOT NULL REFERENCES users(id),ordinal integer NOT NULL,body text NOT NULL,embedding jsonb NOT NULL,PRIMARY KEY(document_id,ordinal));
CREATE INDEX IF NOT EXISTS idx_doc_chunks_user ON doc_chunks(user_id);
CREATE TABLE IF NOT EXISTS outbox(id bigserial PRIMARY KEY,kind text NOT NULL,payload jsonb NOT NULL,created_at timestamptz DEFAULT now(),delivered_at timestamptz,attempts integer NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox(id) WHERE delivered_at IS NULL;
CREATE TABLE IF NOT EXISTS traces(workflow_id uuid PRIMARY KEY REFERENCES workflows(id),user_id uuid NOT NULL REFERENCES users(id),trace jsonb NOT NULL,score jsonb NOT NULL,created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS audit(id bigserial PRIMARY KEY,user_id uuid NOT NULL REFERENCES users(id),workflow_id uuid,action text NOT NULL,created_at timestamptz DEFAULT now());
ALTER TABLE workflows ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES users(id);
'''
_old_init=init
def init():
    _old_init()
    with connect() as c:
        for stmt in EXT_SCHEMA.split(';'):
            if stmt.strip():c.execute(stmt)
