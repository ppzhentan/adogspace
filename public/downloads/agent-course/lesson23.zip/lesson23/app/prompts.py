def prompt_for(node,goal,context):
    by={x['id']:x['result'] for x in context}
    if node.startswith('research_'):
        topic=node.split('_',1)[1]
        return f'你是Researcher。只针对{topic}研究以下业务目标。提供事实与不确定性，不要编造外部来源。\n目标:{goal}'
    if node=='analysis':return f'你是Analyst。对研究材料分析，给出三个有证据边界的改进方向。\n目标:{goal}\n材料:{by}'
    if node=='write':return f'你是Writer。基于分析生成中文Markdown报告，区分事实与假设。\n目标:{goal}\n材料:{by}'
    if node=='review':return f'你是Reviewer。审查报告，输出JSON: {{"approved":true/false,"issues":[]}}。\n材料:{by}'
    if node=='publish':return by.get('write','')
    raise ValueError('unknown node')

