# Lesson 23 — Integrated AI Agent SaaS (local/private lab)

**Python 3.12 · FastAPI · PostgreSQL 16 · Redis 7 · Ollama `qwen3-local` + `embeddinggemma`**

This lesson extends the Lesson 22 worker/lease/DAG prototype with real account authentication and user-scoped RAG from Lesson 21, a transactional outbox, observed tool traces, metrics and offline gold-data Evals. This is a **deployment-oriented educational prototype**, not an audited public SaaS.

## Quick start (macOS + Docker Desktop)

1. Install and start Ollama on the Mac. Confirm:
   ```bash
   ollama list
   ollama pull embeddinggemma
   ```
   You should already have `qwen3-local`. If not, create/configure your own local alias; this project does not assume an official model tag of that name.
2. Make sure Ollama accepts connections from Docker containers. On macOS, if the default host-only listener rejects requests, configure Ollama's `OLLAMA_HOST=0.0.0.0:11434` in a **trusted local environment** and restart it. Do not expose port 11434 to the public internet.
3. Run:
   ```bash
   docker compose up --build -d
   docker compose ps
   docker compose logs -f api worker relay
   ```
4. Open <http://127.0.0.1:8000>. Register an account using a real-looking email and a password of at least 12 characters; log in. **Do not reuse a real password.**
5. Add `shipping.md` with: `日本站满6999日元免标准运费。` Add `returns.md` with: `收到商品7天内可申请退货，非质量问题退货运费由顾客承担。` (fictional examples).
6. Create task: `根据知识库配送与退货政策，分析潜在转化阻碍，给出三项改进建议。明确区分事实与假设。`
7. Observe three parallel research nodes, analysis, write, review, waiting approval; approve/reject in UI.
8. Scale worker processes:
   ```bash
   docker compose up -d --scale worker=2
   ```
9. Stop without destroying volumes: `docker compose down`. **`docker compose down -v` deletes data.**

### Services

- `api`: FastAPI + UI; **127.0.0.1 only**.
- `worker`: separate DAG workers, row-level claiming, leases/heartbeats/fencing, retry/recovery.
- `relay`: scans PostgreSQL transactional outbox, pushes Redis wake notifications.
- `postgres`: authoritative workflow/user/document/trace state.
- `redis`: best-effort wake queue; database polling ensures work is discoverable if notifications fail.
- Ollama runs **on your Mac**, not in Docker.

## Why outbox?

`store.create()` and `store.decision()` write workflow/approval **and** outbox row in the same PostgreSQL transaction. The relay later delivers the Redis notification and marks the row delivered. If Redis is down, the row stays pending. If the relay crashes after LPUSH but before commit, the wake notification may be sent twice; this is acceptable because `FOR UPDATE SKIP LOCKED` claims the task atomically. The outbox does **not** make external email/payment/publish side effects exactly once.

## Auth and isolation

- Email + `scrypt` salted password hash, hashed expiring bearer token.
- Every API read/write of user data is scoped to authenticated user UUID; RAG retrieval filters chunks by user UUID.
- This demo uses each user as a tenant. Real organizations need organization membership and RBAC.
- There is no password reset, account verification, per-IP login rate limiting, session revocation UI, TLS termination, CSRF-protected cookie auth, migration framework or security audit. Bearer token is kept in JS memory (lost on refresh).

## Observability

- Worker JSON logs include workflow/node and duration (`docker compose logs -f worker`).
- `GET /metrics` provides small Prometheus-compatible counters/gauges (workflow status counts and outbox backlog); no PII labels. Metrics endpoint is not separately authenticated, so keep API loopback-only.
- `GET /api/workflows/{id}/events` provides persisted execution events; `GET /api/workflows/{id}/eval` provides observed retrieval calls and structural checks. It does **not** claim full semantic factuality.

## Evals: actual traces vs. teaching fixtures

The API eval endpoint builds a trace from **actual persisted workflow events** including observed `retrieve_documents` calls. The included `evals/sample_trace.jsonl` is a **synthetic teaching fixture**; do not present it as an actual model evaluation.

Offline gold tests:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python eval_offline.py --trace evals/sample_trace.jsonl --gold evals/gold.jsonl --min-rate 1
```

For a real regression gate, collect real candidate and baseline traces, normalize each to JSONL with `case_id, answer, tool_calls, sources, events`, annotate `evals/gold.jsonl` with verified facts, then run:

```bash
python eval_offline.py --trace candidate.jsonl --baseline baseline.jsonl --gold evals/gold.jsonl --min-rate 0.95
```

Exit 1 means low success rate or a passing baseline case regressed. Use only **fixed cases with identical case IDs**. LLM Judge is intentionally not a hard gate; this lesson focuses on observable trace checks and human-verified facts.

## Reliability limits / next steps

- Worker uses **at-least-once** execution. Fencing rejects stale database result writes; it does not stop duplicate inference or irreversible external side effects.
- Lease recovery is polling-based; process crash while calling Ollama may waste compute. Redis notifications are hints, not task ownership.
- `publish` only persists report text in PostgreSQL; no external email, payment or web publishing. A real side effect requires an idempotency key, durable external-delivery outbox, retry policy and reconciliation.
- Database schema uses `CREATE TABLE IF NOT EXISTS` as a learning convenience. Use Alembic migrations before a real deployment.
- Vector search computes cosine similarity over user chunks in Python, which is deliberately simple but does not scale. Upgrade to `pgvector` with HNSW/IVFFlat and tenant-scoped indexed queries.
- PostgreSQL and Redis use demo credentials inside the Compose file; replace credentials and add secret management, backups, TLS, firewall, monitoring, alerts, retention, quotas and a complete integration test suite before real users.
- The unit tests run without PostgreSQL, Redis or Ollama. Run end-to-end experiments manually on your machine.

## Project structure

```text
app/
  server.py        API, auth, user-scoped documents/workflows/evals/metrics
  security.py      scrypt, bearer tokens
  rag.py           Ollama embedding + cosine retrieval
  store.py         durable DAG, quotas, leases, approval, outbox writes
  outbox.py        Redis relay
  worker.py        isolated node execution + real retrieval trace
  db.py            PostgreSQL schema
  trace_evals.py   deterministic eval + regression comparison
  observability.py structured logs + timings
  policy.py        DAG validation
  prompts.py       role prompts
  config.py        settings
static/index.html  browser console
evals/            gold cases and explicitly synthetic example traces
tests/            offline unit tests
```

### CI

`.github/workflows/ci.yml` runs the 13 offline tests and synthetic fixture checks. It does not launch Ollama or certify production quality. To enforce real candidate quality, add a trusted job that generates fresh traces, applies human-labelled gold cases and runs `eval_offline.py --baseline ...`.
