# Lesson 22 — Agent SaaS Architecture Lab

PostgreSQL + Redis wake-up queue + FastAPI + independently scalable DAG workers + local Ollama `qwen3-local` + tenant quotas + human approval + structural Evals.

**Teaching architecture, not production certified.** This is a *standalone* architecture lab, not an in-place migration of Lesson 21. In particular, it intentionally omits Lesson 21's RAG/document ingestion and user registration. Tenant auth is demo static bearer keys. It does not yet implement a full Golden Dataset regression harness or human-labelled factuality evaluation.

## Quick start (macOS)

1. Start Ollama on host and check `ollama list` contains `qwen3-local`.
2. From project folder: `docker compose up --build -d`.
3. Open http://127.0.0.1:8000 and enter `demo-a` (tenant A) or `demo-b` (tenant B). These credentials are **demo only**; change `API_KEYS` in environment for any shared deployment.
4. Create a workflow. Three research nodes can be claimed in parallel by different workers. To add a worker: `docker compose up -d --scale worker=2`.
5. Once workflow reaches `waiting_approval`, inspect `write` output and click approve or reject.
6. Check `/api/workflows/{id}/eval` for structural checks.
7. Run tests: `python -m pip install -r requirements.txt && python -m pytest -q`.

For host Ollama, the container uses `http://host.docker.internal:11434`. If unreachable, configure Ollama to listen on an address reachable from Docker, but **never expose Ollama directly to the internet**.

## API

- `GET /health` — liveness
- `POST /api/workflows` — create (`{"goal":"..."}`)
- `GET /api/workflows` — tenant history
- `GET /api/workflows/{id}` — nodes and results
- `GET /api/workflows/{id}/events` — trace events
- `GET /api/workflows/{id}/eval` — deterministic structural Evals
- `POST /api/workflows/{id}/approve` — `{"reviewer":"local-operator"}`
- `POST /api/workflows/{id}/reject` — same payload
- `POST /api/workflows/{id}/cancel` — cooperative cancellation

All `/api` routes require `Authorization: Bearer demo-a` (or `demo-b`). Use separate browsers or curl to verify tenant isolation.

## Key architecture lessons

- PostgreSQL is authoritative. Redis only sends wake-up hints; the worker polls PostgreSQL periodically, so dropped Redis messages do not permanently lose jobs.
- `SELECT ... FOR UPDATE SKIP LOCKED` prevents two workers claiming the same node.
- Leases + heartbeat + fencing tokens allow stale workers to be rejected on result commit. A lease expiring causes a retry (up to 3 attempts). This provides **at-least-once execution**, not exactly-once external side effects.
- Dependencies must be completed before a node can be claimed. Three independent research nodes are eligible in parallel.
- Approval blocks publishing; only a tenant-authenticated request can transition the workflow from `waiting_approval` to `running`.
- Tenant quotas use PostgreSQL row locking: 3 active workflows and 20 created workflows per UTC database day by default.
- Structural Evals inspect node completion, report presence, approval and publish consistency; these are **not** semantic factuality or complete Agent Evals.

## Known limitations and next improvements

1. `API_KEYS` uses static demo tokens, and approval `reviewer` is unverified. Replace with account login, hashed API keys, RBAC, audit identity, and CSRF protection as applicable.
2. Redis wake-up list can grow and is not a durable result queue. PostgreSQL scanner is the actual reliable job source.
3. Workers use sync Ollama HTTP requests, with heartbeat thread. Multiple workers may saturate one local model. Benchmark and limit concurrent inference.
4. A worker crash after an external side effect can cause duplicate execution. Implement idempotency keys and a transactional outbox for real write tools.
5. Retry is immediate, without backoff or dead-letter queue. Add retry scheduling, jitter, error classification and administrative retry.
6. Database schema uses `CREATE TABLE IF NOT EXISTS`; use Alembic migrations for production.
7. No real knowledge-base ingestion, RAG embeddings, document source citations or full multi-agent trace evaluation in this standalone lab. Integrate those modules explicitly after the architecture is understood.
8. Polling dashboard is intentionally minimal. Add SSE/WebSocket and richer DAG visualization later.
9. The default PostgreSQL password and API keys are for local teaching only. Use secrets management, TLS, private networks, backups, monitoring and per-tenant cost budgets before deployment.
10. A long-running Ollama request may continue computing after cancellation. Stale writes are rejected, but compute is not necessarily interrupted.

## Exercises

A. Run `docker compose up -d --scale worker=2`, create a workflow, inspect `docker compose logs -f worker` and node statuses.

B. Stop workers while a task is running; restart them after lease expiry. Check events for `lease_expired` and that already completed nodes are not redone.

C. Try accessing a tenant A workflow using tenant B token; expect 404.

D. Create four workflows in tenant A; fourth should be rejected while three are active.

E. Reject a workflow and verify no `publish` result is created.

F. Extend the structural Evals to require a reviewer JSON schema and evidence references. Then connect your Lesson 20 Golden Dataset evaluator to the stored event trace.
