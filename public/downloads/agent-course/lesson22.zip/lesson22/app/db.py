from contextlib import contextmanager
import psycopg
from psycopg.rows import dict_row
from .config import DATABASE_URL

@contextmanager
def connect():
    with psycopg.connect(DATABASE_URL,row_factory=dict_row) as conn:
        yield conn

SCHEMA='''
CREATE TABLE IF NOT EXISTS workflows (
 id uuid PRIMARY KEY, tenant text NOT NULL, goal text NOT NULL,
 status text NOT NULL DEFAULT 'running', created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS nodes (
 workflow_id uuid NOT NULL REFERENCES workflows(id), id text NOT NULL, kind text NOT NULL,
 deps jsonb NOT NULL, status text NOT NULL DEFAULT 'pending', result text,
 attempts integer NOT NULL DEFAULT 0, lease_until timestamptz,
 owner text, fencing bigint NOT NULL DEFAULT 0, error text,
 PRIMARY KEY(workflow_id,id));
CREATE TABLE IF NOT EXISTS approvals (
 workflow_id uuid PRIMARY KEY REFERENCES workflows(id), tenant text NOT NULL,
 decision text NOT NULL, reviewer text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS events (
 id bigserial PRIMARY KEY, workflow_id uuid NOT NULL REFERENCES workflows(id),
 kind text NOT NULL, node text, detail text, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS quotas (
 tenant text NOT NULL, day date NOT NULL, used integer NOT NULL DEFAULT 0,
 PRIMARY KEY(tenant,day));
CREATE INDEX IF NOT EXISTS idx_nodes_status ON nodes(status,lease_until);
'''

def init():
    with connect() as conn:
        for statement in SCHEMA.split(';'):
            if statement.strip():conn.execute(statement)
