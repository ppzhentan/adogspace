import os,time,threading,uuid,logging
import httpx
from . import store,queue
from .prompts import prompt_for
from .config import OLLAMA_URL,MODEL,LEASE_SECONDS
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(message)s')
LOG=logging.getLogger('worker')


def run_model(prompt):
    with httpx.Client(timeout=90) as client:
        r=client.post(f'{OLLAMA_URL}/api/chat',json={'model':MODEL,'stream':False,'messages':[{'role':'system','content':'你是谨慎的业务分析Agent，不得虚构数据。'},{'role':'user','content':prompt}]})
        r.raise_for_status()
        return r.json()['message']['content']

def work_one(worker):
    task=store.claim(worker)
    if not task:return False
    wid,node,token=task['workflow_id'],task['id'],task['fencing']
    stop=threading.Event()
    def pulse():
        while not stop.wait(max(2,LEASE_SECONDS//3)):
            try:
                if not store.heartbeat(wid,node,worker,token):return
            except Exception:LOG.exception('heartbeat failure')
    thread=threading.Thread(target=pulse,daemon=True);thread.start()
    try:
        ctx=store.node_context(wid)
        p=prompt_for(node,task['goal'],ctx)
        result=p if node=='publish' else run_model(p)
        if store.finish(wid,node,worker,token,result):LOG.info('completed %s/%s',wid,node)
        else:LOG.warning('stale completion ignored %s/%s',wid,node)
    except Exception as exc:
        store.fail(wid,node,worker,token,str(exc));LOG.exception('node failure %s/%s',wid,node)
    finally:
        stop.set();thread.join(timeout=1)
    return True

def main():
    worker=f'{os.getpid()}-{uuid.uuid4().hex[:8]}'
    while True:
        try:
            store.recover()
            if work_one(worker):continue
            try:queue.client().brpop('agent:wake',timeout=2)
            except Exception:time.sleep(2)
        except Exception:LOG.exception('worker loop failure');time.sleep(2)
if __name__=='__main__':main()
