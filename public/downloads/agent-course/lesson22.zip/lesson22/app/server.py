from fastapi import FastAPI,Depends,HTTPException,Header
from fastapi.responses import HTMLResponse
from pydantic import BaseModel,Field
from pathlib import Path
from . import db,store,queue
from .config import API_KEYS
from .policy import tenant_for_token
from .evals import evaluate

app=FastAPI(title='Lesson 22 Agent Platform')
@app.on_event('startup')
def startup():db.init()

def tenant(authorization:str=Header(default='')):
    if not authorization.startswith('Bearer '):raise HTTPException(401,'Missing token')
    t=tenant_for_token(authorization[7:],API_KEYS)
    if not t:raise HTTPException(401,'Invalid token')
    return t

class Create(BaseModel):goal:str=Field(min_length=5,max_length=2000)
class Approval(BaseModel):reviewer:str=Field(min_length=1,max_length=100)

@app.get('/',response_class=HTMLResponse)
def index():return (Path(__file__).resolve().parent.parent/'static/index.html').read_text()
@app.get('/health')
def health():return {'status':'ok'}
@app.post('/api/workflows')
def create(body:Create,t:str=Depends(tenant)):
    try:wid=store.create(t,body.goal)
    except ValueError as e:raise HTTPException(429,str(e))
    queue.wake();return {'id':wid}
@app.get('/api/workflows')
def history(t:str=Depends(tenant)):return store.history(t)
@app.get('/api/workflows/{wid}')
def detail(wid:str,t:str=Depends(tenant)):
    try:obj=store.get(t,wid)
    except Exception:raise HTTPException(404)
    if not obj:raise HTTPException(404)
    return obj
@app.get('/api/workflows/{wid}/events')
def events(wid:str,t:str=Depends(tenant)):
    if not store.get(t,wid):raise HTTPException(404)
    return store.events(t,wid)
@app.get('/api/workflows/{wid}/eval')
def evals(wid:str,t:str=Depends(tenant)):
    obj=store.get(t,wid)
    if not obj:raise HTTPException(404)
    return evaluate(obj)
@app.post('/api/workflows/{wid}/approve')
def approve(wid:str,body:Approval,t:str=Depends(tenant)):
    if not store.decision(t,wid,True,body.reviewer):raise HTTPException(409,'Not awaiting approval or not found')
    queue.wake();return {'status':'approved'}
@app.post('/api/workflows/{wid}/reject')
def reject(wid:str,body:Approval,t:str=Depends(tenant)):
    if not store.decision(t,wid,False,body.reviewer):raise HTTPException(409,'Not awaiting approval or not found')
    return {'status':'rejected'}
@app.post('/api/workflows/{wid}/cancel')
def cancel(wid:str,t:str=Depends(tenant)):
    if not store.cancel(t,wid):raise HTTPException(409,'Cannot cancel')
    return {'status':'cancelled'}
