import uuid,json
from .db import connect
from .policy import plan,valid_plan
from .config import MAX_ACTIVE,DAILY_LIMIT,LEASE_SECONDS

def create(tenant,goal):
    nodes=plan()
    if not valid_plan(nodes):raise ValueError('invalid DAG')
    wid=str(uuid.uuid4())
    with connect() as c:
        with c.transaction():
            c.execute('INSERT INTO quotas(tenant,day,used) VALUES (%s,current_date,0) ON CONFLICT DO NOTHING',(tenant,))
            row=c.execute('SELECT used FROM quotas WHERE tenant=%s AND day=current_date FOR UPDATE',(tenant,)).fetchone()
            active=c.execute("SELECT count(*) n FROM workflows WHERE tenant=%s AND status IN ('running','waiting_approval')",(tenant,)).fetchone()['n']
            if row['used']>=DAILY_LIMIT:raise ValueError('daily quota exceeded')
            if active>=MAX_ACTIVE:raise ValueError('concurrency quota exceeded')
            c.execute('UPDATE quotas SET used=used+1 WHERE tenant=%s AND day=current_date',(tenant,))
            c.execute('INSERT INTO workflows(id,tenant,goal) VALUES (%s,%s,%s)',(wid,tenant,goal))
            for n in nodes:c.execute('INSERT INTO nodes(workflow_id,id,kind,deps) VALUES (%s,%s,%s,%s::jsonb)',(wid,n['id'],n['kind'],json.dumps(n['deps'])))
            c.execute('INSERT INTO events(workflow_id,kind) VALUES (%s,%s)',(wid,'created'))
    return wid

def get(tenant,wid):
    with connect() as c:
        w=c.execute('SELECT * FROM workflows WHERE id=%s AND tenant=%s',(wid,tenant)).fetchone()
        if not w:return None
        ns=c.execute('SELECT id,kind,deps,status,result,attempts,error FROM nodes WHERE workflow_id=%s ORDER BY id',(wid,)).fetchall()
        return {'workflow':w,'nodes':ns}

def history(tenant):
    with connect() as c:return c.execute('SELECT * FROM workflows WHERE tenant=%s ORDER BY created_at DESC LIMIT 50',(tenant,)).fetchall()

def claim(worker):
    # Lock one eligible node; no worker can claim the same row concurrently.
    with connect() as c:
        with c.transaction():
            rows=c.execute('''SELECT n.workflow_id,n.id,n.kind,n.deps,n.fencing,w.goal
            FROM nodes n JOIN workflows w ON w.id=n.workflow_id
            WHERE w.status='running' AND n.status='pending'
            ORDER BY w.created_at,n.id FOR UPDATE OF n SKIP LOCKED LIMIT 60''').fetchall()
            for n in rows:
                deps=c.execute('SELECT id,status FROM nodes WHERE workflow_id=%s',(n['workflow_id'],)).fetchall()
                states={x['id']:x['status'] for x in deps}
                if not all(states.get(d)=='completed' for d in n['deps']):continue
                if n['kind']=='approval':
                    c.execute("UPDATE nodes SET status='waiting_approval' WHERE workflow_id=%s AND id=%s",(n['workflow_id'],n['id']))
                    c.execute("UPDATE workflows SET status='waiting_approval' WHERE id=%s",(n['workflow_id'],))
                    c.execute('INSERT INTO events(workflow_id,kind,node) VALUES (%s,%s,%s)',(n['workflow_id'],'approval_requested',n['id']))
                    continue
                token=n['fencing']+1
                c.execute('''UPDATE nodes SET status='running',owner=%s,attempts=attempts+1,
                    fencing=%s,lease_until=now()+(%s * interval '1 second')
                    WHERE workflow_id=%s AND id=%s''',(worker,token,LEASE_SECONDS,n['workflow_id'],n['id']))
                c.execute('INSERT INTO events(workflow_id,kind,node) VALUES (%s,%s,%s)',(n['workflow_id'],'started',n['id']))
                return {**n,'fencing':token}
    return None

def heartbeat(wid,node,worker,token):
    with connect() as c:
        return c.execute('''UPDATE nodes SET lease_until=now()+(%s * interval '1 second')
          WHERE workflow_id=%s AND id=%s AND owner=%s AND fencing=%s AND status='running'
          RETURNING id''',(LEASE_SECONDS,wid,node,worker,token)).fetchone() is not None

def finish(wid,node,worker,token,result):
    with connect() as c:
        with c.transaction():
            row=c.execute('''UPDATE nodes SET status='completed',result=%s,owner=NULL,lease_until=NULL
             WHERE workflow_id=%s AND id=%s AND owner=%s AND fencing=%s AND status='running'
             AND EXISTS(SELECT 1 FROM workflows w WHERE w.id=%s AND w.status='running') RETURNING id''',
             (result,wid,node,worker,token,wid)).fetchone()
            if not row:return False
            c.execute('INSERT INTO events(workflow_id,kind,node) VALUES (%s,%s,%s)',(wid,'completed',node))
            if node=='publish':c.execute("UPDATE workflows SET status='completed',updated_at=now() WHERE id=%s",(wid,))
            return True

def fail(wid,node,worker,token,error):
    with connect() as c:
        with c.transaction():
            row=c.execute('''UPDATE nodes SET status=CASE WHEN attempts<3 THEN 'pending' ELSE 'failed' END,
             error=%s,owner=NULL,lease_until=NULL WHERE workflow_id=%s AND id=%s AND owner=%s
             AND fencing=%s AND status='running' RETURNING status''',(error[:500],wid,node,worker,token)).fetchone()
            if not row:return
            c.execute('INSERT INTO events(workflow_id,kind,node,detail) VALUES (%s,%s,%s,%s)',(wid,'failed_attempt',node,error[:150]))
            if row['status']=='failed':c.execute("UPDATE workflows SET status='failed' WHERE id=%s AND status='running'",(wid,))

def recover():
    with connect() as c:
        with c.transaction():
            rows=c.execute("""UPDATE nodes SET status=CASE WHEN attempts<3 THEN 'pending' ELSE 'failed' END,
              owner=NULL,lease_until=NULL,fencing=fencing+1,error='lease expired'
              WHERE status='running' AND lease_until<now() RETURNING workflow_id,id,status""").fetchall()
            for r in rows:
                c.execute('INSERT INTO events(workflow_id,kind,node) VALUES (%s,%s,%s)',(r['workflow_id'],'lease_expired',r['id']))
                if r['status']=='failed':c.execute("UPDATE workflows SET status='failed' WHERE id=%s AND status='running'",(r['workflow_id'],))
    return len(rows)

def decision(tenant,wid,approve,reviewer):
    with connect() as c:
        with c.transaction():
            w=c.execute('SELECT status FROM workflows WHERE id=%s AND tenant=%s FOR UPDATE',(wid,tenant)).fetchone()
            if not w or w['status']!='waiting_approval':return False
            c.execute('INSERT INTO approvals(workflow_id,tenant,decision,reviewer) VALUES (%s,%s,%s,%s)',(wid,tenant,'approved' if approve else 'rejected',reviewer))
            c.execute("UPDATE nodes SET status=%s WHERE workflow_id=%s AND id='approval'",('completed' if approve else 'rejected',wid))
            c.execute('UPDATE workflows SET status=%s,updated_at=now() WHERE id=%s',('running' if approve else 'rejected',wid))
            c.execute('INSERT INTO events(workflow_id,kind,node) VALUES (%s,%s,%s)',(wid,'approved' if approve else 'rejected','approval'))
            return True

def cancel(tenant,wid):
    with connect() as c:
        with c.transaction():
            row=c.execute("""UPDATE workflows SET status='cancelled' WHERE id=%s AND tenant=%s
              AND status IN ('running','waiting_approval') RETURNING id""",(wid,tenant)).fetchone()
            if not row:return False
            c.execute("UPDATE nodes SET status='cancelled',fencing=fencing+1 WHERE workflow_id=%s AND status IN ('pending','running','waiting_approval')",(wid,))
            c.execute('INSERT INTO events(workflow_id,kind) VALUES (%s,%s)',(wid,'cancelled'))
            return True

def node_context(wid):
    with connect() as c:
        return c.execute('SELECT id,result FROM nodes WHERE workflow_id=%s AND status=%s',(wid,'completed')).fetchall()

def events(tenant,wid):
    with connect() as c:
        return c.execute('''SELECT e.* FROM events e JOIN workflows w ON w.id=e.workflow_id
          WHERE w.tenant=%s AND w.id=%s ORDER BY e.id''',(tenant,wid)).fetchall()
