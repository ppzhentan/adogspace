import os
DATABASE_URL=os.getenv('DATABASE_URL','postgresql://agent:agent@localhost:5432/agent')
REDIS_URL=os.getenv('REDIS_URL','redis://localhost:6379/0')
OLLAMA_URL=os.getenv('OLLAMA_URL','http://localhost:11434')
MODEL=os.getenv('OLLAMA_MODEL','qwen3-local')
API_KEYS=os.getenv('API_KEYS','demo-a:tenant-a,demo-b:tenant-b')
LEASE_SECONDS=int(os.getenv('LEASE_SECONDS','180'))
MAX_ACTIVE=int(os.getenv('MAX_ACTIVE','3'))
DAILY_LIMIT=int(os.getenv('DAILY_LIMIT','20'))
