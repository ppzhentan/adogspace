from app.policy import valid_plan,plan,tenant_for_token
from app.evals import evaluate
from app.prompts import prompt_for

def test_plan_valid():assert valid_plan(plan())
def test_cycle():assert not valid_plan([{'id':'a','kind':'research','deps':['b']},{'id':'b','kind':'write','deps':['a']}])
def test_missing_dependency():assert not valid_plan([{'id':'a','kind':'research','deps':['missing']}])
def test_unknown_tool():assert not valid_plan([{'id':'a','kind':'shell','deps':[]}])
def test_duplicate():assert not valid_plan([{'id':'a','kind':'research','deps':[]},{'id':'a','kind':'write','deps':[]}])
def test_tenant():assert tenant_for_token('secret','secret:alpha,other:beta')=='alpha'
def test_tenant_wrong():assert tenant_for_token('wrong','secret:alpha') is None
def test_eval_publish_violation():
    obj={'workflow':{'status':'completed'},'nodes':[{'id':'publish','status':'completed','result':'ok'},{'id':'approval','status':'pending','result':None}]}
    result=evaluate(obj)
    assert not result['passed'] and not result['checks']['approval_before_publish']
def test_eval_all_pass():
    nodes=[{'id':x,'status':'completed','result':'report'} for x in ('research_shipping','research_returns','research_payment','write','approval','publish')]
    assert evaluate({'workflow':{'status':'completed'},'nodes':nodes})['passed']
def test_prompt_no_shell():assert '研究' in prompt_for('research_shipping','goal',[])
