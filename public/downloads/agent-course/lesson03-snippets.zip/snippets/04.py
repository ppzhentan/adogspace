
import json
from openai import OpenAI

# 1. 连接本地 Ollama
client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama",
    timeout=120.0
)

MODEL = "qwen3-local"

# 2. 模拟订单数据库
ORDERS = {
    "A1001": {
        "price": 199,
        "cost": 120,
        "shipping": 25,
        "fee": 12
    },
    "A1002": {
        "price": 299,
        "cost": 100,
        "shipping": 20,
        "fee": 15
    }
}


# 3. 定义 Python 工具

def get_order(order_id: str):
    """查询订单"""
    if order_id not in ORDERS:
        return {"error": "订单不存在"}
    return ORDERS[order_id]


def calculate_profit(
    price: float,
    cost: float,
    shipping: float,
    fee: float
):
    """计算利润和利润率"""
    if price <= 0:
        return {"error": "售价必须大于0"}

    profit = price - cost - shipping - fee
    margin = profit / price * 100

    return {
        "profit": round(profit, 2),
        "margin": round(margin, 2)
    }


def calculate_target_price(
    cost: float,
    shipping: float,
    fee: float,
    target_margin: float
):
    """计算目标利润率对应的售价"""
    if not 0 <= target_margin < 100:
        return {"error": "目标利润率必须在0到100之间"}

    total_cost = cost + shipping + fee
    price = total_cost / (1 - target_margin / 100)

    return {
        "target_price": round(price, 2)
    }


# 4. 工具注册表
FUNCTIONS = {
    "get_order": get_order,
    "calculate_profit": calculate_profit,
    "calculate_target_price": calculate_target_price
}


# 5. 告诉模型有哪些工具
tools = [
    {
        "type": "function",
        "function": {
            "name": "get_order",
            "description": "根据订单编号查询订单信息",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "订单编号"
                    }
                },
                "required": ["order_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_profit",
            "description": "计算订单利润和利润率",
            "parameters": {
                "type": "object",
                "properties": {
                    "price": {"type": "number"},
                    "cost": {"type": "number"},
                    "shipping": {"type": "number"},
                    "fee": {"type": "number"}
                },
                "required": [
                    "price", "cost", "shipping", "fee"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_target_price",
            "description": "根据成本和目标利润率计算最低售价",
            "parameters": {
                "type": "object",
                "properties": {
                    "cost": {"type": "number"},
                    "shipping": {"type": "number"},
                    "fee": {"type": "number"},
                    "target_margin": {
                        "type": "number",
                        "description": "目标利润率百分比，例如30"
                    }
                },
                "required": [
                    "cost", "shipping",
                    "fee", "target_margin"
                ]
            }
        }
    }
]


# 6. Agent Loop 核心
def run_agent(task: str, max_steps: int = 8):

    messages = [
        {
            "role": "system",
            "content": (
                "你是一个电商利润分析助手。"
                "需要数据时必须调用工具，不要猜测订单数据。"
                "先查询订单，再根据结果进行计算。"
                "利润率是利润除以售价。"
                "工具返回错误时不要编造结果。"
                "用中文回答，清楚列出计算过程。"
            )
        },
        {
            "role": "user",
            "content": task
        }
    ]

    for step in range(max_steps):

        print(f"\n========== 第 {step + 1} 轮 ==========")

        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=0
        )

        message = response.choices[0].message
        messages.append(message)

        # 没有工具调用，说明模型给出最终回答
        if not message.tool_calls:
            print("\nAgent 最终回答：")
            print(message.content or "模型未返回文本")
            return message.content

        # 逐个执行本轮工具调用
        for call in message.tool_calls:

            name = call.function.name

            print(f"\n调用工具：{name}")

            try:
                args = json.loads(
                    call.function.arguments
                )

                print("参数：", args)

                if name not in FUNCTIONS:
                    result = {
                        "error": f"不允许调用工具: {name}"
                    }
                elif not isinstance(args, dict):
                    result = {
                        "error": "工具参数必须是JSON对象"
                    }
                else:
                    result = FUNCTIONS[name](**args)

            except (ValueError, TypeError) as e:
                result = {"error": str(e)}

            print("工具结果：", result)

            # 把结果交还给模型
            messages.append({
                "role": "tool",
                "tool_call_id": call.id,
                "content": json.dumps(
                    result,
                    ensure_ascii=False
                )
            })

    print("\n达到最大执行轮数，Agent 停止。")
    return None


# 7. 启动 Agent
if __name__ == "__main__":

    run_agent(
        "分析订单A1001，计算利润和利润率。"
        "如果利润率低于30%，"
        "计算达到30%利润率需要的售价，"
        "并告诉我需要涨价多少。"
    )
