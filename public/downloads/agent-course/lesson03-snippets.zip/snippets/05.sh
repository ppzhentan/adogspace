python lesson03.py
