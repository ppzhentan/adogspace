while not finished:
    response = ask_model()
    if response.has_tool_calls:
        execute_tools()
    else:
        finished = True
