python lesson04.py
