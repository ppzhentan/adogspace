curl "https://api.frankfurter.dev/v1/latest?base=USD&symbols=CNY,JPY"
