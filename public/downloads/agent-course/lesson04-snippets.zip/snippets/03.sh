python -m pip install -U openai requests
