
import json
import requests
from openai import OpenAI

# =========================
# 1. 配置本地模型
# =========================

MODEL = "qwen3-local"

client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama",
    timeout=120.0
)

API_URL = "https://api.frankfurter.dev/v1/latest"

SUPPORTED = {"USD", "CNY", "JPY", "EUR", "GBP", "HKD"}


# =========================
# 2. 工具：查询真实汇率
# =========================

def get_exchange_rate(base: str, target: str):

    base = base.upper()
    target = target.upper()

    if base not in SUPPORTED or target not in SUPPORTED:
        return {"error": "不支持的货币代码"}

    if base == target:
        return {
            "base": base,
            "target": target,
            "rate": 1.0,
            "note": "相同货币无需查询"
        }

    try:
        response = requests.get(
            API_URL,
            params={
                "base": base,
                "symbols": target
            },
            timeout=15
        )

        response.raise_for_status()
        data = response.json()

        return {
            "base": base,
            "target": target,
            "rate": data["rates"][target],
            "date": data["date"],
            "source": "Frankfurter API"
        }

    except (requests.RequestException, ValueError, KeyError) as e:
        return {
            "error": f"汇率查询失败: {str(e)}"
        }


# =========================
# 3. 工具：计算兑换金额
# =========================

def calculate_exchange(amount: float, rate: float):

    if amount < 0 or rate <= 0:
        return {"error": "金额或汇率无效"}

    return {
        "amount": amount,
        "rate": rate,
        "converted": round(amount * rate, 2)
    }


# =========================
# 4. 注册工具
# =========================

FUNCTIONS = {
    "get_exchange_rate": get_exchange_rate,
    "calculate_exchange": calculate_exchange
}

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_exchange_rate",
            "description": "通过外部API查询最新可用参考汇率",
            "parameters": {
                "type": "object",
                "properties": {
                    "base": {
                        "type": "string",
                        "description": "基础货币，例如USD"
                    },
                    "target": {
                        "type": "string",
                        "description": "目标货币，例如JPY"
                    }
                },
                "required": ["base", "target"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_exchange",
            "description": "根据已查询的汇率计算货币兑换金额",
            "parameters": {
                "type": "object",
                "properties": {
                    "amount": {
                        "type": "number",
                        "description": "原始金额"
                    },
                    "rate": {
                        "type": "number",
                        "description": "从汇率查询工具获取的汇率"
                    }
                },
                "required": ["amount", "rate"]
            }
        }
    }
]


# =========================
# 5. Agent Loop
# =========================

def run_agent(task, max_steps=8):

    messages = [
        {
            "role": "system",
            "content": (
                "你是一个专业的中文汇率分析助手。"
                "必须通过get_exchange_rate查询汇率，"
                "不得编造汇率或数据日期。"
                "通过calculate_exchange计算兑换金额。"
                "只能使用工具返回的有效数据。"
                "如果API返回错误，应说明失败原因，"
                "不能自行猜测汇率。"
                "最终回答必须包含汇率日期、来源、"
                "计算金额和货币单位。"
            )
        },
        {
            "role": "user",
            "content": task
        }
    ]

    for step in range(max_steps):

        print(f"\n========== 第 {step + 1} 轮 ==========")

        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                temperature=0
            )
        except Exception as e:
            print("模型调用失败：", e)
            return None

        message = response.choices[0].message
        messages.append(message)

        if not message.tool_calls:
            print("\n========== 最终回答 ==========")
            print(message.content or "模型没有返回答案")
            return message.content

        for call in message.tool_calls:

            name = call.function.name

            print("\n调用工具：", name)

            try:
                args = json.loads(
                    call.function.arguments
                )

                if not isinstance(args, dict):
                    result = {
                        "error": "参数必须是JSON对象"
                    }

                elif name not in FUNCTIONS:
                    result = {
                        "error": "未知工具"
                    }

                else:
                    print("工具参数：", args)

                    result = FUNCTIONS[name](**args)

            except (ValueError, TypeError, KeyError) as e:
                result = {"error": str(e)}

            print("工具结果：", result)

            messages.append({
                "role": "tool",
                "tool_call_id": call.id,
                "content": json.dumps(
                    result,
                    ensure_ascii=False
                )
            })

    print("\n达到最大执行轮数，任务停止。")
    return None


# =========================
# 6. 启动 Agent
# =========================

if __name__ == "__main__":

    run_agent(
        "查询最新可用的美元兑人民币、"
        "美元兑日元参考汇率。"
        "假设我有1000美元，"
        "分别可以兑换多少人民币和日元？"
        "请给出汇率日期和数据来源。"
    )
