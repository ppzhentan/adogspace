import pytest
from app.rag import chunks,validate_vector,DIM
from app.trace_evals import score,compare
from pathlib import Path

def test_dim():assert DIM==768

def test_valid_vector():assert validate_vector([0]*DIM).startswith('[')
@pytest.mark.parametrize('v',[[0]*767,[0]*769,[True]*768])
def test_bad_vector(v):
    with pytest.raises(ValueError):validate_vector(v)
def test_chunks():assert chunks('abc',size=2,overlap=1)==['ab','bc','c']
def test_regression():
    result=compare([{'case_id':'x','passed':True}],[{'case_id':'x','passed':False}])
    assert result['regressions']==['x']
def test_migration_index():
    s=Path('migrations/versions/0001_initial.py').read_text()
    assert 'vector_cosine_ops' in s and 'vector(768)' in s
def test_no_schema_autocreate():
    import ast
    tree=ast.parse(Path('app/db.py').read_text())
    assert 'init' not in [n.name for n in tree.body if isinstance(n,ast.FunctionDef)]
def test_no_prompt_in_spans():
    pytest.importorskip('opentelemetry.instrumentation.fastapi')
    from app.telemetry import traced
    with traced('test',prompt='secret',node='research') as span:
        assert 'prompt' not in getattr(span,'attributes',{})
