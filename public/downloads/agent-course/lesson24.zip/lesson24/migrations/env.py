from alembic import context
from sqlalchemy import engine_from_config,pool
from logging.config import fileConfig
import os
config=context.config
config.set_main_option('sqlalchemy.url',os.environ.get('DATABASE_URL','postgresql://agent:agent@localhost:5432/agent').replace('postgresql://','postgresql+psycopg://',1))
def run_migrations_online():
    engine=engine_from_config(config.get_section(config.config_ini_section),prefix='sqlalchemy.',poolclass=pool.NullPool)
    with engine.connect() as connection:
        context.configure(connection=connection,transactional_ddl=True)
        with context.begin_transaction():context.run_migrations()
run_migrations_online()
