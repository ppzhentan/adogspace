"""Initial schema: lesson23 domain + pgvector 768."""
from alembic import op
revision='0001_initial'
down_revision=None
branch_labels=None
depends_on=None

def upgrade():
    op.execute('CREATE EXTENSION IF NOT EXISTS vector')
    op.execute("""CREATE TABLE users(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),email text UNIQUE NOT NULL,salt text NOT NULL,password_hash text NOT NULL)""")
    op.execute("""CREATE TABLE sessions(token_hash text PRIMARY KEY,user_id uuid NOT NULL REFERENCES users(id),expires_at timestamptz NOT NULL)""")
    op.execute("""CREATE TABLE workflows(id uuid PRIMARY KEY,tenant text NOT NULL,goal text NOT NULL,status text NOT NULL DEFAULT 'running',created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),user_id uuid REFERENCES users(id))""")
    op.execute("""CREATE TABLE nodes(workflow_id uuid NOT NULL REFERENCES workflows(id),id text NOT NULL,kind text NOT NULL,deps jsonb NOT NULL,status text NOT NULL DEFAULT 'pending',result text,attempts integer NOT NULL DEFAULT 0,lease_until timestamptz,owner text,fencing bigint NOT NULL DEFAULT 0,error text,PRIMARY KEY(workflow_id,id))""")
    op.execute("""CREATE TABLE approvals(workflow_id uuid PRIMARY KEY REFERENCES workflows(id),tenant text NOT NULL,decision text NOT NULL,reviewer text NOT NULL,created_at timestamptz NOT NULL DEFAULT now())""")
    op.execute("""CREATE TABLE events(id bigserial PRIMARY KEY,workflow_id uuid NOT NULL REFERENCES workflows(id),kind text NOT NULL,node text,detail text,created_at timestamptz NOT NULL DEFAULT now())""")
    op.execute("""CREATE TABLE quotas(tenant text NOT NULL,day date NOT NULL,used integer NOT NULL DEFAULT 0,PRIMARY KEY(tenant,day))""")
    op.execute("""CREATE TABLE documents(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),user_id uuid NOT NULL REFERENCES users(id),name text NOT NULL,body text NOT NULL,created_at timestamptz DEFAULT now())""")
    op.execute("""CREATE TABLE doc_chunks(document_id uuid NOT NULL REFERENCES documents(id),user_id uuid NOT NULL REFERENCES users(id),ordinal integer NOT NULL,body text NOT NULL,embedding vector(768) NOT NULL,PRIMARY KEY(document_id,ordinal))""")
    op.execute("""CREATE TABLE outbox(id bigserial PRIMARY KEY,kind text NOT NULL,payload jsonb NOT NULL,created_at timestamptz DEFAULT now(),delivered_at timestamptz,attempts integer NOT NULL DEFAULT 0)""")
    op.execute("""CREATE TABLE traces(workflow_id uuid PRIMARY KEY REFERENCES workflows(id),user_id uuid NOT NULL REFERENCES users(id),trace jsonb NOT NULL,score jsonb NOT NULL,created_at timestamptz DEFAULT now())""")
    op.execute("""CREATE TABLE audit(id bigserial PRIMARY KEY,user_id uuid NOT NULL REFERENCES users(id),workflow_id uuid,action text NOT NULL,created_at timestamptz DEFAULT now())""")
    op.execute('CREATE INDEX idx_nodes_status ON nodes(status,lease_until)')
    op.execute('CREATE INDEX idx_doc_chunks_user ON doc_chunks(user_id)')
    op.execute('CREATE INDEX idx_outbox_pending ON outbox(id) WHERE delivered_at IS NULL')
    op.execute('CREATE INDEX idx_doc_chunks_hnsw ON doc_chunks USING hnsw (embedding vector_cosine_ops)')

def downgrade():
    for table in ('audit','traces','outbox','doc_chunks','documents','quotas','events','approvals','nodes','workflows','sessions','users'):
        op.execute('DROP TABLE '+table+' CASCADE')
    # Keep vector extension: other applications may use it.
