"""CI gate: evaluate fresh, persisted executions, not checked-in sample traces."""
import argparse,json,sys
from app.real_evals import evaluate_workflow
from app.trace_evals import compare

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest',required=True,help='JSONL records with user_id, workflow_id, gold, case_id')
    p.add_argument('--baseline',required=True,help='JSONL previous verified results')
    p.add_argument('--min-rate',type=float,default=.95)
    a=p.parse_args()
    cases=[json.loads(x) for x in open(a.manifest) if x.strip()]
    if not cases:raise SystemExit('empty manifest')
    current=[]
    for item in cases:
        ev=evaluate_workflow(item['user_id'],item['workflow_id'],item['gold'])
        current.append({'case_id':item['case_id'],'passed':ev['result']['passed']})
    baseline=[json.loads(x) for x in open(a.baseline) if x.strip()]
    comparison=compare(baseline,current)
    print(json.dumps({'cases':current,'comparison':comparison},ensure_ascii=False,indent=2))
    return 0 if not comparison['regressions'] and comparison['candidate_rate']>=a.min_rate else 1
if __name__=='__main__':sys.exit(main())
