# Lesson 24 — Agent SaaS Performance, Observability and Release Engineering

This project **extends Lesson 23** with pgvector, Alembic, OpenTelemetry, Prometheus, Grafana and a real-trace CI gate. It remains a **local/private training system**, not public production-ready software.

## Start

```bash
cp .env.example .env
# Edit both passwords to strong unique values
ollama list  # qwen3-local and embeddinggemma required
docker compose up --build -d
docker compose ps
```

- Workspace: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Prometheus: http://127.0.0.1:9090
- Grafana: http://127.0.0.1:3000
- Jaeger: http://127.0.0.1:16686

Docker Desktop on macOS must allow `host.docker.internal:11434` access to Ollama. The `migrate` one-shot service must finish successfully before API/Worker start.

## Migration

```bash
docker compose run --rm migrate alembic current
docker compose run --rm migrate alembic history
```

**Important:** This is a fresh-install migration. Do **not** point this Compose stack at an existing Lesson 23 volume: its old `jsonb` embeddings and missing Alembic version state need a separate reviewed data migration and backup. Never delete a real volume to avoid writing a migration. The default stack uses its own Compose project volume.

The HNSW cosine index is approximate. Filter by user ID on every retrieval. Highly selective tenant filtering can reduce recall; compare against exact retrieval on a labelled benchmark and consider partitioning or tenant-aware indexes. `embeddinggemma` is expected to return 768 dimensions; verify before importing real data.

## Evaluation

```bash
python -m pytest -q
python eval_offline.py --trace evals/sample_trace.jsonl --gold evals/gold.jsonl --min-rate 1
```

Offline CI only tests fixtures and code. A **real gate** needs fresh persisted executions. Run an approved test dataset through the actual API and Worker, obtain each workflow UUID, then create `manifest.jsonl` with records:

```json
{"case_id":"shipping-01","user_id":"<user UUID>","workflow_id":"<actual workflow UUID>","gold":{"required_sources":["shipping.md"],"required_facts":["6999"],"forbidden_claims":["5000"]}}
```

Provide a verified baseline file with one JSON object per line (`case_id`, `passed`). Execute:

```bash
python real_eval_gate.py --manifest manifest.jsonl --baseline baseline.jsonl --min-rate 0.95
```

This gate queries **real database events**, and fails on regressions or insufficient pass rate. The test runner must have access to the database and must use trusted user/workflow IDs. Do not auto-approve real customer workflows. The golden set must include human-labelled expected facts and adversarial cases. Current rule-based factuality uses substring matching and is not semantic entailment; use manual audits for release-critical claims.

## Observability

- `/metrics`: workflow status and outbox gauges, HTTP metrics via FastAPI instrumentation if configured, worker node duration counters are **worker-local** and not exposed by API. Add a worker metrics endpoint/collector to graph those metrics centrally.
- Jaeger: OTLP spans from API and Worker; cross-process parent-child linking is **not yet implemented**, so traces are per-service, not end-to-end correlated.
- Avoid prompt, document, email, auth token and other sensitive data in trace attributes.

## Production security checklist

- [ ] Reverse proxy TLS, real domain, hardened cookies/session design, CSRF protection if using cookies
- [ ] Real RBAC and admin controls, account recovery, abuse protection and per-user rate limiting
- [ ] PostgreSQL and Redis authentication/TLS and private network isolation
- [ ] Database backups **and restore drills**, tested Alembic forward/back migrations
- [ ] Secrets manager instead of Compose plaintext environment variables
- [ ] Tenant-isolation integration tests, audit log integrity and data retention policy
- [ ] HNSW recall benchmarks, embedding model/dimension versioning and reindexing strategy
- [ ] Real trace Evals CI gate on trusted self-hosted runner, with human-labelled golden data
- [ ] Worker failure injection, outbox duplication tests and idempotency for external side effects
- [ ] Prometheus/Grafana auth, metrics network restriction and alerting
- [ ] Resource limits, capacity planning, incident response and dependency image updates

Do not expose these demo ports directly to the internet.
