"""Tenant-scoped pgvector RAG. embeddinggemma produces 768-dimensional vectors."""
import re,json
import httpx
from .config import OLLAMA_URL,EMBED_MODEL
DIM=768

def chunks(text,size=1100,overlap=120):
    if size<=overlap or overlap<0:raise ValueError('invalid chunk settings')
    return [text[i:i+size] for i in range(0,len(text),size-overlap)]

def validate_vector(v):
    if len(v)!=DIM or any(not isinstance(x,(int,float)) or isinstance(x,bool) for x in v):
        raise ValueError(f'embedding must be {DIM} numeric dimensions')
    return '['+','.join(str(float(x)) for x in v)+']'

def embedding(text):
    with httpx.Client(timeout=120) as client:
        r=client.post(f'{OLLAMA_URL}/api/embed',json={'model':EMBED_MODEL,'input':text})
        r.raise_for_status();return r.json()['embeddings'][0]

def add_document(user_id,name,body,embed=embedding):
    if not re.fullmatch(r'[\w .-]{1,100}',name) or not body.strip() or len(body)>40000:raise ValueError('invalid document')
    parts=chunks(body)
    vectors=[validate_vector(embed(x)) for x in parts]
    from .db import connect
    with connect() as c:
        with c.transaction():
            d=c.execute('INSERT INTO documents(user_id,name,body) VALUES (%s,%s,%s) RETURNING id',(user_id,name,body)).fetchone()['id']
            for i,(part,v) in enumerate(zip(parts,vectors)):
                c.execute('INSERT INTO doc_chunks(document_id,user_id,ordinal,body,embedding) VALUES (%s,%s,%s,%s,%s::vector)',(d,user_id,i,part,v))
    return str(d)

def retrieve(user_id,query,limit=4,embed=embedding):
    v=validate_vector(embed(query))
    from .db import connect
    with connect() as c:
        # Index applies approximate HNSW candidate search. Tenant filter is mandatory.
        # For small datasets or high tenant selectivity, compare against exact scan.
        rows=c.execute("""SELECT c.body,d.name,d.id AS document_id,c.ordinal,
            (1-(c.embedding <=> %s::vector)) AS score
            FROM doc_chunks c JOIN documents d ON d.id=c.document_id
            WHERE c.user_id=%s AND d.user_id=%s
            ORDER BY c.embedding <=> %s::vector LIMIT %s""",
            (v,user_id,user_id,v,max(1,min(limit,20)))).fetchall()
    return [{'score':float(r['score']),'body':r['body'],'source':r['name'],
             'document_id':str(r['document_id']),'chunk':r['ordinal']} for r in rows]

# Kept for backward-compatible offline unit tests; production retrieval is pgvector SQL.
def cosine(a,b):
    import math
    if len(a)!=len(b) or not a:return 0.0
    den=math.sqrt(sum(x*x for x in a))*math.sqrt(sum(x*x for x in b))
    return sum(x*y for x,y in zip(a,b))/den if den else 0.0
