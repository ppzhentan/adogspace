"""Evaluate actual persisted workflow traces; never manufacture successful events."""
import json
from .trace_evals import score
from . import store

def evaluate_workflow(user_id,wid,gold):
    obj=store.get(user_id,wid,user_id)
    if not obj:raise ValueError('workflow not found')
    evs=store.events(user_id,wid,user_id)
    nodes={n['id']:n for n in obj['nodes']}
    tools=[];sources=set()
    for e in evs:
        if e['kind']=='tool_call':
            detail=json.loads(e['detail'])
            tools.append({'name':detail.get('name','')})
            sources.update(detail.get('sources',[]))
    trace={'answer':nodes.get('write',{}).get('result') or '',
           'tool_calls':tools,'sources':sorted(sources),
           'events':[{'kind':e['kind']} for e in evs]}
    return {'workflow_id':str(wid),'result':score(trace,gold),'trace':trace}
