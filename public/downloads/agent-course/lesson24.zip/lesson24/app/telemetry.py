"""OpenTelemetry spans and bounded-cardinality Prometheus metrics."""
from contextlib import contextmanager
from prometheus_client import Gauge,Histogram,Counter
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
import os
WORKFLOWS=Gauge('agent_workflows','Workflows by status',['status'])
OUTBOX=Gauge('agent_outbox_pending','Undelivered outbox rows')
NODE_LATENCY=Histogram('agent_node_duration_seconds','Node execution duration',['node'])
NODE_FAILURES=Counter('agent_node_failures_total','Node failures',['node'])
_started=False

def setup_telemetry(app=None):
    global _started
    if not _started:
        provider=TracerProvider(resource=Resource.create({'service.name':os.getenv('OTEL_SERVICE_NAME','agent-api')}))
        endpoint=os.getenv('OTEL_EXPORTER_OTLP_ENDPOINT','')
        if endpoint:provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint.rstrip('/')+'/v1/traces')))
        trace.set_tracer_provider(provider)
        _started=True
    if app is not None:FastAPIInstrumentor.instrument_app(app)

@contextmanager
def traced(name,**attrs):
    with trace.get_tracer('agent-saas').start_as_current_span(name) as span:
        for k,v in attrs.items():
            if k not in ('user_id','tenant','goal','prompt','answer','document'):
                span.set_attribute(k,str(v))
        yield span

def collect_db_metrics():
    from .db import connect
    with connect() as c:
        rows=c.execute('SELECT status,count(*) n FROM workflows GROUP BY status').fetchall()
        for status in ('running','waiting_approval','completed','cancelled','failed','rejected'):
            WORKFLOWS.labels(status=status).set(0)
        for r in rows:
            if r['status'] in ('running','waiting_approval','completed','cancelled','failed','rejected'):
                WORKFLOWS.labels(status=r['status']).set(r['n'])
        OUTBOX.set(c.execute('SELECT count(*) n FROM outbox WHERE delivered_at IS NULL').fetchone()['n'])
