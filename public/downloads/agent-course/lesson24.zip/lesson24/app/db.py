"""Schema is managed exclusively by Alembic. Never auto-DDL at API startup."""
from contextlib import contextmanager
import psycopg
from psycopg.rows import dict_row
from .config import DATABASE_URL
@contextmanager
def connect():
    with psycopg.connect(DATABASE_URL,row_factory=dict_row) as conn:
        yield conn
