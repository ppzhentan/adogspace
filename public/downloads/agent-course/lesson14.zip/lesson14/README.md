# Lesson 14 — 可观测性与可靠任务队列

## 本地运行

```bash
python -m pip install -r requirements.txt
export API_TOKEN=$(python -c 'import secrets;print(secrets.token_urlsafe(32))')
python worker.py                 # 终端 1
uvicorn server:app --host 127.0.0.1 --port 8000  # 终端 2
```

```bash
curl -X POST http://127.0.0.1:8000/api/jobs \
  -H "Authorization: Bearer $API_TOKEN" \
  -H 'Idempotency-Key: lesson14-test-1' \
  -H 'Content-Type: application/json' \
  -d '{"question":"用三句话解释 Agent Checkpoint"}'
```

使用返回的 `job_id` 查询 `/api/jobs/{job_id}`，或查看 `/api/metrics`。

## Docker

```bash
printf 'API_TOKEN=%s\n' "$(python -c 'import secrets;print(secrets.token_urlsafe(32))')" > .env
chmod 600 .env
docker compose up --build -d
```

容器通过 `host.docker.internal:11434` 访问宿主机 Ollama。macOS 上 Ollama 监听地址可能需要调整，**不要把 Ollama 暴露到公网**。

## 实现边界

- 本课独立演示可观测性和队列；不包含第十三课的多用户与 RAG。要集成到原项目，请复用 `store.py` 的队列设计和 `worker.py` 的监测/重试逻辑，将 `process()` 替换为已有 RAG 管线。
- SQLite 单机、少量 Worker 演示。多个 Worker 领取任务通过 `BEGIN IMMEDIATE` 串行化，但不能提供分布式严格 exactly-once。
- 模型调用结果先写入 `effects` 表，之后标记任务完成。如果进程在两者之间崩溃，重试仍可能重新调用模型，但不会重复插入同一条 `effects` 记录。对支付/发邮件等外部副作用必须使用目标系统提供的幂等键。
- 心跳依赖本机时钟；如果 Worker 失去租约，仍可能完成模型调用，但不能再提交 `jobs` 的成功状态。
- `metrics` 为全局指标，仅限可信管理员；真实多租户应限制访问。
- 本课仅保存每次成功调用的 Token 使用量。失败请求、重试耗时和排队耗时可进一步扩展。
- API_TOKEN 只是单用户演示凭据；生产环境使用第十三课的用户认证并加强权限与限流。
