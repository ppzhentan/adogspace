import logging,json,os,time,uuid
from fastapi import FastAPI,Header,HTTPException,Depends,Request
from pydantic import BaseModel,Field
from store import init,enqueue,get_job,metrics

logging.basicConfig(level=logging.INFO,format='%(message)s')
log=logging.getLogger('agent')
app=FastAPI(title='Lesson 14: Observable Agent')
@app.on_event('startup')
def startup():init()

def auth(authorization:str|None=Header(default=None)):
    token=os.getenv('API_TOKEN','')
    if not token:raise HTTPException(503,'请先设置 API_TOKEN')
    import secrets
    if not authorization or not authorization.startswith('Bearer ') or not secrets.compare_digest(authorization[7:],token):
        raise HTTPException(401,'Unauthorized')
    return 'demo-user'  # 单用户演示；接入第十三课时替换为真实 user_id

@app.middleware('http')
async def tracing(request:Request,call_next):
    trace=str(uuid.uuid4());request.state.trace_id=trace;start=time.perf_counter()
    try:
        response=await call_next(request)
        status=response.status_code
        response.headers['X-Trace-ID']=trace
        return response
    finally:
        log.info(json.dumps({'event':'http_request','trace_id':trace,'path':request.url.path,'elapsed_ms':round((time.perf_counter()-start)*1000,1)},ensure_ascii=False))

class Task(BaseModel):
    question:str=Field(min_length=1,max_length=3000)

@app.get('/health')
def health():return {'ok':True}

@app.post('/api/jobs',status_code=202)
def submit(data:Task,request:Request,idempotency_key:str|None=Header(default=None,alias='Idempotency-Key'),owner:str=Depends(auth)):
    if not idempotency_key or len(idempotency_key)>128:raise HTTPException(400,'需要 Idempotency-Key (1-128字符)')
    try:jid=enqueue(owner,idempotency_key,data.model_dump(),request.state.trace_id)
    except ValueError as e:raise HTTPException(409,str(e))
    return {'job_id':jid,'trace_id':request.state.trace_id,'status_url':f'/api/jobs/{jid}'}

@app.get('/api/jobs/{jid}')
def status(jid:str,owner:str=Depends(auth)):
    job=get_job(jid,owner)
    if not job:raise HTTPException(404,'Not found')
    return {k:job[k] for k in ['id','status','attempts','result','error','trace_id']}

@app.get('/api/metrics')
def summary(owner:str=Depends(auth)):
    return metrics()  # 演示版全局指标；多租户时须隔离/限制权限
