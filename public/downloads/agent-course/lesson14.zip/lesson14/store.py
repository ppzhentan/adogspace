import json, os, sqlite3, time, uuid
from contextlib import contextmanager
DB=os.getenv('DB_PATH','data/agent.db')

def conn():
    os.makedirs(os.path.dirname(DB) or '.',exist_ok=True)
    c=sqlite3.connect(DB,timeout=15,isolation_level=None)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA busy_timeout=15000')
    c.execute('PRAGMA journal_mode=WAL')
    return c

def init():
    with conn() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, owner TEXT NOT NULL, idem TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, max_attempts INTEGER NOT NULL DEFAULT 3, available_at REAL NOT NULL, lease_until REAL, worker_id TEXT, result TEXT, error TEXT, trace_id TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL, UNIQUE(owner,idem));
        CREATE INDEX IF NOT EXISTS jobs_ready ON jobs(status,available_at);
        CREATE TABLE IF NOT EXISTS metrics(id INTEGER PRIMARY KEY AUTOINCREMENT,trace_id TEXT,job_id TEXT,latency_ms REAL,prompt_tokens INTEGER,completion_tokens INTEGER,created_at REAL);
        CREATE TABLE IF NOT EXISTS effects(job_id TEXT PRIMARY KEY, content TEXT NOT NULL, created_at REAL NOT NULL);''')

def enqueue(owner,idem,payload,trace_id):
    now=time.time(); jid=str(uuid.uuid4()); encoded=json.dumps(payload,sort_keys=True,ensure_ascii=False)
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            c.execute('INSERT INTO jobs(id,owner,idem,payload,status,available_at,trace_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',(jid,owner,idem,encoded,'queued',now,trace_id,now,now))
        except sqlite3.IntegrityError:
            row=c.execute('SELECT * FROM jobs WHERE owner=? AND idem=?',(owner,idem)).fetchone()
            if row['payload'] != encoded:
                c.execute('ROLLBACK');raise ValueError('同一 Idempotency-Key 对应不同请求内容')
            jid=row['id']
        c.execute('COMMIT')
    return jid

def get_job(jid,owner):
    with conn() as c:
        row=c.execute('SELECT * FROM jobs WHERE id=? AND owner=?',(jid,owner)).fetchone()
    return dict(row) if row else None

def claim(worker,lease=60):
    now=time.time()
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute('''SELECT * FROM jobs WHERE (status='queued' AND available_at<=?) OR (status='running' AND lease_until<?) ORDER BY created_at LIMIT 1''',(now,now)).fetchone()
        if not row:
            c.execute('COMMIT');return None
        attempts=row['attempts']+1
        if attempts>row['max_attempts']:
            c.execute("UPDATE jobs SET status='dead',error='租约超时且重试次数耗尽',updated_at=? WHERE id=?",(now,row['id']))
            c.execute('COMMIT');return None
        c.execute('''UPDATE jobs SET status='running',attempts=?,lease_until=?,worker_id=?,updated_at=? WHERE id=?''',(attempts,now+lease,worker,now,row['id']))
        c.execute('COMMIT')
        return dict(c.execute('SELECT * FROM jobs WHERE id=?',(row['id'],)).fetchone())

def heartbeat(jid,worker,lease=60):
    with conn() as c:
        r=c.execute("UPDATE jobs SET lease_until=?,updated_at=? WHERE id=? AND worker_id=? AND status='running' AND lease_until>?",(time.time()+lease,time.time(),jid,worker,time.time()))
        return r.rowcount==1

def finish(jid,worker,result,latency,prompt,completion):
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        r=c.execute("UPDATE jobs SET status='completed',result=?,lease_until=NULL,updated_at=? WHERE id=? AND worker_id=? AND status='running' AND lease_until>?",(json.dumps(result,ensure_ascii=False),time.time(),jid,worker,time.time()))
        if r.rowcount:
            row=c.execute('SELECT trace_id FROM jobs WHERE id=?',(jid,)).fetchone()
            c.execute('INSERT INTO metrics(trace_id,job_id,latency_ms,prompt_tokens,completion_tokens,created_at) VALUES(?,?,?,?,?,?)',(row['trace_id'],jid,latency,prompt,completion,time.time()))
        c.execute('COMMIT');return r.rowcount==1

def fail(jid,worker,message,retryable):
    now=time.time()
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute("SELECT attempts,max_attempts FROM jobs WHERE id=? AND worker_id=? AND status='running' AND lease_until>?",(jid,worker,now)).fetchone()
        if not row:
            c.execute('COMMIT');return
        retry=retryable and row['attempts']<row['max_attempts']
        delay=min(60,2**row['attempts']) if retry else 0
        c.execute('''UPDATE jobs SET status=?,error=?,available_at=?,lease_until=NULL,worker_id=NULL,updated_at=? WHERE id=?''',('queued' if retry else 'dead',message[:500],now+delay,now,jid))
        c.execute('COMMIT')

def save_effect(jid,content):
    # 原子地记录业务效果：这里将“报告”存入同一 SQLite 数据库。
    with conn() as c:
        c.execute('INSERT OR IGNORE INTO effects(job_id,content,created_at) VALUES(?,?,?)',(jid,content,time.time()))
        return c.execute('SELECT content FROM effects WHERE job_id=?',(jid,)).fetchone()['content']

def metrics():
    with conn() as c:
        m=c.execute('SELECT COUNT(*) n,ROUND(AVG(latency_ms),1) latency,COALESCE(SUM(prompt_tokens),0) prompt,COALESCE(SUM(completion_tokens),0) completion FROM metrics').fetchone()
        jobs=[dict(x) for x in c.execute('SELECT status,COUNT(*) count FROM jobs GROUP BY status')]
    return {'model':dict(m),'jobs':jobs}
