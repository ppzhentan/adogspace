import json,logging,os,threading,time,uuid
from openai import OpenAI,APITimeoutError,APIConnectionError,RateLimitError,APIStatusError
from store import init,claim,heartbeat,finish,fail,save_effect

logging.basicConfig(level=logging.INFO,format='%(message)s')
log=logging.getLogger('worker')
MODEL=os.getenv('OLLAMA_MODEL','qwen3-local')
URL=os.getenv('OLLAMA_URL','http://127.0.0.1:11434/v1')
client=OpenAI(base_url=URL,api_key='ollama',timeout=90,max_retries=0)

def process(job):
    question=json.loads(job['payload'])['question']
    start=time.perf_counter()
    response=client.chat.completions.create(model=MODEL,messages=[
        {'role':'system','content':'你是中文 AI 助手。回答清晰简洁。当前是任务队列可观测性教学实验。'},
        {'role':'user','content':question}
    ],temperature=0)
    text=response.choices[0].message.content or ''
    usage=response.usage
    saved=save_effect(job['id'],text)
    return {'answer':saved},(time.perf_counter()-start)*1000,(usage.prompt_tokens if usage else 0),(usage.completion_tokens if usage else 0)

def main():
    init();wid=str(uuid.uuid4());print('Worker started:',wid,flush=True)
    while True:
        job=claim(wid,lease=120)
        if not job:
            time.sleep(1);continue
        stop=threading.Event();lost=threading.Event()
        def beat():
            while not stop.wait(20):
                if not heartbeat(job['id'],wid,lease=120):lost.set();break
        thread=threading.Thread(target=beat,daemon=True);thread.start()
        try:
            result,ms,pt,ct=process(job)
            if lost.is_set():
                log.error(json.dumps({'event':'lease_lost','job_id':job['id']}));continue
            ok=finish(job['id'],wid,result,ms,pt,ct)
            log.info(json.dumps({'event':'job_completed' if ok else 'stale_result','job_id':job['id'],'trace_id':job['trace_id'],'latency_ms':round(ms,1),'prompt_tokens':pt,'completion_tokens':ct},ensure_ascii=False))
        except (APITimeoutError,APIConnectionError,RateLimitError) as e:
            fail(job['id'],wid,type(e).__name__,True)
        except APIStatusError as e:
            fail(job['id'],wid,f'HTTP {e.status_code}',e.status_code in (408,409,429) or e.status_code>=500)
        except Exception as e:
            fail(job['id'],wid,type(e).__name__,False)
            log.exception('job_failed job_id=%s',job['id'])
        finally:
            stop.set();thread.join(timeout=2)

if __name__=='__main__':main()
