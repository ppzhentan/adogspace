# Lesson 25 · AI Agent SaaS Billing Studio

A standalone **local teaching project**, designed as a billing adapter for Lesson 24. It does not replace Lesson 24's PostgreSQL / Redis / DAG / RAG stack. It uses SQLite to make billing mechanics easy to test. Do not expose it to the internet.

## Setup

```bash
cd lesson25
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama list                    # ensure qwen3-local exists
export ADMIN_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export WEBHOOK_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
uvicorn server:app --host 127.0.0.1 --port 8000 --workers 1
```

Visit http://127.0.0.1:8000 and enter `demo-a` (or `demo-b`) as a **local demo token**. Run a task and inspect the ledger.

## Run tests

```bash
python -m pytest -q
```

## API

- `GET /api/plans` public plan limits
- `GET /api/me` budget status (Bearer demo-a / demo-b)
- `GET /api/usage` tenant-scoped ledger
- `POST /api/run` request_id, prompt, reserve_units; real local Ollama inference
- `POST /api/webhook` signed **simulated provider** subscription.updated events
- `GET /api/admin` X-Admin-Token admin summary

## Webhook demo (NOT an actual Stripe/Paddle integration)

In another shell with the same WEBHOOK_SECRET as the server:

```bash
python - <<'PY'
import hashlib,hmac,json,os,urllib.request
payload={'event_id':'evt_demo_1','tenant':'tenant-a','plan':'pro','type':'subscription.updated'}
body=json.dumps(payload).encode()
sig=hmac.new(os.environ['WEBHOOK_SECRET'].encode(),body,hashlib.sha256).hexdigest()
req=urllib.request.Request('http://127.0.0.1:8000/api/webhook',data=body,headers={'X-Signature':sig,'Content-Type':'application/json'},method='POST')
print(urllib.request.urlopen(req).read().decode())
PY
```

Run the command again: it returns `duplicate:true` and does not apply the event twice.

## Concepts

- **Units are fictional resource units**, not currency. 1 input token = 1 unit; 1 output token = 3 units. Plan limits: Free 10,000; Pro 100,000; Business 1,000,000 units/month. These are demonstration values, not pricing recommendations.
- `BEGIN IMMEDIATE` serializes SQLite quota reservations. A unique reservation ID makes settlement idempotent.
- Reserve before inference, settle from actual `response.usage`, release after a failed request. A missing usage record is treated as an error, not silently billed as zero.
- **Important gap:** actual input tokens cannot be perfectly bounded from prompt characters. The demo rejects settlements above reservation and releases the reservation; this means unusually large requests could consume compute without charge. Production must implement provider-aware token preflight, strict model token ceilings, overage policy, and reconciliation.
- **Important gap:** reservation and active-request coordination uses an in-process set; a crash can strand a reservation, and duplicate requests across processes are not prevented. Production needs durable claim state, leases, expiry/reconciliation, and a queue with idempotent execution. Do not use multiple uvicorn workers.
- **Important gap:** `subscription.updated` is a custom signed demonstration event, **not** a payment-provider webhook schema. Real integrations must verify provider-specific signatures, timestamps, event ordering, account mapping, refunds, and entitlements.
- **Important gap:** subscription plan changes are immediate; no proration, invoices, tax, refunds, or revenue ledger. Token usage is not a customer invoice.
- **Important gap:** the browser uses fixed demo tokens. Replace with Lesson 23's user auth, tenant-scoped DB queries, RBAC, and TLS before sharing.

## Production integration exercise

1. Move tenants, reservations, ledger, webhook_events into PostgreSQL via Alembic migration.
2. Use PostgreSQL `SELECT ... FOR UPDATE` on a tenant budget row to reserve atomically.
3. Enqueue `reservation_id` into Lesson 24's transactional Outbox; Worker claims and executes once per attempt.
4. Collect actual Ollama usage and commit settlement in the same transaction as workflow result.
5. Reconcile expired reservations and failed executions, without silently dropping real compute usage.
6. Use a real payment provider's official webhook signature verification and event-version semantics.
7. Add cost dashboards for latency, GPU utilization, electricity, hosting, and gross margin; these costs are separate from fictional units.

## Lesson 26 preview

Build an actual billing adapter for the PostgreSQL/Redis worker stack, integrate a provider sandbox, add metered usage dashboards and customer-facing invoices, and verify concurrency and crash recovery with integration tests.

## Optional Docker

```bash
cp .env.example .env
# Replace ADMIN_TOKEN and WEBHOOK_SECRET with random values in .env
# Ensure Ollama is reachable from the Docker container (host.docker.internal:11434)
docker compose up --build -d
```

Compose publishes only to `127.0.0.1:8000`. The SQLite database lives in a named volume. This is a **single-worker local demo**, not a scalable or hardened deployment.
