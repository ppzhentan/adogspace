"""Educational, transaction-safe usage ledger. Not a payment processor."""
import hashlib, hmac, json, os, sqlite3, time, uuid
from contextlib import contextmanager
from pathlib import Path

DB = os.getenv('BILLING_DB', str(Path(__file__).with_name('billing.sqlite3')))
PLANS = {'free': {'monthly_units': 10000, 'max_reserve': 2000}, 'pro': {'monthly_units': 100000, 'max_reserve': 10000}, 'business': {'monthly_units': 1000000, 'max_reserve': 50000}}
# Internal demo units: 1 input token = 1 unit; 1 output token = 3 units.
# This is NOT money and does not represent a provider's pricing.

def connection():
    c = sqlite3.connect(DB, timeout=20, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA busy_timeout=20000')
    return c

@contextmanager
def tx():
    c = connection()
    try:
        c.execute('BEGIN IMMEDIATE')
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()

def init():
    with tx() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS tenants(id TEXT PRIMARY KEY, plan TEXT NOT NULL DEFAULT 'free');
        CREATE TABLE IF NOT EXISTS reservations(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, period TEXT NOT NULL, reserved INTEGER NOT NULL, state TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL, FOREIGN KEY(tenant) REFERENCES tenants(id));
        CREATE TABLE IF NOT EXISTS ledger(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, reservation_id TEXT NOT NULL UNIQUE, period TEXT NOT NULL, input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL, units INTEGER NOT NULL, elapsed_ms INTEGER NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS webhook_events(event_id TEXT PRIMARY KEY, tenant TEXT NOT NULL, plan TEXT NOT NULL, created REAL NOT NULL);
        ''')

def period():
    return time.strftime('%Y-%m', time.gmtime())

def register(tenant):
    with tx() as c:
        c.execute('INSERT OR IGNORE INTO tenants(id,plan) VALUES (?,?)', (tenant,'free'))

def status(tenant):
    with connection() as c:
        row = c.execute('SELECT plan FROM tenants WHERE id=?', (tenant,)).fetchone()
        if not row: raise ValueError('unknown tenant')
        p = period()
        spent = c.execute('SELECT COALESCE(SUM(units),0) n FROM ledger WHERE tenant=? AND period=?',(tenant,p)).fetchone()['n']
        reserved = c.execute("SELECT COALESCE(SUM(reserved),0) n FROM reservations WHERE tenant=? AND period=? AND state='reserved'",(tenant,p)).fetchone()['n']
        return {'tenant':tenant,'plan':row['plan'],'period':p,'limit':PLANS[row['plan']]['monthly_units'],'spent':spent,'reserved':reserved,'available':max(0,PLANS[row['plan']]['monthly_units']-spent-reserved)}

def reserve(tenant, request_id, units):
    if not isinstance(units,int) or units <= 0: raise ValueError('invalid reservation')
    with tx() as c:
        old = c.execute('SELECT * FROM reservations WHERE id=?',(request_id,)).fetchone()
        if old:
            if old['tenant'] != tenant or old['reserved'] != units: raise ValueError('idempotency conflict')
            return dict(old)
        row = c.execute('SELECT plan FROM tenants WHERE id=?',(tenant,)).fetchone()
        if not row: raise ValueError('unknown tenant')
        plan = PLANS[row['plan']]
        if units > plan['max_reserve']: raise ValueError('reservation exceeds per-request limit')
        p = period()
        spent = c.execute('SELECT COALESCE(SUM(units),0) n FROM ledger WHERE tenant=? AND period=?',(tenant,p)).fetchone()['n']
        outstanding = c.execute("SELECT COALESCE(SUM(reserved),0) n FROM reservations WHERE tenant=? AND period=? AND state='reserved'",(tenant,p)).fetchone()['n']
        if spent+outstanding+units > plan['monthly_units']: raise ValueError('monthly budget exceeded')
        now=time.time()
        c.execute('INSERT INTO reservations VALUES (?,?,?,?,?,?,?)',(request_id,tenant,p,units,'reserved',now,now))
        return dict(c.execute('SELECT * FROM reservations WHERE id=?',(request_id,)).fetchone())

def settle(tenant, request_id, input_tokens, output_tokens, elapsed_ms):
    if any(not isinstance(x,int) or x < 0 for x in (input_tokens,output_tokens,elapsed_ms)):
        raise ValueError('invalid usage')
    units=input_tokens+3*output_tokens
    with tx() as c:
        r=c.execute('SELECT * FROM reservations WHERE id=?',(request_id,)).fetchone()
        if not r or r['tenant'] != tenant: raise ValueError('reservation missing')
        old=c.execute('SELECT * FROM ledger WHERE reservation_id=?',(request_id,)).fetchone()
        if old:
            if (old['input_tokens'],old['output_tokens'],old['elapsed_ms']) != (input_tokens,output_tokens,elapsed_ms): raise ValueError('settlement conflict')
            return dict(old)
        if r['state'] != 'reserved': raise ValueError('reservation not active')
        if units > r['reserved']: raise ValueError('actual usage exceeds reservation')
        now=time.time()
        c.execute('INSERT INTO ledger VALUES (?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),tenant,request_id,r['period'],input_tokens,output_tokens,units,elapsed_ms,now))
        c.execute("UPDATE reservations SET state='settled',updated=? WHERE id=?",(now,request_id))
        return dict(c.execute('SELECT * FROM ledger WHERE reservation_id=?',(request_id,)).fetchone())

def release(tenant, request_id):
    with tx() as c:
        r=c.execute('SELECT state,tenant FROM reservations WHERE id=?',(request_id,)).fetchone()
        if not r or r['tenant'] != tenant: raise ValueError('reservation missing')
        if r['state']=='settled': raise ValueError('already settled')
        if r['state']=='reserved': c.execute("UPDATE reservations SET state='released',updated=? WHERE id=?",(time.time(),request_id))

def apply_webhook(body, signature, secret):
    if not secret: raise ValueError('webhook secret not configured')
    expected=hmac.new(secret.encode(),body,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature): raise ValueError('invalid signature')
    event=json.loads(body)
    if set(event) != {'event_id','tenant','plan','type'} or event['type'] != 'subscription.updated' or event['plan'] not in PLANS: raise ValueError('invalid event')
    if not all(isinstance(event[k],str) and 0 < len(event[k]) <= 128 for k in ('event_id','tenant')): raise ValueError('invalid identifiers')
    with tx() as c:
        if c.execute('SELECT 1 FROM webhook_events WHERE event_id=?',(event['event_id'],)).fetchone(): return {'duplicate':True}
        if not c.execute('SELECT 1 FROM tenants WHERE id=?',(event['tenant'],)).fetchone(): raise ValueError('unknown tenant')
        c.execute('INSERT INTO webhook_events VALUES (?,?,?,?)',(event['event_id'],event['tenant'],event['plan'],time.time()))
        c.execute('UPDATE tenants SET plan=? WHERE id=?',(event['plan'],event['tenant']))
        return {'duplicate':False,'plan':event['plan']}

def history(tenant):
    with connection() as c:
        return [dict(r) for r in c.execute('SELECT * FROM ledger WHERE tenant=? ORDER BY created DESC LIMIT 100',(tenant,))]

def admin_summary():
    with connection() as c:
        return {'tenants':[dict(r) for r in c.execute('SELECT id,plan FROM tenants ORDER BY id')], 'usage':[dict(r) for r in c.execute('SELECT tenant,period,SUM(units) units,COUNT(*) requests FROM ledger GROUP BY tenant,period ORDER BY period DESC,tenant')]}
