"""Local-only commercial SaaS billing lab. Tokens are demo credentials, not production auth."""
import os, time, uuid
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
import billing

@asynccontextmanager
async def lifespan(app):
    billing.init()
    yield

app=FastAPI(title='Lesson 25 - SaaS Billing Lab',lifespan=lifespan)

def tenant_for(token):
    # A minimal local auth adapter. Lesson 23's real auth should replace this in production.
    expected=os.getenv('TENANT_TOKENS','demo-a:tenant-a,demo-b:tenant-b')
    mapping=dict(item.split(':',1) for item in expected.split(',') if ':' in item)
    for k,v in mapping.items():
        import hmac
        if hmac.compare_digest(token or '',k):
            billing.register(v)
            return v
    raise HTTPException(401,'invalid token')

def auth(authorization):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'bearer token required')
    return tenant_for(authorization[7:])

class RunRequest(BaseModel):
    prompt:str=Field(min_length=1,max_length=4000)
    reserve_units:int=Field(default=2000,ge=1,le=50000)
    request_id:str=Field(default_factory=lambda:str(uuid.uuid4()),min_length=8,max_length=128)

@app.get('/')
def home(): return FileResponse(Path(__file__).parent/'static'/'index.html')

@app.get('/health')
def health(): return {'ok':True}

@app.get('/api/plans')
def plans(): return billing.PLANS

@app.get('/api/me')
def me(authorization:str|None=Header(None)):
    return billing.status(auth(authorization))

@app.get('/api/usage')
def usage(authorization:str|None=Header(None)):
    return billing.history(auth(authorization))

@app.post('/api/run')
async def run(body:RunRequest, authorization:str|None=Header(None)):
    tenant=auth(authorization)
    try:
        r=billing.reserve(tenant,body.request_id,body.reserve_units)
    except ValueError as e: raise HTTPException(409,str(e))
    if r['state'] != 'reserved': raise HTTPException(409,'request id already finalized')
    # Prevent replay of an active request ID. Single-process demo only; production requires a DB claim.
    import asyncio
    lock=app.state.__dict__.setdefault('active_requests',set())
    if body.request_id in lock: raise HTTPException(409,'request already running')
    lock.add(body.request_id)
    started=time.monotonic()
    try:
        from openai import AsyncOpenAI
        client=AsyncOpenAI(base_url=os.getenv('OLLAMA_BASE_URL','http://127.0.0.1:11434/v1'),api_key='ollama',timeout=90,max_retries=0)
        try:
            response=await client.chat.completions.create(model=os.getenv('OLLAMA_MODEL','qwen3-local'),messages=[{'role':'user','content':body.prompt}],max_tokens=min(1024,body.reserve_units//3))
        finally:
            await client.close()
        usage=response.usage
        if usage is None: raise RuntimeError('model did not return token usage; cannot safely settle')
        i,o=usage.prompt_tokens,usage.completion_tokens
        elapsed=int((time.monotonic()-started)*1000)
        settled=billing.settle(tenant,body.request_id,i,o,elapsed)
        return {'request_id':body.request_id,'answer':response.choices[0].message.content,'usage':settled,'budget':billing.status(tenant)}
    except ValueError as e:
        # If actual usage exceeded reserved budget, do not silently undercharge.
        billing.release(tenant,body.request_id)
        raise HTTPException(409,str(e))
    except Exception as e:
        billing.release(tenant,body.request_id)
        raise HTTPException(503,'inference failed or usage unavailable') from e
    finally:
        lock.discard(body.request_id)

@app.post('/api/webhook')
async def webhook(request:Request,x_signature:str|None=Header(None)):
    body=await request.body()
    if len(body)>8192: raise HTTPException(413,'event too large')
    try: return billing.apply_webhook(body,x_signature or '',os.getenv('WEBHOOK_SECRET',''))
    except (ValueError,KeyError,TypeError) as e: raise HTTPException(400,str(e))

@app.get('/api/admin')
def admin(x_admin_token:str|None=Header(None)):
    import hmac
    secret=os.getenv('ADMIN_TOKEN','')
    if not secret or not hmac.compare_digest(x_admin_token or '',secret): raise HTTPException(403,'admin only')
    return billing.admin_summary()
