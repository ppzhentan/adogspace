import hashlib,hmac,json,pytest
import billing

@pytest.fixture(autouse=True)
def isolated(tmp_path,monkeypatch):
    monkeypatch.setattr(billing,'DB',str(tmp_path/'test.db'))
    billing.init(); billing.register('a');billing.register('b')

def test_default_plan():
    assert billing.status('a')['plan']=='free'

def test_reserve_and_settle():
    billing.reserve('a','request-001',100)
    assert billing.status('a')['reserved']==100
    x=billing.settle('a','request-001',20,10,50)
    assert x['units']==50
    assert billing.status('a')['spent']==50
    assert billing.status('a')['reserved']==0

def test_settle_idempotent():
    billing.reserve('a','request-001',100)
    a=billing.settle('a','request-001',20,10,50)
    b=billing.settle('a','request-001',20,10,50)
    assert a['id']==b['id']
    assert billing.status('a')['spent']==50

def test_conflicting_settlement():
    billing.reserve('a','request-001',100)
    billing.settle('a','request-001',20,10,50)
    with pytest.raises(ValueError,match='conflict'): billing.settle('a','request-001',20,11,50)

def test_tenant_isolation():
    billing.reserve('a','request-001',100)
    with pytest.raises(ValueError): billing.settle('b','request-001',10,10,10)
    assert billing.history('b')==[]

def test_reserve_idempotent_conflict():
    billing.reserve('a','request-001',100)
    assert billing.reserve('a','request-001',100)['reserved']==100
    with pytest.raises(ValueError): billing.reserve('a','request-001',200)

def test_budget():
    for i in range(5): billing.reserve('a',f'request-{i:03}',2000)
    with pytest.raises(ValueError,match='budget'): billing.reserve('a','request-extra',1)

def test_per_request_limit():
    with pytest.raises(ValueError): billing.reserve('a','request-001',2001)

def test_release():
    billing.reserve('a','request-001',100)
    billing.release('a','request-001')
    assert billing.status('a')['available']==10000
    with pytest.raises(ValueError): billing.settle('a','request-001',1,1,1)

def test_over_reservation():
    billing.reserve('a','request-001',10)
    with pytest.raises(ValueError): billing.settle('a','request-001',20,0,1)

def sign(event,secret='test-secret'):
    body=json.dumps(event).encode()
    return body,hmac.new(secret.encode(),body,hashlib.sha256).hexdigest()

def test_webhook_valid_and_duplicate():
    event={'event_id':'evt1','tenant':'a','plan':'pro','type':'subscription.updated'}
    body,sig=sign(event)
    assert billing.apply_webhook(body,sig,'test-secret')['duplicate'] is False
    assert billing.apply_webhook(body,sig,'test-secret')['duplicate'] is True
    assert billing.status('a')['plan']=='pro'

def test_webhook_signature():
    body,sig=sign({'event_id':'evt1','tenant':'a','plan':'pro','type':'subscription.updated'})
    with pytest.raises(ValueError,match='signature'): billing.apply_webhook(body,'bad','test-secret')

def test_webhook_unknown_tenant():
    body,sig=sign({'event_id':'evt1','tenant':'missing','plan':'pro','type':'subscription.updated'})
    with pytest.raises(ValueError,match='unknown tenant'): billing.apply_webhook(body,sig,'test-secret')

def test_invalid_usage():
    billing.reserve('a','request-001',100)
    with pytest.raises(ValueError): billing.settle('a','request-001',-1,1,1)

def test_admin_summary():
    billing.reserve('a','request-001',100)
    billing.settle('a','request-001',10,10,10)
    assert billing.admin_summary()['usage'][0]['units']==40
