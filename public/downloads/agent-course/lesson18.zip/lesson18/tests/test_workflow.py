import importlib
import pytest

@pytest.fixture
def store(tmp_path,monkeypatch):
    import store
    monkeypatch.setattr(store,"DB_PATH",tmp_path/"db.sqlite3")
    store.init()
    return store

def test_create_and_history(store):
    wid=store.create("local","test goal")
    assert store.get(wid,"local")["workflow"]["status"]=="queued"
    assert len(store.history("local"))==1
    assert store.get(wid,"another") is None

def test_dependency_gate(store):
    wid=store.create("local","goal")
    assert not store.claim_node(wid,"analysis")
    assert store.claim_node(wid,"research_shipping")
    assert store.complete_node(wid,"research_shipping","done")
    assert not store.claim_node(wid,"analysis")

def make_waiting(store):
    wid=store.create("local","goal")
    for n in ("research_shipping","research_returns","research_payment","analysis","draft"):
        assert store.claim_node(wid,n)
        assert store.complete_node(wid,n,"report")
    store.waiting_approval(wid)
    return wid

def test_approve_and_publish(store):
    wid=make_waiting(store)
    assert store.decide(wid,"local","alice","approved")=="ok"
    assert store.claim_node(wid,"publish")
    assert store.complete_node(wid,"publish","final")
    assert store.get(wid,"local")["workflow"]["status"]=="completed"
    assert store.decide(wid,"local","alice","approved")=="conflict"

def test_reject_blocks_publish(store):
    wid=make_waiting(store)
    assert store.decide(wid,"local","alice","rejected")=="ok"
    assert not store.claim_node(wid,"publish")

def test_cancel_blocks_completion(store):
    wid=store.create("local","goal")
    assert store.claim_node(wid,"research_shipping")
    assert store.cancel(wid,"local")=="ok"
    assert not store.complete_node(wid,"research_shipping","late")
    assert store.get(wid,"local")["workflow"]["status"]=="cancelled"

def test_failed_recovery(store):
    wid=store.create("local","goal")
    assert store.claim_node(wid,"research_shipping")
    store.fail_node(wid,"research_shipping","error")
    assert store.recover(wid,"local")=="ok"
    assert store.claim_node(wid,"research_shipping")

def test_event_cursor(store):
    wid=store.create("local","goal")
    rows=store.events_since(wid,"local")
    assert len(rows)==1
    assert store.events_since(wid,"local",rows[0]["id"])==[]
    assert store.events_since(wid,"other") is None
