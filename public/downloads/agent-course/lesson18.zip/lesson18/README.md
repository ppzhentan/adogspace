# 第十八课：Multi-Agent DAG Web 控制台

本地教学版：FastAPI + SSE + SQLite + Ollama `qwen3-local`。不需要付费 API。

## 快速启动（macOS）

```bash
cd lesson18
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama list   # 确认 qwen3-local 存在
export AGENT_API_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
echo "$AGENT_API_TOKEN"   # 保存，Web 页面需要填写
uvicorn server:app --host 127.0.0.1 --port 8000
```

浏览器打开 `http://127.0.0.1:8000`，输入 Token，点击“连接并加载历史”，输入目标并启动工作流。API 文档：`http://127.0.0.1:8000/docs`。

**注意**：Token 不会保存到浏览器持久化存储，刷新后需要重新输入。示例只有一个本地用户 `local`，不是生产多用户认证系统。不要对公网开放。

## 工作流

三个 Researcher 并行读取本地 `docs/` 演示文档；Analyst 等待三个研究节点完成；Writer 输出 Markdown 草稿；Human Approval 暂停等待审批；批准后 Publish 把结果持久化在 SQLite 的 `tasks.output` 中。网页中可查看草稿及发布结果。

任务状态与事件存于 `data/workflows.sqlite3`。SSE 接口按事件 ID 提供可重放的更新。浏览器通过 `fetch()` 传 Bearer Token 消费 SSE（原生 EventSource 不方便添加自定义 Authorization 头）。

## REST API

```bash
export TOKEN='复制上面生成的AGENT_API_TOKEN'

curl -X POST http://127.0.0.1:8000/api/workflows \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"goal":"分析日本站配送退货与支付政策，提出三项优化建议"}'

curl http://127.0.0.1:8000/api/workflows \
  -H "Authorization: Bearer $TOKEN"

curl -N http://127.0.0.1:8000/api/workflows/WORKFLOW_ID/stream \
  -H "Authorization: Bearer $TOKEN"

curl -X POST http://127.0.0.1:8000/api/workflows/WORKFLOW_ID/approve \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"reviewer":"alice"}'

curl -X POST http://127.0.0.1:8000/api/workflows/WORKFLOW_ID/cancel \
  -H "Authorization: Bearer $TOKEN"
```

拒绝：`POST /api/workflows/{id}/reject`，Body `{"reviewer":"alice"}`；失败后恢复：`POST /api/workflows/{id}/resume`。恢复前确认原执行进程已经停止。

## 自动测试

```bash
python -m pytest -q
```

测试验证：依赖门禁、任务状态、人工审批、拒绝发布、取消后阻止完成写入、失败恢复、事件游标和用户范围检查。不调用真实 Ollama。

## 重要工程边界

- **单进程运行**：进程内 Runner 防止同一工作流重复调度，但没有跨进程锁或租约。不要使用 `uvicorn --workers 2`，不要多实例启动。
- **重启恢复**：SQLite 保存状态和事件，但进程崩溃时 `running` 节点不会自动变为 `failed`。需要运维先确认旧进程已停止，再手动恢复。可扩展 Lease + Heartbeat + Fencing Token。
- **取消是协作式的**：取消会先持久化 `cancelled` 并阻止晚到结果写回，随后取消 asyncio 任务。不能保证 Ollama 服务端已停止推理，也不撤销外部副作用。
- **审批不具备强身份验证**：本地共享 Bearer Token，`reviewer` 只是审计文本。生产环境需要多用户、RBAC、CSRF/Origin 策略、HTTPS 和限流。
- **SSE 不保证立即推送**：这里每秒轮询 SQLite 事件表并发出 SSE；断线后可以用 `since` 重放。生产可使用消息代理和 Last-Event-ID。
- **数据隐私**：数据库保存用户目标和模型中间输出，必须保护数据库文件。演示资料均为虚构。
- **执行预算**：默认没有按 Token 计费/配额、复杂的失败重试、任务超时、完整的模型评估与检索引用验证。
- **不要让模型执行任意命令**：本课只允许读取预置文档；外部资料一律按不可信数据处理。
