"""Durable SQLite workflow state. One writer transaction per transition."""
import json
import os
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(os.getenv("WORKFLOW_DB", Path(__file__).resolve().parent / "data" / "workflows.sqlite3"))
NODES = {
    "research_shipping": ("Researcher", []),
    "research_returns": ("Researcher", []),
    "research_payment": ("Researcher", []),
    "analysis": ("Analyst", ["research_shipping", "research_returns", "research_payment"]),
    "draft": ("Writer", ["analysis"]),
    "approval": ("Human", ["draft"]),
    "publish": ("Publisher", ["approval"]),
}
TERMINAL = {"completed", "rejected", "cancelled", "failed"}

@contextmanager
def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()

def init():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript("""
        CREATE TABLE IF NOT EXISTS workflows(
          id TEXT PRIMARY KEY, owner TEXT NOT NULL, goal TEXT NOT NULL,
          status TEXT NOT NULL, cancel_requested INTEGER NOT NULL DEFAULT 0,
          created_at REAL NOT NULL, updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks(
          workflow_id TEXT NOT NULL, node TEXT NOT NULL, role TEXT NOT NULL,
          status TEXT NOT NULL, output TEXT, error TEXT, started_at REAL,
          finished_at REAL, PRIMARY KEY(workflow_id,node),
          FOREIGN KEY(workflow_id) REFERENCES workflows(id)
        );
        CREATE TABLE IF NOT EXISTS events(
          id INTEGER PRIMARY KEY AUTOINCREMENT, workflow_id TEXT NOT NULL,
          kind TEXT NOT NULL, node TEXT, payload TEXT NOT NULL,
          created_at REAL NOT NULL,
          FOREIGN KEY(workflow_id) REFERENCES workflows(id)
        );
        CREATE TABLE IF NOT EXISTS approvals(
          workflow_id TEXT PRIMARY KEY, reviewer TEXT NOT NULL,
          decision TEXT NOT NULL, created_at REAL NOT NULL,
          FOREIGN KEY(workflow_id) REFERENCES workflows(id)
        );
        CREATE INDEX IF NOT EXISTS idx_workflows_owner ON workflows(owner,created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_events_workflow ON events(workflow_id,id);
        """)

def event(c, wid, kind, node=None, payload=None):
    c.execute("INSERT INTO events(workflow_id,kind,node,payload,created_at) VALUES(?,?,?,?,?)",
              (wid,kind,node,json.dumps(payload or {},ensure_ascii=False),time.time()))

def create(owner,goal):
    wid=str(uuid.uuid4()); now=time.time()
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        c.execute("INSERT INTO workflows(id,owner,goal,status,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                  (wid,owner,goal,"queued",now,now))
        c.executemany("INSERT INTO tasks(workflow_id,node,role,status) VALUES(?,?,?,?)",
                      [(wid,node,role,"pending") for node,(role,_) in NODES.items()])
        event(c,wid,"workflow_created",payload={"goal":goal})
        c.execute("COMMIT")
    return wid

def get(wid,owner):
    with db() as c:
        row=c.execute("SELECT * FROM workflows WHERE id=? AND owner=?",(wid,owner)).fetchone()
        if row is None: return None
        tasks=c.execute("SELECT * FROM tasks WHERE workflow_id=? ORDER BY rowid",(wid,)).fetchall()
        approval=c.execute("SELECT reviewer,decision,created_at FROM approvals WHERE workflow_id=?",(wid,)).fetchone()
        return {"workflow":dict(row),"tasks":[dict(t)|{"depends_on":NODES[t["node"]][1]} for t in tasks],
                "approval":dict(approval) if approval else None}

def history(owner,limit=50):
    with db() as c:
        return [dict(x) for x in c.execute("SELECT * FROM workflows WHERE owner=? ORDER BY created_at DESC LIMIT ?",(owner,limit))]

def events_since(wid,owner,since=0,limit=100):
    with db() as c:
        if not c.execute("SELECT 1 FROM workflows WHERE id=? AND owner=?",(wid,owner)).fetchone(): return None
        rows=c.execute("SELECT * FROM events WHERE workflow_id=? AND id>? ORDER BY id LIMIT ?",(wid,since,limit)).fetchall()
        return [dict(r)|{"payload":json.loads(r["payload"])} for r in rows]

def claim_node(wid,node):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT status,cancel_requested FROM workflows WHERE id=?",(wid,)).fetchone()
        if not w or w["cancel_requested"] or w["status"] in TERMINAL:
            c.execute("ROLLBACK"); return False
        statuses={r["node"]:r["status"] for r in c.execute("SELECT node,status FROM tasks WHERE workflow_id=?",(wid,))}
        if statuses[node]!="pending" or not all(statuses[d]=="completed" for d in NODES[node][1]):
            c.execute("ROLLBACK"); return False
        c.execute("UPDATE tasks SET status='running',started_at=?,error=NULL WHERE workflow_id=? AND node=?",(time.time(),wid,node))
        c.execute("UPDATE workflows SET status='running',updated_at=? WHERE id=?",(time.time(),wid))
        event(c,wid,"node_started",node)
        c.execute("COMMIT"); return True

def complete_node(wid,node,output):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT cancel_requested FROM workflows WHERE id=?",(wid,)).fetchone()
        t=c.execute("SELECT status FROM tasks WHERE workflow_id=? AND node=?",(wid,node)).fetchone()
        if not w or w["cancel_requested"] or not t or t["status"]!="running":
            c.execute("ROLLBACK"); return False
        c.execute("UPDATE tasks SET status='completed',output=?,finished_at=? WHERE workflow_id=? AND node=?",(output,time.time(),wid,node))
        event(c,wid,"node_completed",node,{"length":len(output)})
        if node=="publish":
            c.execute("UPDATE workflows SET status='completed',updated_at=? WHERE id=?",(time.time(),wid))
            event(c,wid,"workflow_completed")
        else:
            c.execute("UPDATE workflows SET updated_at=? WHERE id=?",(time.time(),wid))
        c.execute("COMMIT"); return True

def fail_node(wid,node,error):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT cancel_requested FROM workflows WHERE id=?",(wid,)).fetchone()
        if not w or w["cancel_requested"]:
            c.execute("ROLLBACK"); return
        c.execute("UPDATE tasks SET status='failed',error=?,finished_at=? WHERE workflow_id=? AND node=?",(str(error)[:500],time.time(),wid,node))
        c.execute("UPDATE workflows SET status='failed',updated_at=? WHERE id=?",(time.time(),wid))
        event(c,wid,"node_failed",node,{"error":str(error)[:200]})
        c.execute("COMMIT")

def waiting_approval(wid):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT status,cancel_requested FROM workflows WHERE id=?",(wid,)).fetchone()
        if w and not w["cancel_requested"] and w["status"] not in TERMINAL:
            c.execute("UPDATE workflows SET status='waiting_approval',updated_at=? WHERE id=?",(time.time(),wid))
            event(c,wid,"approval_requested","approval")
        c.execute("COMMIT")

def decide(wid,owner,reviewer,decision):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT status,cancel_requested FROM workflows WHERE id=? AND owner=?",(wid,owner)).fetchone()
        if not w: c.execute("ROLLBACK"); return "not_found"
        if w["status"]!="waiting_approval" or w["cancel_requested"]:
            c.execute("ROLLBACK"); return "conflict"
        draft=c.execute("SELECT status FROM tasks WHERE workflow_id=? AND node='draft'",(wid,)).fetchone()
        if not draft or draft["status"]!="completed": c.execute("ROLLBACK"); return "conflict"
        c.execute("INSERT INTO approvals(workflow_id,reviewer,decision,created_at) VALUES(?,?,?,?)",(wid,reviewer,decision,time.time()))
        c.execute("UPDATE tasks SET status=?,output=?,finished_at=? WHERE workflow_id=? AND node='approval'",("completed" if decision=="approved" else "rejected",decision,time.time(),wid))
        c.execute("UPDATE workflows SET status=?,updated_at=? WHERE id=?",("queued" if decision=="approved" else "rejected",time.time(),wid))
        event(c,wid,"approval_decided","approval",{"decision":decision,"reviewer":reviewer})
        c.execute("COMMIT"); return "ok"

def cancel(wid,owner):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT status FROM workflows WHERE id=? AND owner=?",(wid,owner)).fetchone()
        if not w: c.execute("ROLLBACK"); return "not_found"
        if w["status"] in TERMINAL: c.execute("ROLLBACK"); return "conflict"
        c.execute("UPDATE workflows SET status='cancelled',cancel_requested=1,updated_at=? WHERE id=?",(time.time(),wid))
        c.execute("UPDATE tasks SET status='cancelled' WHERE workflow_id=? AND status IN ('pending','running')",(wid,))
        event(c,wid,"workflow_cancelled")
        c.execute("COMMIT"); return "ok"

def recover(wid,owner):
    """Manual recovery only when previous worker has been stopped."""
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        w=c.execute("SELECT status FROM workflows WHERE id=? AND owner=?",(wid,owner)).fetchone()
        if not w: c.execute("ROLLBACK"); return "not_found"
        if w["status"]!="failed": c.execute("ROLLBACK"); return "conflict"
        c.execute("UPDATE tasks SET status='pending',error=NULL WHERE workflow_id=? AND status IN ('failed','running')",(wid,))
        c.execute("UPDATE workflows SET status='queued',updated_at=? WHERE id=?",(time.time(),wid))
        event(c,wid,"workflow_recovered")
        c.execute("COMMIT"); return "ok"
