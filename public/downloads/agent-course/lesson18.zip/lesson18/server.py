"""Local-only teaching API. Never expose without real user auth and deployment hardening."""
import asyncio
import json
import os
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field
import store
from engine import Runner

runner=Runner()
TOKEN=os.getenv("AGENT_API_TOKEN","")
if not TOKEN:
    # Only safe when bound to loopback; prefer explicitly setting token for any deployment.
    print("WARNING: AGENT_API_TOKEN not set. API calls require setting a token before starting.")

@asynccontextmanager
async def lifespan(app):
    store.init()
    # Startup recovery is intentionally manual; running jobs are not automatically reclaimed.
    yield
    for t in list(runner.active.values()): t.cancel()
    if runner.active:
        await asyncio.gather(*runner.active.values(),return_exceptions=True)

app=FastAPI(title="Lesson 18 - Multi-Agent Workflow",lifespan=lifespan)
STATIC=Path(__file__).resolve().parent/"static"/"index.html"

async def auth(authorization: str | None=Header(default=None)):
    if not TOKEN or not authorization or not authorization.startswith("Bearer ") or not secrets.compare_digest(authorization[7:],TOKEN):
        raise HTTPException(401,"Unauthorized")
    return "local"

class CreateWorkflow(BaseModel):
    goal: str=Field(min_length=8,max_length=1000)
class Decision(BaseModel):
    reviewer: str=Field(min_length=1,max_length=80)

@app.get("/")
def index(): return FileResponse(STATIC)

@app.get("/api/health")
def health(): return {"ok":True,"model":os.getenv("OLLAMA_MODEL","qwen3-local")}

@app.post("/api/workflows",status_code=201)
async def create_workflow(body:CreateWorkflow,owner=Depends(auth)):
    wid=store.create(owner,body.goal)
    await runner.launch(wid)
    return {"id":wid,"status":"queued"}

@app.get("/api/workflows")
def list_workflows(owner=Depends(auth)):
    return {"items":store.history(owner)}

@app.get("/api/workflows/{wid}")
def get_workflow(wid:str,owner=Depends(auth)):
    value=store.get(wid,owner)
    if value is None: raise HTTPException(404,"Not found")
    return value

@app.get("/api/workflows/{wid}/events")
def get_events(wid:str,since:int=0,owner=Depends(auth)):
    rows=store.events_since(wid,owner,max(0,since))
    if rows is None: raise HTTPException(404,"Not found")
    return {"items":rows}

@app.get("/api/workflows/{wid}/stream")
async def stream_events(wid:str,request:Request,since:int=0,owner=Depends(auth)):
    if store.get(wid,owner) is None: raise HTTPException(404,"Not found")
    async def gen():
        cursor=max(0,since)
        while not await request.is_disconnected():
            events=store.events_since(wid,owner,cursor)
            for ev in events or []:
                cursor=ev["id"]
                yield f"id: {cursor}\nevent: update\ndata: {json.dumps(ev,ensure_ascii=False)}\n\n"
            yield ": heartbeat\n\n"
            await asyncio.sleep(1)
    return StreamingResponse(gen(),media_type="text/event-stream",headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.post("/api/workflows/{wid}/approve")
async def approve(wid:str,body:Decision,owner=Depends(auth)):
    result=store.decide(wid,owner,body.reviewer,"approved")
    if result=="not_found": raise HTTPException(404,"Not found")
    if result!="ok": raise HTTPException(409,"Workflow is not waiting for approval")
    await runner.launch(wid)
    return {"status":"approved"}

@app.post("/api/workflows/{wid}/reject")
def reject(wid:str,body:Decision,owner=Depends(auth)):
    result=store.decide(wid,owner,body.reviewer,"rejected")
    if result=="not_found": raise HTTPException(404,"Not found")
    if result!="ok": raise HTTPException(409,"Workflow is not waiting for approval")
    return {"status":"rejected"}

@app.post("/api/workflows/{wid}/cancel")
async def cancel(wid:str,owner=Depends(auth)):
    result=store.cancel(wid,owner)
    if result=="not_found": raise HTTPException(404,"Not found")
    if result!="ok": raise HTTPException(409,"Already terminal")
    await runner.stop(wid)
    return {"status":"cancelled"}

@app.post("/api/workflows/{wid}/resume")
async def resume(wid:str,owner=Depends(auth)):
    if wid in runner.active and not runner.active[wid].done():
        raise HTTPException(409,"Worker still active")
    result=store.recover(wid,owner)
    if result=="not_found": raise HTTPException(404,"Not found")
    if result!="ok": raise HTTPException(409,"Only failed workflows can be resumed")
    await runner.launch(wid)
    return {"status":"queued"}
