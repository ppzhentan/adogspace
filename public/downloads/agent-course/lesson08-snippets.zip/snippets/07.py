if user_input and get_pending_calls(history):
    raise RuntimeError(
        "存在未完成的工具调用，请先输入 resume"
    )
