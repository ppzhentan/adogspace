
def get_pending_calls(history):
    """找出最近一组尚未完成的工具调用。"""

    for i in range(len(history) - 1, -1, -1):
        msg = history[i]

        if msg["role"] != "assistant":
            continue

        calls = msg.get("tool_calls") or []
        if not calls:
            continue

        completed_ids = {
            item["tool_call_id"]
            for item in history[i + 1:]
            if item["role"] == "tool"
        }

        return [
            call for call in calls
            if call["id"] not in completed_ids
        ]

    return []
