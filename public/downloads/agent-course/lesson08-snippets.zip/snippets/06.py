pending = get_pending_calls(history)

if pending:
    calls = pending
else:
    # 正常请求模型
    ...
