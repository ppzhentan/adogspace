
import json
import sqlite3
from pathlib import Path
from datetime import datetime, timezone
from openai import OpenAI

MODEL = "qwen3-local"
DB_PATH = Path(__file__).parent / "agent.db"

client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama",
    timeout=120
)


def now():
    return datetime.now(timezone.utc).isoformat()


# ---------- 数据库 ----------

def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            payload TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS memories (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS tasks (
            session_id TEXT PRIMARY KEY,
            status TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """)


def save_message(session_id, message):
    with connect() as db:
        db.execute(
            """
            INSERT INTO messages
            (session_id, role, payload, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (
                session_id,
                message["role"],
                json.dumps(message, ensure_ascii=False),
                now()
            )
        )


def load_messages(session_id):
    with connect() as db:
        rows = db.execute(
            """
            SELECT payload FROM messages
            WHERE session_id = ?
            ORDER BY id
            """,
            (session_id,)
        ).fetchall()

    return [json.loads(row["payload"]) for row in rows]


def set_status(session_id, status):
    with connect() as db:
        db.execute(
            """
            INSERT INTO tasks
            (session_id, status, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(session_id) DO UPDATE SET
                status = excluded.status,
                updated_at = excluded.updated_at
            """,
            (session_id, status, now())
        )


# ---------- 长期记忆工具 ----------

def remember(key: str, value: str):
    """保存一条长期记忆。"""
    if not key or len(key) > 100 or len(value) > 1000:
        return {"error": "记忆长度不符合要求"}

    with connect() as db:
        db.execute(
            """
            INSERT INTO memories (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_at = excluded.updated_at
            """,
            (key, value, now())
        )

    return {"saved": True, "key": key}


def recall(key: str):
    """读取指定长期记忆。"""
    with connect() as db:
        row = db.execute(
            "SELECT value FROM memories WHERE key = ?",
            (key,)
        ).fetchone()

    if row is None:
        return {"found": False}

    return {"found": True, "value": row["value"]}


# ---------- 商品工具 ----------

def get_product(product_id: str):
    products = {
        "P001": {
            "name": "女士针织衫",
            "price": 299,
            "cost": 120,
            "shipping": 25
        },
        "P002": {
            "name": "女士连衣裙",
            "price": 399,
            "cost": 180,
            "shipping": 35
        }
    }

    return products.get(
        product_id,
        {"error": "商品不存在"}
    )


FUNCTIONS = {
    "remember": remember,
    "recall": recall,
    "get_product": get_product
}

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "remember",
            "description": "用户明确要求记住信息时保存长期记忆",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string"},
                    "value": {"type": "string"}
                },
                "required": ["key", "value"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "recall",
            "description": "通过key查询之前保存的长期记忆",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string"}
                },
                "required": ["key"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_product",
            "description": "通过商品编号查询商品信息",
            "parameters": {
                "type": "object",
                "properties": {
                    "product_id": {"type": "string"}
                },
                "required": ["product_id"]
            }
        }
    }
]


# ---------- 上下文管理 ----------

SYSTEM = {
    "role": "system",
    "content": (
        "你是中文电商分析助手。"
        "需要商品数据时使用get_product。"
        "用户明确要求记住信息时使用remember。"
        "需要长期记忆时使用recall。"
        "不得编造工具结果。"
        "工具失败时说明原因。"
    )
}


def build_context(history, max_messages=20):
    """
    保留最近消息，避免上下文无限增长。
    不截断未完成的工具调用组。
    """

    if len(history) <= max_messages:
        return [SYSTEM] + history

    # 从最近消息向前查找安全切分点
    start = len(history) - max_messages

    # 不要从 tool 消息开始
    while start > 0 and history[start]["role"] == "tool":
        start -= 1

    return [SYSTEM] + history[start:]


# ---------- Agent Loop ----------

def run_agent(session_id, user_input=None, max_steps=8):

    history = load_messages(session_id)

    if user_input:
        # 不允许在未完成的工具调用中插入新问题
        if history and history[-1].get("tool_calls"):
            raise RuntimeError(
                "上次工具调用尚未完成，请先恢复任务"
            )

        user_message = {
            "role": "user",
            "content": user_input
        }
        save_message(session_id, user_message)
        history.append(user_message)

    elif not history:
        print("没有可恢复的会话")
        return

    set_status(session_id, "running")

    for step in range(max_steps):

        print(f"\n===== 第 {step + 1} 轮 =====")

        # 恢复未完成的工具调用
        pending = None

        if history:
            last = history[-1]
            if last["role"] == "assistant":
                pending = last.get("tool_calls")

        if pending:
            calls = pending

        else:
            messages = build_context(history)

            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                temperature=0
            )

            message = response.choices[0].message
            assistant_message = message.model_dump(
                exclude_none=True
            )

            save_message(session_id, assistant_message)
            history.append(assistant_message)

            calls = assistant_message.get("tool_calls")

            if not calls:
                answer = assistant_message.get("content")
                print("\nAgent:", answer)
                set_status(session_id, "completed")
                return answer

        # 执行本轮工具
        for call in calls:

            name = call["function"]["name"]
            call_id = call["id"]

            print("调用工具：", name)

            try:
                args = json.loads(
                    call["function"]["arguments"]
                )

                if not isinstance(args, dict):
                    result = {"error": "参数格式错误"}
                elif name not in FUNCTIONS:
                    result = {"error": "未知工具"}
                else:
                    result = FUNCTIONS[name](**args)

            except (ValueError, TypeError) as e:
                result = {"error": str(e)}

            tool_message = {
                "role": "tool",
                "tool_call_id": call_id,
                "content": json.dumps(
                    result,
                    ensure_ascii=False
                )
            }

            save_message(session_id, tool_message)
            history.append(tool_message)

            print("结果：", result)

    set_status(session_id, "paused")
    print("\n已暂停，可稍后恢复")


# ---------- CLI ----------

if __name__ == "__main__":

    init_db()

    print("AI Agent Memory Demo")
    print("输入 exit 退出")
    print("输入 resume 恢复当前任务")

    session_id = input(
        "Session ID（默认 demo）："
    ).strip() or "demo"

    while True:
        text = input("\n你：").strip()

        if text == "exit":
            break

        if text == "resume":
            run_agent(session_id)
            continue

        if text:
            run_agent(session_id, text)
